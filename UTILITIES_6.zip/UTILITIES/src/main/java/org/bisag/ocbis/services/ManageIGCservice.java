package org.bisag.ocbis.services;

import java.io.File;
import java.io.OutputStream;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.bisag.ocbis.models.ManageIGCcontacts;
import org.bisag.ocbis.models.ManageIGCdocs;
import org.bisag.ocbis.models.ManageIGCphotos;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.ManageIGCcontactRepository;
import org.bisag.ocbis.repository.ManageIGCdocsRepository;
import org.bisag.ocbis.repository.ManageIGCphotosRepository;
import org.bisag.ocbis.utils.FileValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
public class ManageIGCservice {

    @Value("${fileServerPath}")
    String fileServerPath;

    @Autowired
    private ManageIGCcontactRepository contactsrepo;

    @Autowired
    private ManageIGCdocsRepository docsrepo;

    @Autowired
    private ManageIGCphotosRepository photosrepo;

    // 1. Save IGC contact
    @Transactional
    public <json> EncryptedResponse saveManageIGCcontacts(ManageIGCcontacts body) throws Exception {

        // Long id = body.getId();

        // if (savedObj.isPresent()) {
        // try {
        // ManageRecentDocs existingDetails = savedObj.get();

        // try (OutputStream stream = FileUtils.openOutputStream(fileTenth))
        // {
        // stream.write(docUpload);
        // existingDetails.setUploadDocument(uuid.toString());
        // }
        // existingDetails.setId((body.getId()));
        // existingDetails.setTitle(body.getTitle());
        // existingDetails.setSecurityGroup(body.getSecurityGroup());
        // existingDetails.setType(body.getType());
        // existingDetails.setDocumentType(body.getDocumentType());
        // existingDetails.setDescription(body.getDescription());
        // existingDetails.setStatus(body.getStatus());
        // existingDetails.setReceivedDate(body.getReceivedDate());
        // existingDetails.setRegion(body.getRegion());

        // managerecentdocsrepo.save(existingDetails);

        // return new EncryptedResponse("Document uploaded");
        // } catch (Exception e) {
        // return new EncryptedResponse("some error occured");
        // }
        // } else {
        try {

            ManageIGCcontacts newIGCcontact = new ManageIGCcontacts();
            newIGCcontact.setSection((body.getSection()));
            newIGCcontact.setName(body.getName());
            newIGCcontact.setDesignation(body.getDesignation());
            newIGCcontact.setAddress(body.getAddress());
            newIGCcontact.setEmailId(body.getEmailId());
            newIGCcontact.setIp(body.getIp());
            newIGCcontact.setFax(body.getFax());
            newIGCcontact.setPhone(body.getPhone());
            newIGCcontact.setWebsite(body.getWebsite());
            contactsrepo.save(newIGCcontact);

            return new EncryptedResponse("Contact saved successfully");

        } catch (Exception e) {
            return new EncryptedResponse("Error saving contact");
        }
    }

    // 2. View all IGC contact
    @Transactional
    public List<ManageIGCcontacts> getAllIGCcontacts(PageRequest page) {
        return contactsrepo.findAll();
    }

    // 3.  Delete IGC contact
    @Transactional
    public void deleteIGCcontact(ManageIGCcontacts body) {
        Long id = body.getId();
        contactsrepo.deleteById(id);
    }

    // 4. Edit IGC Contact
    @Transactional
    public ManageIGCcontacts editIGCcontact(ManageIGCcontacts body) {
        Long id = body.getId();
        Optional<ManageIGCcontacts> optionalContact = contactsrepo.findById(id);
        
        if (optionalContact.isPresent()) {
            ManageIGCcontacts igcContact = optionalContact.get();
            igcContact.setName(body.getName());
            igcContact.setIp(body.getIp());
            igcContact.setFax(body.getFax());
            igcContact.setEmailId(body.getEmailId());
            igcContact.setDesignation(body.getDesignation());
            igcContact.setAddress(body.getAddress());
            igcContact.setPhone(body.getPhone());

            return contactsrepo.save(igcContact);
        } else
            throw new RuntimeException("IGC contact not found ");
    }



    // 5.Save IGC Documents
    public <json> EncryptedResponse saveManageIGCdocs(ManageIGCdocs body) throws Exception {
        UUID uuid = UUID.randomUUID();
        var photoPathTenth = fileServerPath + "document" + uuid + ".pdf";
        File fileTenth = new File(photoPathTenth);
        byte[] docUpload = Base64.getDecoder().decode(body.getUploadDocument().split(",")[1]);

        FileValidator.validateFileSize(docUpload, 5);
        try {

            ManageIGCdocs igcDocs = new ManageIGCdocs();
            igcDocs.setDocumentType(body.getDocumentType());
            igcDocs.setDocumentTitle(body.getDocumentTitle());
            igcDocs.setAccessibility(body.getAccessibility());
            igcDocs.setUploadDate(body.getUploadDate());//lastModifiedDate
            igcDocs.setFileName(body.getFileName());
            try (OutputStream stream = FileUtils.openOutputStream(fileTenth)) {
                stream.write(docUpload);
                igcDocs.setUploadDocument(uuid.toString());
            }
            docsrepo.save(igcDocs);
            System.out.println(igcDocs);

            return new EncryptedResponse("Document saved successfully");
        } catch (Exception e) {
            return new EncryptedResponse("Error saving document");
        }
    }

    // 6. Saving IGC photographs
    @Transactional
    public <json> EncryptedResponse saveManageIGCphotos(ManageIGCphotos body) throws Exception {

        UUID uuid = UUID.randomUUID();
        // Long id = body.getId();

        // Optional<ManageRecentDocs> savedObj = managerecentdocsrepo.findById(id);

        var photoPathTenth = fileServerPath + "photo" + uuid;
        File fileTenth = new File(photoPathTenth);
        byte[] picUpload = Base64.getDecoder().decode(body.getUploadPhoto().split(",")[1]);
        FileValidator.validateFileSize(picUpload, 5);

        // if (savedObj.isPresent()) {
        // try {
        // ManageRecentDocs existingDetails = savedObj.get();

        // try (OutputStream stream = FileUtils.openOutputStream(fileTenth))
        // {
        // stream.write(docUpload);
        // existingDetails.setUploadDocument(uuid.toString());
        // }
        // existingDetails.setId((body.getId()));
        // existingDetails.setTitle(body.getTitle());
        // existingDetails.setSecurityGroup(body.getSecurityGroup());
        // existingDetails.setType(body.getType());
        // existingDetails.setDocumentType(body.getDocumentType());
        // existingDetails.setDescription(body.getDescription());
        // existingDetails.setStatus(body.getStatus());
        // existingDetails.setReceivedDate(body.getReceivedDate());
        // existingDetails.setRegion(body.getRegion());

        // managerecentdocsrepo.save(existingDetails);

        // return new EncryptedResponse("Document uploaded");
        // } catch (Exception e) {
        // return new EncryptedResponse("some error occured");
        // }
        // } else {
        try {

            ManageIGCphotos newIGCphotos = new ManageIGCphotos();

            newIGCphotos.setPhotoCaption((body.getPhotoCaption()));
            newIGCphotos.setUploadType(body.getUploadType());
            newIGCphotos.setReceivedDate(body.getReceivedDate());
            newIGCphotos.setPhotoSource(body.getPhotoSource());
            newIGCphotos.setUploadPhoto(body.getUploadPhoto());
            newIGCphotos.setFileName(body.getFileName());
            try (OutputStream stream = FileUtils.openOutputStream(fileTenth)) {
                stream.write(picUpload);
                newIGCphotos.setUploadPhoto(uuid.toString());
            }
            photosrepo.save(newIGCphotos);

            return new EncryptedResponse("Photos saved successfully");

        } catch (Exception e) {
            return new EncryptedResponse("Error saving Photo");
        }
    }

    // 7. view All IGC photos
    @Transactional
    public List<ManageIGCphotos> getAllIGCphotos(PageRequest page) {
        return photosrepo.findAll();
    }

    //8. Delete IGC Photo
    @Transactional
    public void deleteIGCphoto(ManageIGCphotos body) {
        Long id = body.getId();
        photosrepo.deleteById(id);
    }

    //9. Edit IGC photo
    @Transactional
    public ManageIGCphotos editIGCphoto(ManageIGCphotos body) {
        Long id = body.getId();
        Optional<ManageIGCphotos> optionalphoto = photosrepo.findById(id);

        if (optionalphoto.isPresent()) {
            ManageIGCphotos igcphoto = optionalphoto.get();
            igcphoto.setPhotoCaption(body.getPhotoCaption());
            igcphoto.setPhotoSource(body.getPhotoSource());
            igcphoto.setUploadType(body.getUploadType());
            return photosrepo.save(igcphoto);
        } else
            throw new RuntimeException("Photo not found ");
    }

}
