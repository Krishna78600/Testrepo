package org.bisag.ocbis.payloads.request;

public record CFPI(String tblname, String cfpi_wkt, String cfpi_range) {}
