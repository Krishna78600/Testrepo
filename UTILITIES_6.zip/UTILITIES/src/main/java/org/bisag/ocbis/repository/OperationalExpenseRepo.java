package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.OperationalExpense;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OperationalExpenseRepo extends JpaRepository<OperationalExpense, Long> {

   
    
}
