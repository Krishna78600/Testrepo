package org.bisag.ocbis.controllers;

import java.io.File;
import java.io.OutputStream;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.bisag.ocbis.models.Commodity;
import org.bisag.ocbis.models.ConsumableItem;
import org.bisag.ocbis.models.CreateFsp;
import org.bisag.ocbis.models.FspApprove;
import org.bisag.ocbis.models.LithologyZone;
import org.bisag.ocbis.models.NonConsumableItem;
import org.bisag.ocbis.models.OperationalExpense;
import org.bisag.ocbis.models.QualitativeTargetsAnalysisType;
import org.bisag.ocbis.models.QualitativeTargetsSubTask;
import org.bisag.ocbis.models.QualitativeTargetsTask;
import org.bisag.ocbis.models.SampleQuantService;
import org.bisag.ocbis.models.User;
import org.bisag.ocbis.models.Vehicle;
import org.bisag.ocbis.payloads.request.DrillRequest;
import org.bisag.ocbis.payloads.request.EncryptedRequest;
import org.bisag.ocbis.payloads.request.OperationalExpenseRequest;
import org.bisag.ocbis.payloads.request.QuantServiceLabRequest;
import org.bisag.ocbis.payloads.request.VehicleRequest;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.CommodityRepo;
import org.bisag.ocbis.repository.ConsumableItemRepo;
import org.bisag.ocbis.repository.FSPGeoDataRepository;
import org.bisag.ocbis.repository.FspApproveRepo;
import org.bisag.ocbis.repository.FspRepo;
import org.bisag.ocbis.repository.LithologyZoneRepo;
import org.bisag.ocbis.repository.NonConsumableItemRepo;
import org.bisag.ocbis.repository.OperationalExpenseRepo;
import org.bisag.ocbis.repository.QualitativeTargetsAnalysisTypeRepo;
import org.bisag.ocbis.repository.QualitativeTargetsSubTaskRepo;
import org.bisag.ocbis.repository.QualitativeTargetsTaskRepo;
import org.bisag.ocbis.repository.SampleQuantServiceRepo;
import org.bisag.ocbis.repository.VehicleRepo;
import org.bisag.ocbis.utils.FileValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@RestController
@CrossOrigin("*")
@RequestMapping("/createfsp")
public class CreateFspController {

  @Value("${fileServerPath}")
  String fileServerPath;

  @Autowired
  FspRepo fsprepo;

  @Autowired
  FspApproveRepo fspApproveRepo;

  @Autowired
  VehicleRepo vehicleRepo;

  @Autowired
  OperationalExpenseRepo operationalExpenseRepo;

  @Autowired
  ConsumableItemRepo consumableItemRepo;

  @Autowired
  NonConsumableItemRepo nonConsumableItemRepo;

  @Autowired
  CommodityRepo commodityRepo;

  @Autowired
  LithologyZoneRepo lithologyZoneRepo;

  @Autowired
  SampleQuantServiceRepo sampleQuantServiceRepo;

  @Autowired
  QualitativeTargetsSubTaskRepo qualitativeTargetsSubTaskRepo;

  @Autowired
  QualitativeTargetsAnalysisTypeRepo qualitativeTargetsAnalysisTypeRepo;
  @Autowired
  QualitativeTargetsTaskRepo qualitativeTargetsTaskRepo;

  @Autowired
  FSPGeoDataRepository geometryRepository;

  @PostMapping("/save-fsp")
  public <json> EncryptedResponse saveFspDetail(
      @Valid @RequestBody EncryptedRequest req, @AuthenticationPrincipal User user) throws Exception {
    var body = req.bodyAs(CreateFsp.class);
    System.out.println("firstApprovingAuthorityName" + body.getFirstApprovingAuthorityName());
    System.out.println("parentMissionCode" + body.getParentMissionCode());
    System.out.println("subMissionCode" + body.getSubMissionCode());
    System.out.println("formId" + body.getId());

    CreateFsp savedBody = null;

    Map<String, Object> responseMap = new HashMap<>();
    try {
      body.setStepsCompleted(body.getStepsCompleted());
      body.setCreateFspDate(ZonedDateTime.now());
      if (body.getId() != null) {
        savedBody = fsprepo.save(body);
      } else {
        CreateFsp existing = fsprepo.findByFormId(body.getId());
        existing.setMissionName(body.getMissionName());
        existing.setSubMissionName(body.getSubMissionName());
        existing.setThemeName(body.getThemeName());
        existing.setTypeCode(body.getTypeCode());
        existing.setCommercialCode(body.getCommercialCode());
        existing.setRegionName(body.getRegionName());
        existing.setStateUnitName(body.getStateUnitName());
        existing.setYearOfInitiation(body.getYearOfInitiation());
        existing.setYearOfCompletion(body.getYearOfCompletion());
        existing.setFirstApprovingAuthority(body.getFirstApprovingAuthority());
        existing.setFieldSeasonYear(body.getFieldSeasonYear());
        existing.setProposalId(body.getProposalId());
        existing.setUserId(user.getId());
        savedBody = fsprepo.save(existing);

      }

      System.out.println("called outside entry");

      FspApprove fspApprove = fspApproveRepo.findByFormId(body.getId());

      if (savedBody != null && fspApprove != null) {

        // Update the existing entry
        fspApprove.setCreateFspUserId(user.getId());
        fspApprove.setProposalId(body.getProposalId());
        fspApprove.setFspFormId(savedBody.getId());
        fspApprove.setFirstApprovingAuthorityName(body.getFirstApprovingAuthorityName());
        fspApprove.setParentMissionCode(body.getParentMissionCode());
        fspApprove.setSubMissionCode(body.getSubMissionCode());
      } else {

        // Create a new entry
        fspApprove = new FspApprove();
        fspApprove.setCreateFspUserId(user.getId());
        fspApprove.setProposalId(body.getProposalId());
        fspApprove.setFspFormId(savedBody.getId());
        fspApprove.setFirstApprovingAuthorityName(body.getFirstApprovingAuthorityName());
        fspApprove.setParentMissionCode(body.getParentMissionCode());
        fspApprove.setSubMissionCode(body.getSubMissionCode());
      }

      fspApproveRepo.save(fspApprove);

      responseMap.put("id", savedBody.getId());
      responseMap.put("proposalId", savedBody.getProposalId());
      responseMap.put("message", "success");

    } catch (Exception e) {
      return new EncryptedResponse(e);
    }
    return new EncryptedResponse(responseMap);
  }

  @Transactional
  @PostMapping("/save-season-program-details")
  public <json> EncryptedResponse saveSeasonProgramDetail(@RequestBody EncryptedRequest req, HttpServletRequest request,
      @AuthenticationPrincipal User user)
      throws Exception {
    CreateFsp body = req.bodyAs(CreateFsp.class);

    UUID uuid = UUID.randomUUID();

    Long id = body.getId();
    Optional<CreateFsp> savedObj = fsprepo.findById(id);

    var pdfPathTenth = fileServerPath + "/documents/" + uuid + ".pdf";
    File fileTenth = new File(pdfPathTenth);
    byte[] backgroundInfoBytes = Base64.getDecoder().decode(body.getBackgroundInfo().split(",")[1]);
    FileValidator.validateFileSize(backgroundInfoBytes, 5);

    if (savedObj.isPresent()) {
      try {
        CreateFsp exisitingFspDetails = savedObj.get();
        commodityRepo.deleteByFspFormId(exisitingFspDetails.getId());

        Commodity[] commodities = body.getCommodity();
        if (commodities != null && commodities.length > 0) {
          for (Commodity commodity : commodities) {
            Commodity commodityDetails = new Commodity();
            commodityDetails.setFspFormId(exisitingFspDetails.getId());
            commodityDetails.setProposalId(body.getProposalId());
            commodityDetails.setFspCommodityName(commodity.getFspCommodityName());
            commodityDetails.setFspSubCommodityName(commodity.getFspSubCommodityName());
            commodityDetails.setFspMineralType(commodity.getFspMineralType());
            commodityRepo.save(commodityDetails);
          }
        }

        try (OutputStream stream = FileUtils.openOutputStream(fileTenth)) {
          stream.write(backgroundInfoBytes);
          exisitingFspDetails.setBackgroundInfo(uuid.toString());
        }
        exisitingFspDetails.setUserId(body.getUserId());
        exisitingFspDetails.setFspTitle(body.getFspTitle());
        exisitingFspDetails.setCommodityName(body.getCommodityName());
        exisitingFspDetails.setFspStartDate(body.getFspStartDate());
        exisitingFspDetails.setFspItemType(body.getFspItemType());
        exisitingFspDetails.setFspAreaType(body.getFspAreaType());
        exisitingFspDetails.setFspDurationItem(body.getFspDurationItem());
        exisitingFspDetails.setFspItemFundedby(body.getFspItemFundedby());
        exisitingFspDetails.setFspItemFundedbyName(body.getFspItemFundedbyName());
        exisitingFspDetails.setFspItemRecommByCgpb(body.getFspItemRecommByCgpb());
        exisitingFspDetails.setFspCgpbCommitieeList(body.getFspCgpbCommitieeList());
        exisitingFspDetails.setFspItemRecommBySgpb(body.getFspItemRecommBySgpb());
        exisitingFspDetails.setFspStateListBySgpb(body.getFspStateListBySgpb());
        exisitingFspDetails.setFspKeyWords(body.getFspKeyWords());
        exisitingFspDetails.setFspStageOfInvestigation(body.getFspStageOfInvestigation());
        exisitingFspDetails.setFspCoOwner(body.getFspCoOwner());
        exisitingFspDetails.setFspCoOwnerStream(body.getFspCoOwnerStream());
        exisitingFspDetails.setFspSpinOfOtherItem(body.getFspSpinOfOtherItem());
        exisitingFspDetails.setFspSpinOfCategory(body.getFspSpinOfCategory());
        exisitingFspDetails.setFspSpinOfFspItem(body.getFspSpinOfFspItem());
        exisitingFspDetails.setFspCoverdByGcm(body.getFspCoverdByGcm());
        exisitingFspDetails.setFspCoverdByGpm(body.getFspCoverdByGpm());
        exisitingFspDetails.setFspCoverdByNagmp(body.getFspCoverdByNagmp());
        exisitingFspDetails.setFspCollaborativeItem(body.getFspCollaborativeItem());
        exisitingFspDetails.setFspCollaborativeAgencyBox(body.getFspCollaborativeAgencyBox());
        exisitingFspDetails.setFspSponsoredItem(body.getFspSponsoredItem());
        exisitingFspDetails.setFspSponsoredAgencyBox(body.getFspSponsoredAgencyBox());
        exisitingFspDetails.setFspObjective(body.getFspObjective());
        exisitingFspDetails.setStepsCompleted(body.getStepsCompleted());
        exisitingFspDetails.setFspDetailDate(ZonedDateTime.now());
        exisitingFspDetails.setUserId(user.getId());
        fsprepo.save(exisitingFspDetails);

        return new EncryptedResponse("saved successfully");
      } catch (Exception e) {
        System.out.println("caught error");
        e.printStackTrace();
        return new EncryptedResponse("false");
      }

    }

    return new EncryptedResponse("saved successfully");
  }

  @Transactional
  @PostMapping("save-participating-unit")
  public <json> EncryptedResponse saveSeasonProgramDetail(@RequestBody EncryptedRequest req,
      @AuthenticationPrincipal User user) throws Exception {

    CreateFsp body = req.bodyAs(CreateFsp.class);
    Long id = body.getId();
    Optional<CreateFsp> savedObj = fsprepo.findById(id);

    if (savedObj.isPresent()) {
      try {
        CreateFsp existingFspDetails = savedObj.get();
        existingFspDetails.setPuRegion(body.getPuRegion());
        existingFspDetails.setPuStateUnit(body.getPuStateUnit());
        existingFspDetails.setPuDivision(body.getPuDivision());
        existingFspDetails.setPuPersonnelStreams(body.getPuPersonnelStreams());
        existingFspDetails.setPuFullOrPartTime(body.getPuFullOrPartTime());
        existingFspDetails.setPuPersonType(body.getPuPersonType());
        existingFspDetails.setPuPersonType(body.getPuPersonType());

        existingFspDetails.setStepsCompleted(body.getStepsCompleted());
        existingFspDetails.setPuCreatedDate(ZonedDateTime.now());
        existingFspDetails.setUserId(user.getId());
        fsprepo.save(existingFspDetails);
        return new EncryptedResponse("saved successfully");

      } catch (Exception e) {
        return new EncryptedResponse("false");
      }
    }
    return new EncryptedResponse("saved successfully");
  }

  @Transactional
  @PostMapping("/save-drill-unit")
  public EncryptedResponse saveDrill(@Valid @RequestBody EncryptedRequest req,
      HttpServletRequest request, @AuthenticationPrincipal User user)
      throws Exception {
    try {
      DrillRequest body = req.bodyAs(DrillRequest.class);
      List<LithologyZone> litholodyZones = new ArrayList<>();

      String block = body.block();
      String otherBlock = body.otherBlock();
      Integer area = body.area();
      Integer altitude = body.altitude();
      String condition = body.terrainConditions();
      Integer headName = body.nearestRailHeadName();
      String distance = body.railHeadDistance();
      String waterSource = body.waterSourceType();
      String clearance = body.clearanceReceivedfrom();
      String drilling = body.quantumOfDrilling();
      Integer boreholes = body.numberOfBoreholes();
      Integer boreholesAngle = body.boreHolesAngle();
      String boreholesSpacing = body.boreHoleSpacing();
      Integer boreSize = body.boreSize();
      Integer boreholesRange = body.estimatedBoreholeDepthRange();
      String pattern = body.pattern();
      String patternText = body.patternText();
      String coreRecoveryMineralised = body.coreRecoveryMineralised();
      String coreRecoveryFormations = body.coreRecoveryFormations();
      String geophysicalBhlog = body.geophysicalBhlog();
      String geophysicalBhlogNumber = body.geophysicalBhlogNumber();
      String typeOfDrilling = body.typeOfDrilling();
      String drillingBy = body.drillingBy();
      String otherDrillingBy = body.otherDrillingBy();

      CreateFsp drillUnit = fsprepo.findByFormId(body.fspFormId());
      System.out.println("Drill :" + body.fspFormId());

      drillUnit.setBlock(block);
      drillUnit.setOtherBlock(otherBlock);
      drillUnit.setArea(area);
      drillUnit.setAltitude(altitude);
      drillUnit.setTerrainConditions(condition);
      drillUnit.setNearestRailHeadName(headName);
      drillUnit.setRailHeadDistance(distance);
      drillUnit.setWaterSourceType(waterSource);
      drillUnit.setClearanceReceivedFrom(clearance);
      drillUnit.setQuantumOfDrilling(drilling);
      drillUnit.setNumberOfBoreholes(boreholes);
      drillUnit.setBoreHolesAngle(boreholesAngle);
      drillUnit.setBoreHoleSpacing(boreholesSpacing);
      drillUnit.setBoreSize(boreSize);
      drillUnit.setEstimatedBoreholeDepthRange(boreholesRange);
      drillUnit.setPattern(pattern);
      drillUnit.setPattern(pattern);
      drillUnit.setPatternText(patternText);
      drillUnit.setCoreRecoveryFormations(coreRecoveryFormations);
      drillUnit.setCoreRecoveryMineralised(coreRecoveryMineralised);
      drillUnit.setGeophysicalBhlog(geophysicalBhlog);
      drillUnit.setGeophysicalBhlogNumber(geophysicalBhlogNumber);
      drillUnit.setTypeOfDrilling(typeOfDrilling);
      drillUnit.setDrillingBy(drillingBy);
      drillUnit.setOtherDrillingBy(otherDrillingBy);
      drillUnit.setStepsCompleted(body.stepsCompleted());

      drillUnit.setDrillCreatedDate(ZonedDateTime.now());
      drillUnit.setUserId(user.getId());

      fsprepo.save(drillUnit);
      lithologyZoneRepo.deleteByFspFormId(body.fspFormId());

      if (litholodyZones != null || !litholodyZones.isEmpty()) {
        for (LithologyZone lithologyData : body.lithology()) {
          LithologyZone lithologys = new LithologyZone();
          lithologys.setProposalId(body.proposalId());
          lithologys.setFspFormId(body.fspFormId());
          lithologys.setRockCharacteristics(lithologyData.getRockCharacteristics());
          lithologys.setRockTypes(lithologyData.getRockTypes());
          lithologys.setOtherRockCharacteristics(lithologyData.getOtherRockCharacteristics());
          lithologys.setOtherRockTypes(lithologyData.getOtherRockTypes());
          lithologys.setDepth(lithologyData.getDepth());

          litholodyZones.add(lithologys);
        }
        lithologyZoneRepo.saveAll(litholodyZones);

      }
    } catch (Exception e) {
      return new EncryptedResponse(e);
    }
    return new EncryptedResponse("Saved");
  }


  @Transactional
  @PostMapping("/save-vehicle")
  public EncryptedResponse saveVehicle(@Valid @RequestBody EncryptedRequest req,
      HttpServletRequest request, @AuthenticationPrincipal User user) throws Exception {

    VehicleRequest body = req.bodyAs(VehicleRequest.class);
    List<Vehicle> vehicles = new ArrayList<>();
    CreateFsp createFsp = fsprepo.findByFormId(body.fspFormId());

    try {
      // First, delete existing vehicles for this fspFormId to avoid duplicates
      vehicleRepo.deleteByFspFormId(body.fspFormId());

      if (body.vehicles() != null && !body.vehicles().isEmpty()) {
        for (Vehicle vehicleData : body.vehicles()) {
          Vehicle vehicle = new Vehicle();

          vehicle.setProposalId(body.proposalId());
          vehicle.setVehicleType(vehicleData.getVehicleType());
          vehicle.setOtherVehicleType(vehicleData.getOtherVehicleType());
          vehicle.setQuantity(vehicleData.getQuantity());
          vehicle.setTentativeKm(vehicleData.getTentativeKm());
          vehicle.setApr(vehicleData.getApr());
          vehicle.setMay(vehicleData.getMay());
          vehicle.setJun(vehicleData.getJun());
          vehicle.setJul(vehicleData.getJul());
          vehicle.setAug(vehicleData.getAug());
          vehicle.setSep(vehicleData.getSep());
          vehicle.setOct(vehicleData.getOct());
          vehicle.setNov(vehicleData.getNov());
          vehicle.setDec(vehicleData.getDec());
          vehicle.setJan(vehicleData.getJan());
          vehicle.setFeb(vehicleData.getFeb());
          vehicle.setMar(vehicleData.getMar());
          vehicle.setFspFormId(body.fspFormId());

          vehicles.add(vehicle);
        }

        vehicleRepo.saveAll(vehicles);
      }

      createFsp.setStepsCompleted(body.stepsCompleted());
      createFsp.setVehicleCreatedDate(ZonedDateTime.now());
      createFsp.setUserId(user.getId());
      fsprepo.save(createFsp);

    } catch (Exception e) {
      return new EncryptedResponse(e);
    }
    return new EncryptedResponse("Saved");
  }

  
  @Transactional
  @PostMapping("/save-course-details")
  public EncryptedResponse saveCourseDetails(@Valid @RequestBody EncryptedRequest req,
      @AuthenticationPrincipal User user) throws Exception {

    CreateFsp body = req.bodyAs(CreateFsp.class);
    body.setStepsCompleted(body.getStepsCompleted());
    Long id = body.getId();
    Optional<CreateFsp> savedObj = fsprepo.findById(id);

    if (savedObj.isPresent()) {
      try {
        CreateFsp existingCuDetails = savedObj.get();

        existingCuDetails.setCuCourseId(body.getCuCourseId());
        existingCuDetails.setCuCourseSubType(body.getCuCourseSubType());
        existingCuDetails.setCuSelfNomination(body.getCuSelfNomination());
        existingCuDetails.setCuCourseSubTypeOther(body.getCuCourseSubTypeOther());
        existingCuDetails.setCuOrganisedFor(body.getCuOrganisedFor());
        existingCuDetails.setCuProposedStartDate(body.getCuProposedStartDate());
        existingCuDetails.setCuProposedEndDate(body.getCuProposedEndDate());
        existingCuDetails.setCuDurationOfCourse(body.getCuDurationOfCourse());
        existingCuDetails.setCuBackgroundInfo(body.getCuBackgroundInfo());
        existingCuDetails.setCuObjective(body.getCuObjective());
        existingCuDetails.setCuFundingAgencyName(body.getCuFundingAgencyName());
        existingCuDetails.setCuMinimumNumberOfPeople(body.getCuMinimumNumberOfPeople());
        existingCuDetails.setCuNumberOfCoreFaculty(body.getCuNumberOfCoreFaculty());
        existingCuDetails.setCuNumberOfGuestFaculty(body.getCuNumberOfGuestFaculty());
        existingCuDetails.setCuCourseCoordinatorEmployeeId(body.getCuCourseCoordinatorEmployeeId());
        existingCuDetails.setCuVehicleBudget(body.getCuVehicleBudget());
        existingCuDetails.setCuLogisticsBudget(body.getCuLogisticsBudget());
        existingCuDetails.setCuOtherBudget(body.getCuOtherBudget());
        existingCuDetails.setCuCourseContent(body.getCuCourseContent());

        existingCuDetails.setStepsCompleted(body.getStepsCompleted());
        existingCuDetails.setCourseCreatedDate(ZonedDateTime.now());
        existingCuDetails.setUserId(user.getId());

        fsprepo.save(existingCuDetails);
        return new EncryptedResponse("saved successfully");

      } catch (Exception e) {
        return new EncryptedResponse("false");
      }
    }

    return new EncryptedResponse("saved");
  }

  @Transactional
  @PostMapping("/save-operational")
  public EncryptedResponse saveOperation(@Valid @RequestBody EncryptedRequest req,
      HttpServletRequest request, @AuthenticationPrincipal User user)
      throws Exception {
    OperationalExpenseRequest body = req.bodyAs(OperationalExpenseRequest.class);
    System.out.println("nullllllllllllll" + body.fspFormId());

    List<OperationalExpense> operationalExpenses = new ArrayList<>();
    List<ConsumableItem> consumableItems = new ArrayList<>();
    List<NonConsumableItem> nonConsumableItems = new ArrayList<>();
    CreateFsp createFsp = fsprepo.findByFormId(body.fspFormId());
    try {

      if (operationalExpenses != null || !operationalExpenses.isEmpty()) {
        for (OperationalExpense data : body.expenses()) {
          OperationalExpense op = new OperationalExpense();
          System.out.println("body.fspFormId() " + body.fspFormId());
          op.setProposalId(body.proposalId());
          op.setFspFormId(body.fspFormId());
          op.setExpenseHead(data.getExpenseHead());
          op.setExpenseType(data.getExpenseType());
          op.setQtr1(data.getQtr1());
          op.setQtr2(data.getQtr2());
          op.setQtr3(data.getQtr3());
          op.setQtr4(data.getQtr4());
          op.setBudget(data.getBudget());

          operationalExpenses.add(op);
        }
        operationalExpenseRepo.saveAll(operationalExpenses);
      }
      if (consumableItems != null || !consumableItems.isEmpty()) {
        for (ConsumableItem consumableItemData : body.consumableItems()) {
          ConsumableItem consumableItem = new ConsumableItem();
          consumableItem.setProposalId(body.proposalId());
          consumableItem.setFspFormId(body.fspFormId());
          consumableItem.setConsumableItemTypes(consumableItemData.getConsumableItemTypes());
          consumableItem.setConsumableQuantity(consumableItemData.getConsumableQuantity());
          consumableItem.setItemExpense(consumableItemData.getItemExpense());
          consumableItem.setConsumableTotal(consumableItemData.getConsumableTotal());
          consumableItems.add(consumableItem);
        }

        consumableItemRepo.saveAll(consumableItems);
      }
      if (nonConsumableItems != null || !nonConsumableItems.isEmpty()) {
        for (NonConsumableItem nonConsumableItemData : body.nonConsumableItems()) {

          NonConsumableItem nonConsumableItem = new NonConsumableItem();
          nonConsumableItem.setProposalId(body.proposalId());
          nonConsumableItem.setFspFormId(body.fspFormId());
          nonConsumableItem.setOperationalNonConsumable(nonConsumableItemData.getOperationalNonConsumable());
          nonConsumableItem.setNonConsumableQuantity(nonConsumableItemData.getNonConsumableQuantity());
          nonConsumableItem.setUnitPrice(nonConsumableItemData.getUnitPrice());
          nonConsumableItem.setNonConsumableTotal(nonConsumableItemData.getNonConsumableTotal());

          nonConsumableItems.add(nonConsumableItem);
        }

        nonConsumableItemRepo.saveAll(nonConsumableItems);
      }
      createFsp.setStepsCompleted(body.stepsCompleted());
      createFsp.setOperationCreatedDate(ZonedDateTime.now());
      createFsp.setUserId(user.getId());

      fsprepo.save(createFsp);
    } catch (Exception e) {
      return new EncryptedResponse(e);
    }
    return new EncryptedResponse("Saved");

  }

  @Transactional
  @PostMapping("/save-quant-service-lab")
  public EncryptedResponse saveQuantServiceLab(@Valid @RequestBody EncryptedRequest req,
      HttpServletRequest request) throws Exception {
    QuantServiceLabRequest body = req.bodyAs(QuantServiceLabRequest.class);

    try {
      // Delete existing records for this fspFormId
      sampleQuantServiceRepo.deleteByFspFormId(body.fspFormId());
      qualitativeTargetsTaskRepo.deleteByFspFormId(body.fspFormId());
      qualitativeTargetsSubTaskRepo.deleteByFspFormId(body.fspFormId());
      qualitativeTargetsAnalysisTypeRepo.deleteByFspFormId(body.fspFormId());

      // Sample Quant Service
      List<SampleQuantService> sampleQuantService = new ArrayList<>();

      if (body.sampleQuantAndService() != null) {
        sampleQuantService = body.sampleQuantAndService().stream()
            .map(quantServiceData -> {
              SampleQuantService qs = new SampleQuantService();
              qs.setProposalId(body.proposalId());
              qs.setFspFormId(body.fspFormId());
              qs.setSampleQuantAndServiceActivityType(quantServiceData.getSampleQuantAndServiceActivityType());
              qs.setSampleQuantAndServiceActivityName(quantServiceData.getSampleQuantAndServiceActivityName());
              qs.setSampleQuantAndServiceElements(quantServiceData.getSampleQuantAndServiceElements());
              qs.setSampleQuantAndServiceSampleTarget(quantServiceData.getSampleQuantAndServiceSampleTarget());
              qs.setSampleQuantAndServiceTotalWorkload(quantServiceData.getSampleQuantAndServiceTotalWorkload());
              qs.setSampleQuantAndServiceWorkCompleted(quantServiceData.getSampleQuantAndServiceWorkCompleted());
              return qs;
            })
            .collect(Collectors.toList());
      }

      if (!sampleQuantService.isEmpty()) {
        sampleQuantServiceRepo.saveAll(sampleQuantService);
      }

      // Qualitative Targets
      List<Map<String, Object>> qualitativeTargetsData = body.qualitativeTargets();
      if (qualitativeTargetsData != null && !qualitativeTargetsData.isEmpty()) {
        List<QualitativeTargetsTask> tasks = new ArrayList<>();
        List<QualitativeTargetsSubTask> subTasks = new ArrayList<>();
        List<QualitativeTargetsAnalysisType> analysisTypes = new ArrayList<>();

        // Process tasks first
        for (Map<String, Object> targetData : qualitativeTargetsData) {
          List<String> taskList = (List<String>) targetData.get("task");
          for (String task : taskList) {
            QualitativeTargetsTask taskEntity = new QualitativeTargetsTask();
            taskEntity.setProposalId(body.proposalId());
            taskEntity.setTask(task);
            taskEntity.setFspFormId(body.fspFormId());
            tasks.add(taskEntity);
          }
        }
        tasks = qualitativeTargetsTaskRepo.saveAll(tasks);

        // Process sub-tasks and analysis types
        int taskIndex = 0;
        for (Map<String, Object> targetData : qualitativeTargetsData) {
          List<String> taskList = (List<String>) targetData.get("task");
          for (String task : taskList) {
            QualitativeTargetsTask taskEntity = tasks.get(taskIndex);
            Long taskId = taskEntity.getId();

            // Analysis types
            List<String> analysisTypesList = (List<String>) targetData.get("analysisTypes");
            if (analysisTypesList != null) {
              for (String analysisType : analysisTypesList) {
                QualitativeTargetsAnalysisType analysis = new QualitativeTargetsAnalysisType();
                analysis.setProposalId(body.proposalId());
                analysis.setAnalysisType(analysisType);
                analysis.setTaskId(taskId);
                analysis.setFspFormId(body.fspFormId());
                analysisTypes.add(analysis);
              }
            }

            // Sub-tasks
            List<Map<String, Object>> subTasksList = (List<Map<String, Object>>) targetData.get("subTasks");
            if (subTasksList != null) {
              for (Map<String, Object> subTaskData : subTasksList) {
                QualitativeTargetsSubTask subTask = new QualitativeTargetsSubTask();
                subTask.setProposalId(body.proposalId());
                subTask.setLabName((String) subTaskData.get("labName"));
                subTask.setSubTask((String) subTaskData.get("subTask"));
                subTask.setTarget((Integer) subTaskData.get("target"));
                subTask.setTimelineFrom((String) subTaskData.get("timelineFrom"));
                subTask.setTimelineTo((String) subTaskData.get("timelineTo"));
                subTask.setWorkload((Integer) subTaskData.get("workload"));
                subTask.setTaskId(taskId);
                subTask.setFspFormId(body.fspFormId());
                subTasks.add(subTask);
              }
            }
            taskIndex++;
          }
        }

        if (!subTasks.isEmpty()) {
          qualitativeTargetsSubTaskRepo.saveAll(subTasks);
        }
        if (!analysisTypes.isEmpty()) {
          qualitativeTargetsAnalysisTypeRepo.saveAll(analysisTypes);
        }
      }

      // Update CreateFsp
      CreateFsp createFsp = fsprepo.findByFormId(body.fspFormId());
      updateCreateFsp(createFsp, body);
      fsprepo.save(createFsp);

      return new EncryptedResponse("Saved");
    } catch (Exception e) {
      throw new RuntimeException("Error saving quantitative service lab data: " + e.getMessage(), e);
    }
  }

  private void updateCreateFsp(CreateFsp createfsp, QuantServiceLabRequest body) {
    createfsp.setDecrepitationTestCompleted(body.decrepitationTestCompleted());
    createfsp.setDecrepitationTestWorkload(body.decrepitationTestWorkload());
    createfsp.setWaterSampleTestingTarget(body.waterSampleTestingTarget());
    createfsp.setWaterSampleTestingWorkload(body.waterSampleTestingWorkload());
    createfsp.setWaterSampleTestingCompleted(body.waterSampleTestingCompleted());
    createfsp.setAlterationZoneMappingTarget(body.alterationZoneMappingTarget());
    createfsp.setAlterationZoneMappingWorkload(body.alterationZoneMappingWorkload());
    createfsp.setAlterationZoneMappingCompleted(body.alterationZoneMappingCompleted());
    createfsp.setBedRockSamplingTarget(body.bedRockSamplingTarget());
    createfsp.setBedRockSamplingWorkload(body.bedRockSamplingWorkload());
    createfsp.setBedRockSamplingCompleted(body.bedRockSamplingCompleted());
    createfsp.setBulkSampleingInTonnesTarget(body.bulkSampleingInTonnesTarget());
    createfsp.setBulkSampleingInTonnesWorkload(body.bulkSampleingInTonnesWorkload());
    createfsp.setBulkSampleingInTonnesCompleted(body.bulkSampleingInTonnesCompleted());
    createfsp.setChannelGroupSamplingTarget(body.channelGroupSamplingTarget());
    createfsp.setChannelGroupWorkload(body.channelGroupWorkload());
    createfsp.setChannelGroupCompleted(body.channelGroupCompleted());
    createfsp.setCoalAndAssociatedRockSamplingTarget(body.coalAndAssociatedRockSamplingTarget());
    createfsp.setCoalAndAssociatedRockSamplingWorkload(body.coalAndAssociatedRockSamplingWorkload());
    createfsp.setCoalAndAssociatedRockSamplingCompleted(body.coalAndAssociatedRockSamplingCompleted());
    createfsp.setAirborneGeophysicalDataTarget(body.airborneGeophysicalDataTarget());
    createfsp.setAirborneGeophysicalDataWorkload(body.airborneGeophysicalDataWorkload());
    createfsp.setAirborneGeophysicalDataCompleted(body.airborneGeophysicalDataCompleted());
    createfsp.setBoreholesWithRealwcoTarget(body.boreholesWithRealwcoTarget());
    createfsp.setBoreholesWithRealwcoWorkload(body.boreholesWithRealwcoWorkload());
    createfsp.setBoreholesWithRealwcoCompleted(body.boreholesWithRealwcoCompleted());
    createfsp.setCoalfieldMapTarget(body.coalfieldMapTarget());
    createfsp.setCoalfieldMapWorkload(body.coalfieldMapWorkload());
    createfsp.setCoalfieldMapCompleted(body.coalfieldMapCompleted());
    createfsp.setCompilationOfGeoQuaMapTarget(body.compilationOfGeoQuaMapTarget());
    createfsp.setCompilationOfGeoQuaMapWorkload(body.compilationOfGeoQuaMapWorkload());
    createfsp.setCompilationOfGeoQuaMapCompleted(body.compilationOfGeoQuaMapCompleted());
    createfsp.setAerialReconnaissanceandPGRSstudiesTarget(body.aerialReconnaissanceandPGRSstudiesTarget());
    createfsp.setAerialReconnaissanceandPGRSstudiesWorkload(body.aerialReconnaissanceandPGRSstudiesWorkload());
    createfsp.setAerialReconnaissanceandPGRSstudiesCompleted(body.aerialReconnaissanceandPGRSstudiesCompleted());
    createfsp.setGeologicalboreholesloggingTarget(body.geologicalboreholesloggingTarget());
    createfsp.setGeologicalboreholesloggingWorkload(body.geologicalboreholesloggingWorkload());
    createfsp.setGeologicalboreholesloggingCompleted(body.geologicalboreholesloggingCompleted());
    createfsp.setGlacialSnoutmonitoringTarget(body.glacialSnoutmonitoringTarget());
    createfsp.setGlacialSnoutmonitoringWorkload(body.glacialSnoutmonitoringWorkload());
    createfsp.setGlacialSnoutmonitoringTargetCompleted(body.glacialSnoutmonitoringTargetCompleted());
    createfsp.setMagnetotelluricsurveyTarget(body.magnetotelluricsurveyTarget());
    createfsp.setMagnetotelluricsurveyWorkload(body.magnetotelluricsurveyWorkload());
    createfsp.setMagnetotelluricsurveyCompleted(body.magnetotelluricsurveyCompleted());
    createfsp.setGeophysicalGravityTarget(body.geophysicalGravityTarget());
    createfsp.setGeophysicalGravityWorkload(body.geophysicalGravityWorkload());
    createfsp.setGeophysicalGravityCompleted(body.geophysicalGravityCompleted());
    createfsp.setGeophysicalIpAreaTarget(body.geophysicalIpAreaTarget());
    createfsp.setGeophysicalIpAreaWorkload(body.geophysicalIpAreaWorkload());
    createfsp.setGeophysicalIpAreaCompleted(body.geophysicalIpAreaCompleted());
    createfsp.setBathymetricSurveySingleBeamTarget(body.bathymetricSurveySingleBeamTarget());
    createfsp.setBathymetricSurveySingleBeamWorkload(body.bathymetricSurveySingleBeamWorkload());
    createfsp.setBathymetricSurveySingleBeamCompleted(body.bathymetricSurveySingleBeamCompleted());
    createfsp.setBeachProfilingTarget(body.beachProfilingTarget());
    createfsp.setBeachProfilingWorkload(body.beachProfilingWorkload());
    createfsp.setBeachProfilingCompleted(body.beachProfilingCompleted());
    createfsp.setMappingDetailedMappingTarget(body.mappingDetailedMappingTarget());
    createfsp.setMappingDetailedMappingWorkload(body.mappingDetailedMappingWorkload());
    createfsp.setMappingDetailedMappingCompleted(body.mappingDetailedMappingCompleted());
    createfsp.setMappingGeochemicalMappingTarget(body.mappingGeochemicalMappingTarget());
    createfsp.setMappingGeochemicalMappingWorkload(body.mappingGeochemicalMappingWorkload());
    createfsp.setMappingGeochemicalMappingCompleted(body.mappingGeochemicalMappingCompleted());
    createfsp.setMappingGeologicalMappingRemoteCompleted(
        body.mappingGeologicalMappingRemoteCompleted());
    createfsp.setMappingGeologicalMappingRemoteTarget(
        body.mappingGeologicalMappingRemoteTarget());
    createfsp.setMappingGeologicalMappingRemoteWorkload(
        body.mappingGeologicalMappingRemoteWorkload());
    createfsp.setAugerDrillingTarget(body.augerDrillingTarget());
    createfsp.setAugerDrillingWorkload(body.augerDrillingWorkload());
    createfsp.setAugerDrillingCompleted(body.augerDrillingCompleted());
    createfsp.setTechnologiclDrillingTarget(body.technologiclDrillingTarget());
    createfsp.setTechnologiclDrillingWorkload(body.technologiclDrillingWorkload());
    createfsp.setTechnologiclDrillingCompleted(body.technologiclDrillingCompleted());
    createfsp.setPittingandTrenchingTarget(body.pittingandTrenchingTarget());
    createfsp.setPittingandTrenchingWorkload(body.pittingandTrenchingWorkload());
    createfsp.setPittingandTrenchingCompleted(body.pittingandTrenchingCompleted());
    createfsp.setStandardPenetrationTestingTarget(body.standardPenetrationTestingTarget());
    createfsp.setStandardPenetrationTestingWorkload(body.standardPenetrationTestingWorkload());
    createfsp.setStandardPenetrationTestingCompleted(body.standardPenetrationTestingCompleted());
    createfsp.setDecrepitationTestTarget(body.decrepitationTestTarget());
    createfsp.setStepsCompleted(body.stepsCompleted());
    createfsp.setQuantCreatedDate(ZonedDateTime.now());
  }
}
