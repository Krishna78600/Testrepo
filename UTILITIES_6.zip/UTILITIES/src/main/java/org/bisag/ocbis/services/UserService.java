package org.bisag.ocbis.services;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.text.DecimalFormat;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.bisag.ocbis.exceptions.BadRequestException;
import org.bisag.ocbis.exceptions.ForbiddenException;
import org.bisag.ocbis.models.User;
import org.bisag.ocbis.repository.UserRepository;
import org.bisag.ocbis.security.jwt.Jwt;
import org.bisag.ocbis.security.jwt.JwtActions;
import org.bisag.ocbis.utils.OtpLimiter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import kotlin.text.Regex;

@Service
public class UserService implements UserDetailsService {

  @Autowired
  @Lazy
  AuthenticationManager authenticationManager;

  @Autowired
  JwtActions jwtActions;

  @Autowired
  BCryptPasswordEncoder encoder;

  @Autowired
  UserRepository userRepo;

  @Autowired
  JdbcTemplate jdbcTemplate;

  @Autowired
  OtpLimiter otpLimiter;

  @Value("${spring.profiles.active}")
  private String activeProfile;

  static final String EMAIL_REGEX = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$";
  static final String MOBILE_REGEX = "^(\\+91|0)?[6789]\\d{9}$";
  static final String OTP_REGEX = "^[0-9]{6}$";
  static final String FULL_NAME_REGEX = "^[a-zA-Z\\-\\. ]{1,50}$";
  static final String CAPTCHA_REGEX = "^[0-9a-zA-Z]{6}$";
  static final String CAPTCHA_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

  public void validateEmail(String email) throws Exception {
    if (StringUtils.isBlank(email) || !isValidRegex(email, EMAIL_REGEX)) {
      throw new BadRequestException("Invalid email");
    }
  }

  public void validateMobile(String mobile) throws Exception {
    if (StringUtils.isBlank(mobile) || !isValidRegex(mobile, MOBILE_REGEX)) {
      throw new BadRequestException("Invalid mobile number");
    }
  }

  public void validatePassword(String password) throws Exception {
    if (StringUtils.isBlank(password) || password.length() < 8) {
      throw new BadRequestException("Invalid password");
    }
  }

  public void validateFullName(String fullName) throws Exception {
    if (StringUtils.isBlank(fullName) || !isValidRegex(fullName, FULL_NAME_REGEX)) {
      throw new BadRequestException("Invalid full name");
    }
  }

  public void validateStateDistrict(String stateId, String districtId)
      throws Exception {
    if (StringUtils.isBlank(stateId) || StringUtils.isBlank(districtId)) {
      throw new BadRequestException("Invalid state or district");
    }
  }

  public boolean isValidRegex(String input, String pattern) {
    var regex = new Regex(pattern);
    return regex.matches(input);
  }

  public void verifyOtp(String otp, User user) throws Exception {
    if (StringUtils.isBlank(otp) || !isValidRegex(otp, OTP_REGEX)) {
      throw new BadRequestException("Invalid OTP");
    }
    if (!user.getOtp().equals(otp)) {
      throw new BadRequestException("Incorrect OTP");
    }
  }

  public void verifyCaptcha(String captcha, User user) throws Exception {
    if (StringUtils.isBlank(captcha) || !isValidRegex(captcha, CAPTCHA_REGEX)) {
      throw new BadRequestException("Invalid captcha");
    }
    if (!user.getCaptcha().equals(captcha)) {
      throw new BadRequestException("Incorrect captcha");
    }
  }

  public User authenticateUser(String username, String password)
      throws Exception {
    Authentication authentication = null;
    try {
      System.out.println("User :" + password);
      authentication = authenticationManager
          .authenticate(new UsernamePasswordAuthenticationToken(username, password));
      SecurityContextHolder.getContext().setAuthentication(authentication);
      return userRepo.findFirstByEmail(username);
    } catch (Exception ex) {
      if (ex instanceof DisabledException) {
        throw new ForbiddenException(
            "This account has been disabled. Please contact the administrator.");
      }
      throw new BadRequestException("Invalid credentials");
    }
  }

  public String assignNewCaptcha(User user) {
    String captcha = activeProfile.equals("dev") ? "qwerty" : generateCaptcha(6);
    jdbcTemplate
        .update("UPDATE layer_metadata_users SET captcha = ? WHERE id = ?",
            captcha, user.getId());
    return captcha;
  }

  public String generateJwt(User user, String fp) {
    long now = System.currentTimeMillis();
    System.out.println("username making token: " + user.getEmail());
    String jwt = jwtActions.generate(new Jwt(user.getEmail(), fp, now));
    jdbcTemplate.update("""
        UPDATE layer_metadata_users SET jwt_timestamp = ? WHERE id = ?
        """, now, user.getId());
    return jwt;
  }

  private String generateCaptcha(int captchaLength) {
    StringBuffer captchaBuffer = new StringBuffer();
    Random random = new Random();
    while (captchaBuffer.length() < captchaLength) {
      int index = random.nextInt(CAPTCHA_ALPHABET.length());
      captchaBuffer.append(CAPTCHA_ALPHABET.charAt(index));
    }
    return captchaBuffer.toString();
  }

  public String generateOtp() {
    return activeProfile.equals("dev")
        ? "000000"
        : new DecimalFormat("000000").format(new Random().nextInt(999999));
  }

  public BufferedImage makeCaptchaImage(String captcha, Color textColor) {
    var image = new BufferedImage(IMAGE_WIDTH, IMAGE_HEIGHT, BufferedImage.TYPE_INT_ARGB);
    Graphics2D graphics = image.createGraphics();
    graphics.setRenderingHint(
        RenderingHints.KEY_TEXT_ANTIALIASING,
        RenderingHints.VALUE_TEXT_ANTIALIAS_GASP);
    graphics.setComposite(AlphaComposite.Clear);
    graphics.fillRect(0, 0, IMAGE_WIDTH, IMAGE_HEIGHT);
    graphics.setComposite(AlphaComposite.Src);
    graphics.setFont(FONT);
    graphics.setColor(textColor);
    FontMetrics metrics = graphics.getFontMetrics(FONT);
    int totalTextWidth = 0;
    for (int i = 0; i < captcha.length(); ++i) {
      totalTextWidth += metrics.charWidth(captcha.charAt(i)) + 4;
    }
    int x = (IMAGE_WIDTH - totalTextWidth) / 2;
    int y = (IMAGE_HEIGHT - 20) / 2 + metrics.getHeight() / 2;
    for (int i = 0; i < captcha.length(); ++i) {
      char c = captcha.charAt(i);
      double theta = RANDOM.nextDouble() * 0.6 - 0.3;
      graphics.rotate(theta, x + metrics.charWidth(c) / 2.0, y);
      graphics.setColor(textColor);
      graphics.drawString(String.valueOf(c), x, y);
      x += metrics.charWidth(c) + 4;
      graphics.rotate(-theta, x - metrics.charWidth(c) / 2.0, y);
    }
    graphics.dispose();
    return image;
  }

  private static final Random RANDOM = new Random();
  private static int IMAGE_WIDTH = 0;
  private static int IMAGE_HEIGHT = 0;
  private static final Font FONT = new Font(Font.MONOSPACED, Font.BOLD | Font.ITALIC, 48);
  public static final Color TEXT_COLOR_LIGHT = new Color(255, 255, 255);
  public static final Color TEXT_COLOR_DARK = new Color(54, 64, 79);

  @Override
  public UserDetails loadUserByUsername(String username)
      throws UsernameNotFoundException {
    // User user = userRepo.findFirstByEmail(username);
    User user = userRepo.findFirstByUsername(username);
    if (user == null) {
      throw new UsernameNotFoundException("User not found.");
    }
    return (UserDetails) user;
  }
}
