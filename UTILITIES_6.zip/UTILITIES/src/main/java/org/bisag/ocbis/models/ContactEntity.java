package org.bisag.ocbis.models;


import jakarta.annotation.Nonnull;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name="Contact_Informations")
public class ContactEntity {
    

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long contactId;

    
    @NotNull
    @Column(name="contactname")
    private String contactName;
    @NotNull
    private String designation;
    @NotNull
    private String ipPhone;


   
    public String getContactName() {
        return contactName;
    }
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }
    public String getDesignation() {
        return designation;
    }
    public void setDesignation(String designation) {
        this.designation = designation;
    }
    public String getIpPhone() {
        return ipPhone;
    }
    public void setIpPhone(String ipPhone) {
        this.ipPhone = ipPhone;
    }
   
    public Long getContactId() {
        return contactId;
    }
    public void setContactId(Long contactId) {
        this.contactId = contactId;
    }
    @Override
    public String toString() {
        return "ContactEntity [contactId=" + contactId + ", contactName=" + contactName + ", designation=" + designation
                + ", ipPhone=" + ipPhone + "]";
    }

    
}
