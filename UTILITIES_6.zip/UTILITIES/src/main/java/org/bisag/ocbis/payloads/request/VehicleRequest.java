package org.bisag.ocbis.payloads.request;

import java.util.List;

import org.bisag.ocbis.models.Vehicle;

public record VehicleRequest(Long fspFormId,
     List<Vehicle> vehicles,
     String proposalId , Integer stepsCompleted) {
    
}
