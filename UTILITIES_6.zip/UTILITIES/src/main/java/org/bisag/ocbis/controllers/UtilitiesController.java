package org.bisag.ocbis.controllers;

import java.util.List;

import org.apache.coyote.BadRequestException;
import org.bisag.ocbis.models.ContactEntity;
import org.bisag.ocbis.models.FacultyEntity;
import org.bisag.ocbis.payloads.request.EncryptedRequest;
import org.bisag.ocbis.payloads.request.Report;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.ContactRepo;
import org.bisag.ocbis.repository.FacultyRepo;
import org.bisag.ocbis.services.ContactService;
import org.bisag.ocbis.services.FacultyService;
import org.bisag.ocbis.utils.Json;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.micrometer.common.util.StringUtils;
import jakarta.validation.Valid;

@RestController
@CrossOrigin("*")
@RequestMapping("/utilities")
public class UtilitiesController {

  @Autowired
  private ContactService contactService;

  @Autowired
  private FacultyService facultyService;

  @Autowired
  private FacultyRepo facultyRepo;

  @Autowired
  private ContactRepo contactRepo;

  // Manage Contact
  // ---------------------------------------------------------------------------------------
  // 1-save contact

  @PostMapping("/saveContact")
  public  ResponseEntity<EncryptedResponse> saveContact(
      @Valid @RequestBody EncryptedRequest req) throws Exception {

    try {
     //var reportReq = Json.deserialize(ContactEntity.class, req.getData());
      var body = req.bodyAs(ContactEntity.class);
      contactService.saveContact(body);
      EncryptedResponse response = new EncryptedResponse("contact created successfully");
      return new ResponseEntity<>(response, HttpStatus.CREATED);
    } catch (DataIntegrityViolationException e) {
      return ResponseEntity.status(HttpStatus.BAD_REQUEST)
          .body(new EncryptedResponse("Contact already exists."));
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(new EncryptedResponse("An error occurred."));
    }
  }

  // 1-ViewAll Contacts
  @PostMapping("/viewAllContacts")
  public EncryptedResponse getAllContacts(@RequestBody EncryptedRequest req)
      throws Exception {
    var reportReq = Json.deserialize(Report.class, req.getData());
    // var pagination = ((Report) reportReq).pagination();
    var pageable = PageRequest.of(reportReq.pagination().page(), reportReq.pagination().size());
    var searchQuery = StringUtils.isBlank(reportReq.search()) ? null : "%" + reportReq.search() + "%";
    var custom = reportReq.custom();

    String contactName = StringUtils.isNotBlank((String) custom.get("contactName"))
        ? (String) custom.get("contactName")
        : null;

    String designation = StringUtils.isNotBlank((String) custom.get("designation"))
        ? (String) custom.get("designation")
        : null;

    String ipPhone = StringUtils.isNotBlank((String) custom.get("ipPhone"))
        ? (String) custom.get("ipPhone")
        : null;
    var result = contactRepo.findByFilters(searchQuery, contactName, designation, ipPhone, pageable);

    return new EncryptedResponse(result);
  }

  
  // 1-edit contact
  @PostMapping("/editContactById")
  public <json> EncryptedResponse editContact(@RequestBody EncryptedRequest req)
      throws Exception {
    // Deserialize the request body into an Employee object
    var body = Json.deserialize(ContactEntity.class, req.getData());
    try {
      contactService.updateContact(body, body.getContactId());
      // contactService.updateContact(body.getContactId(),body.null, null)
      // contactRepo.save(body);
      return new EncryptedResponse("updated contact details");
    } catch (DataIntegrityViolationException ex) {
      throw new BadRequestException("contact already exists.");
    }
  }

  @PostMapping("/deleteContactById")
  public <json> EncryptedResponse deleteContact(@RequestBody EncryptedRequest req)
      throws Exception {
    var body = Json.deserialize(ContactEntity.class, req.getData());
    try {
      contactService.deleteContact(body.getContactId());
      // contactService.updateContact(body.getContactId(),body.null, null)
      // contactRepo.save(body);
      return new EncryptedResponse("contact deleted successfully");
    } catch (DataIntegrityViolationException ex) {
      throw new BadRequestException("contact doesn't exists.");
    }
  }

  // Manage Faculty Details
  // --------------------------------------------------------------------------------------------------
  // 2- save faculty

  @PostMapping("/saveFaculty")
  public ResponseEntity<EncryptedResponse> saveFaculty(@RequestBody EncryptedRequest req) throws Exception {
    try {
      var faculty = req.bodyAs(FacultyEntity.class);
      facultyService.saveFaculty(faculty);
      return ResponseEntity.status(HttpStatus.CREATED)
          .body(new EncryptedResponse("Faculty created successfully."));
    } catch (DataIntegrityViolationException e) {
      return ResponseEntity.status(HttpStatus.BAD_REQUEST)
          .body(new EncryptedResponse("Faculty already exists."));
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(new EncryptedResponse("An error occurred."));
    }
  }

  // 2-View All Faculties

    // 2 - View All Employees
    @PostMapping("/viewAllFaculties")
    public <json> EncryptedResponse getAllFaculties(@RequestBody EncryptedRequest req) throws Exception {
      var reportReq = Json.deserialize(Report.class, req.getData());
      // var pagination = ((Report) reportReq).pagination();     
      var pageable = PageRequest.of(reportReq.pagination().page(), reportReq.pagination().size());
      var searchQuery = StringUtils.isBlank(reportReq.search()) ? null : "%" + reportReq.search() + "%";
      var custom = reportReq.custom();
  
      String facultyName = StringUtils.isNotBlank((String) custom.get("facultyName"))
          ? (String) custom.get("facultyName")
          : null;
  
      String designation = StringUtils.isNotBlank((String) custom.get("designation"))
          ? (String) custom.get("designation")
          : null;
  
      String role = StringUtils.isNotBlank((String) custom.get("role"))
          ? (String) custom.get("role")
          : null;

  
      var result = facultyRepo.findByFilters(searchQuery, facultyName, designation, role, pageable);
  
      return new EncryptedResponse(result);
    }

    // 2 - Edit Faculty
   
      // @PostMapping("/editFacultyById")
      // public <json> ResponseEntity<EncryptedResponse> updateFaculty(@RequestBody EncryptedRequest req) throws Exception {
      //     try {
      //         var faculty = Json.deserialize(FacultyEntity.class, req.getData());
      //         facultyService.updateFaculty(faculty.getFacultyId(), faculty);
      //         return ResponseEntity.ok(new EncryptedResponse("Faculty details updated successfully."));
      //     } catch (Exception e) {
      //         return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
      //                 .body(new EncryptedResponse("An error occurred while updating faculty details."));
      //     }
      // }

  //     @PostMapping("/editFacultyById")
  // public <json> EncryptedResponse updateFaculty(@RequestBody EncryptedRequest req)
  //     throws Exception {
  //   // Deserialize the request body into an Employee object
  //   var faculty = Json.deserialize(FacultyEntity.class, req.getData());
  //   try {
  //     facultyService.updateFaculty(faculty.getFacultyId(),faculty);
  //     // contactService.updateContact(body.getContactId(),body.null, null)
  //     // contactRepo.save(body);
  //     return new EncryptedResponse("updated faculty details");
  //   } catch (DataIntegrityViolationException ex) {
  //     throw new BadRequestException("faculty already exists.");
  //   }
  // }

  @PostMapping(value = "/editFacultyById")
  public EncryptedResponse updateFaculty(@RequestBody EncryptedRequest req)
      throws Exception {
    // Deserialize the request body into an Employee object
    var faculty = Json.deserialize(FacultyEntity.class, req.getData());
    System.out.println("upcoming data"+faculty);
    try {
      facultyRepo.save(faculty);
      return new EncryptedResponse("edited");
    } catch (DataIntegrityViolationException ex) {
      throw new BadRequestException("faculty already exists.");
    }

  }

      // 2 - Delete Faculty
      
    @PostMapping("/deleteFacultyById")
    public ResponseEntity<EncryptedResponse> deleteFaculty(@RequestBody EncryptedRequest req) throws Exception {
        try {
            var faculty = Json.deserialize(FacultyEntity.class, req.getData());
            facultyService.deleteFaculty(faculty.getFacultyId());
            return ResponseEntity.ok(new EncryptedResponse("Faculty deleted successfully."));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new EncryptedResponse("An error occurred while deleting the faculty."));
        }
    }

    @PostMapping("/filterFacultyByRole")
    public EncryptedResponse getFacultyByRole(@RequestBody EncryptedRequest req) throws Exception {
        try {
            String role = (String) Json.deserialize(Object.class, req.getData());
            List<FacultyEntity> faculty = facultyService.getFacultyByRole(role);
            return new EncryptedResponse(faculty);
        } catch (Exception e) {
            return new EncryptedResponse("An error occurred while filtering faculty by role.");
        }
    }
}
