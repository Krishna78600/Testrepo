package org.bisag.ocbis.services;

import java.util.List; 

import org.bisag.ocbis.models.ContactEntity;

public interface ContactService {

    ContactEntity saveContact(ContactEntity contact);
    List<ContactEntity> getAllContacts();
    ContactEntity updateContact(ContactEntity contact,Long contactId);
    void deleteContact(Long contactId);

}