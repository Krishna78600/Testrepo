package org.bisag.ocbis.repository;

import java.time.ZonedDateTime;

import org.bisag.ocbis.models.ManageIGCphotos;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ManageIGCphotosRepository extends JpaRepository<ManageIGCphotos, Long>{

    @Query( nativeQuery= true , 
            value = """
                    SELECT * FROM save_igc_photos s
                    WHERE (?1 \\:\\: text IS NULL OR s\\:\\: ILIKE ?1)
                    AND (?2 \\:\\: text IS NULL OR s.photoType = ?2) 
                    AND (?3 \\:\\: text IS NULL OR s.photoTitle = ?3) 
                    AND (?4 \\:\\: text IS NULL OR s.receivedDateFrom >= ?4) 
                    AND (?5 \\:\\: text IS NULL OR s.receivedDateTo <= ?5)
                    ORDER BY id
                   """)
    Page<ManageIGCphotos> findByFilters(String searchQuery, String photoType, String photoTitle,
            ZonedDateTime receivedDateFrom, ZonedDateTime receivedDateTo, PageRequest pageable);

}

