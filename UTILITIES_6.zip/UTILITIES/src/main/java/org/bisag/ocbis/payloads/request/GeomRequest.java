package org.bisag.ocbis.payloads.request;

public record GeomRequest(String geom, Long formId, String proposalId, String topoSheetNumber) {

}
