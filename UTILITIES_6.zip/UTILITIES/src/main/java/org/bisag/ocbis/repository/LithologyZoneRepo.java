package org.bisag.ocbis.repository;

import java.util.List;

import org.bisag.ocbis.models.LithologyZone;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LithologyZoneRepo extends JpaRepository<LithologyZone, Long> {
    void deleteByFspFormId(Long fspFormId);

    List<LithologyZone> findByFspFormId(Long fspFormId);
}
