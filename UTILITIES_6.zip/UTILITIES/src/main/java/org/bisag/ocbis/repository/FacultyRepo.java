package org.bisag.ocbis.repository;

import java.util.List;

import org.bisag.ocbis.models.ContactEntity;
import org.bisag.ocbis.models.FacultyEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface FacultyRepo extends JpaRepository<FacultyEntity,Long>{
      @Query(nativeQuery = true, value = """
        SELECT * FROM faculty_entity f
        WHERE (?1\\:\\:text IS NULL OR f\\:\\:text ILIKE ?1)
      """)
  Page<FacultyEntity> findByFilters(String search, String faculty_name, String designation, String role,Pageable pageable);

  List<FacultyEntity> findByRole(String role);
}


