package org.bisag.ocbis.services;

import org.bisag.ocbis.models.BoreholeEntity;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.BoreholeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoreholeService {

    @Autowired
    BoreholeRepo boreholeRepo;

    public BoreholeEntity saveBoreholeInfo(BoreholeEntity boreholeEntity) {
        return boreholeRepo.save(boreholeEntity);
    }

}
