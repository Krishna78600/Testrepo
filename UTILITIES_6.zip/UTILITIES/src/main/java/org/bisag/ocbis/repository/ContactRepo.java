package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.BoreholeEntity;
import org.bisag.ocbis.models.ContactEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ContactRepo extends JpaRepository<ContactEntity,Long>{
    
     @Query(nativeQuery = true, value = """
        SELECT * FROM Contact_Informations c
        WHERE (?1\\:\\:text IS NULL OR c\\:\\:text ILIKE ?1)
        AND (?2\\:\\:text IS NULL OR c.contactname = ?2)
        AND (?3\\:\\:text IS NULL OR c.designation = ?3)
        AND (?4\\:\\:text IS NULL OR c.ip_phone = ?4)
      """)
  Page<ContactEntity> findByFilters(String search, String contactName, String designation, String ipPhone,Pageable pageable);
}
