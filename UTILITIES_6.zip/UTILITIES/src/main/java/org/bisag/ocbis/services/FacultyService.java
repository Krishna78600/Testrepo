package org.bisag.ocbis.services;

import java.util.List;

import org.bisag.ocbis.models.FacultyEntity;
import org.hibernate.query.Page;
import org.springframework.data.domain.PageRequest;

public interface FacultyService {
    FacultyEntity saveFaculty(FacultyEntity faculty);

    List<FacultyEntity> getAllFaculties(PageRequest pageable);

    FacultyEntity updateFaculty(Long facultyId, FacultyEntity faculty);

    void deleteFaculty(Long facultyId);

    List<FacultyEntity> getFacultyByRole(String role);
}
