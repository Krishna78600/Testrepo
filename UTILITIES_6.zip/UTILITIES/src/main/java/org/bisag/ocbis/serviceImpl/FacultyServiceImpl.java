package org.bisag.ocbis.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.bisag.ocbis.models.FacultyEntity;
import org.bisag.ocbis.repository.FacultyRepo;
import org.bisag.ocbis.services.FacultyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
@Service
public class FacultyServiceImpl implements FacultyService{


    @Autowired
    private FacultyRepo facultyRepo;

    @Override
    public FacultyEntity saveFaculty(FacultyEntity faculty) {
        return facultyRepo.save(faculty);
    }

    @Override
    public List<FacultyEntity> getAllFaculties(PageRequest page) {
        return facultyRepo.findAll();
    }

    @Override
    public FacultyEntity updateFaculty(Long facultyId, FacultyEntity faculty) {
       Optional<FacultyEntity> optionalFaculty = facultyRepo.findById(facultyId);
       if(optionalFaculty.isPresent()){
        FacultyEntity existingFaculty=optionalFaculty.get();
        existingFaculty.setFacultyName(faculty.getFacultyName());
        existingFaculty.setDesignation(faculty.getDesignation());
        return facultyRepo.save(existingFaculty);
    }
       else throw new RuntimeException("Faculty not found with given FacultyId:"+facultyId);
    }

    @Override
    public void deleteFaculty(Long facultyId) {
        facultyRepo.deleteById(facultyId);
    }

    @Override
    public List<FacultyEntity> getFacultyByRole(String role) {
        return facultyRepo.findByRole(role);
    }
    
}
