package org.bisag.ocbis.controllers;

import java.util.List;
import java.util.Map;

import org.bisag.ocbis.models.BoreholeEntity;
import org.bisag.ocbis.payloads.request.EncryptedRequest;
import org.bisag.ocbis.payloads.request.GetId;
import org.bisag.ocbis.payloads.request.Report;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.BoreholeRepo;
import org.bisag.ocbis.repository.UserRepository;
import org.bisag.ocbis.services.BoreholeService;
import org.bisag.ocbis.services.NavigationService;
import org.bisag.ocbis.utils.Json;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.micrometer.common.util.StringUtils;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@RestController
@CrossOrigin("*")
@RequestMapping("/borehole")
public class BoreholeController {

        @Autowired
        BoreholeService boreholeService;

        @Autowired
        BoreholeRepo boreholeRepo;

        @Autowired
        UserRepository userRepository;

        @Autowired
        NavigationService navigationService;

        /*
         * @Autowired
         * BoreholeRepo boreholeRepo;
         * 
         * @PostMapping("save-borehole")
         * public BoreholeEntity boreholeSave(@RequestBody BoreholeEntity entity) {
         * // TODO: process POST request
         * return boreholeService.saveBoreholeInfo(entity);
         * 
         * }
         */
        @PostMapping("/saveborehole")
        public <json> EncryptedResponse saveFspDetail(
                        @Valid @RequestBody EncryptedRequest req) throws Exception {
                var body = req.bodyAs(BoreholeEntity.class);

                // BoreholeEntity savBoreholeEntity = boreholeRepo.save(body);
                boreholeService.saveBoreholeInfo(body);

        
                return new EncryptedResponse("success");
        }

        @PostMapping("/get-borehole")
        public EncryptedResponse reportUsers(@RequestBody EncryptedRequest req)
                        throws Exception {
                var reportReq = Json.deserialize(Report.class, req.getData());
                // var pagination = reportReq.pagination();
                var pageable = PageRequest.of(reportReq.pagination().page(), reportReq.pagination().size());
                var searchQuery = StringUtils.isBlank(reportReq.search()) ? null : "%" + reportReq.search() + "%";
                var custom = reportReq.custom();

                System.out.println("custom: " + custom);

                String prospectName = StringUtils.isNotBlank((String) custom.get("prospectName"))
                                ? (String) custom.get("prospectName")
                                : null;
                String blockName = StringUtils.isNotBlank((String) custom.get("blockName"))
                                ? (String) custom.get("blockName")
                                : null;
                String inputCenterCode = StringUtils.isNotBlank((String) custom.get("inputCenterCode"))
                                ? (String) custom.get("inputCenterCode")
                                : null;
                String commodity = StringUtils.isNotBlank((String) custom.get("commodity"))
                                ? (String) custom.get("commodity")
                                : null;
                String boreholeName = StringUtils.isNotBlank((String) custom.get("boreholeName"))
                                ? (String) custom.get("boreholeName")
                                : null;

                String sourceOfData = StringUtils.isNotBlank((String) custom.get("sourceOfData"))
                                ? (String) custom.get("sourceOfData")
                                : null;

                String region = StringUtils.isNotBlank((String) custom.get("region"))
                                ? (String) custom.get("region")
                                : null;

                String state = StringUtils.isNotBlank((String) custom.get("state"))
                                ? (String) custom.get("state")
                                : null;

                String district = StringUtils.isNotBlank((String) custom.get("district"))
                                ? (String) custom.get("district")
                                : null;

                var result = boreholeRepo.findByFilters(searchQuery, prospectName, blockName, inputCenterCode,
                                commodity,
                                boreholeName, sourceOfData, region, state, district, pageable);
                return new EncryptedResponse(result);
        }

        @PostMapping("/get-all-region")
        public <json> EncryptedResponse getAllRegion(

                        HttpServletResponse response) throws Exception {
                List<Map<String, Object>> result = userRepository.getAllRegion();
                return new EncryptedResponse(result);
        }

        @PostMapping("/get-states")
        public <json> EncryptedResponse getAllStates() throws Exception {

                return new EncryptedResponse(navigationService.getAllStates());
        }

        @PostMapping("/get-districts-by-state-id")
        public <json> EncryptedResponse getDistrictsByStateId(
                        @RequestBody EncryptedRequest req)
                        throws Exception {
                GetId getid = req.bodyAs(GetId.class);
                String id = getid.id();

                return new EncryptedResponse(navigationService.getDistrictsByStateId(id));

        }

        @PostMapping("/get-districts")
        public <json> EncryptedResponse getDistricts()
                        throws Exception {
                return new EncryptedResponse(navigationService.getAllDistricts());
        }

        @PostMapping("/get-borehole/export")
        public EncryptedResponse reportUsersExport(@RequestBody EncryptedRequest req)
                        throws Exception {
                var reportReq = Json.deserialize(Report.class, req.getData());
                // var pagination = reportReq.pagination();
                // var pageable = PageRequest.of(reportReq.pagination().page(),
                // reportReq.pagination().size());
                var searchQuery = StringUtils.isBlank(reportReq.search()) ? null : "%" + reportReq.search() + "%";
                var custom = reportReq.custom();

                System.out.println("custom: " + custom);

                String prospectName = StringUtils.isNotBlank((String) custom.get("prospectName"))
                                ? (String) custom.get("prospectName")
                                : null;
                String blockName = StringUtils.isNotBlank((String) custom.get("blockName"))
                                ? (String) custom.get("blockName")
                                : null;
                String inputCenterCode = StringUtils.isNotBlank((String) custom.get("inputCenterCode"))
                                ? (String) custom.get("inputCenterCode")
                                : null;
                String commodity = StringUtils.isNotBlank((String) custom.get("commodity"))
                                ? (String) custom.get("commodity")
                                : null;
                String boreholeName = StringUtils.isNotBlank((String) custom.get("boreholeName"))
                                ? (String) custom.get("boreholeName")
                                : null;

                String sourceOfData = StringUtils.isNotBlank((String) custom.get("sourceOfData"))
                                ? (String) custom.get("sourceOfData")
                                : null;

                String region = StringUtils.isNotBlank((String) custom.get("region"))
                                ? (String) custom.get("region")
                                : null;

                String state = StringUtils.isNotBlank((String) custom.get("state"))
                                ? (String) custom.get("state")
                                : null;

                String district = StringUtils.isNotBlank((String) custom.get("district"))
                                ? (String) custom.get("district")
                                : null;

                var result = boreholeRepo.findByFiltersExport(searchQuery, prospectName, blockName, inputCenterCode,
                                commodity,
                                boreholeName, sourceOfData, region, state, district);
                return new EncryptedResponse(result);
        }

}
