package org.bisag.ocbis.models;

import java.util.ArrayList;

public class RowList {

	ArrayList<String> rowarray;

	public ArrayList<String> getRowarray() {
		return rowarray;
	}

	public void setRowarray(ArrayList<String> rowarray) {
		this.rowarray = rowarray;
	}

}
