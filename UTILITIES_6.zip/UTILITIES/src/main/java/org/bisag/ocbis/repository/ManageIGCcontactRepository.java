package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.ManageIGCcontacts;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ManageIGCcontactRepository extends JpaRepository<ManageIGCcontacts, Long>{

    @Query( 
            nativeQuery = true , 
            value = """
                    SELECT * FROM igc_contacts
                    """
          )
    Page<ManageIGCcontacts> findByFilters(String searchQuery, PageRequest pageable);
    
   
}

// WHERE (:searchQuery IS NULL OR contact_name LIKE :searchQuery)