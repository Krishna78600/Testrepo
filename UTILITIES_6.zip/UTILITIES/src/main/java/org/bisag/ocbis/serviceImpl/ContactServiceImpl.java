package org.bisag.ocbis.serviceImpl;

import java.util.List;

import org.bisag.ocbis.models.ContactEntity;
import org.bisag.ocbis.repository.ContactRepo;
import org.bisag.ocbis.services.ContactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;

@Service
public class ContactServiceImpl implements ContactService{
    
      
    @Autowired
    private ContactRepo contactRepo;

    @Override
    public ContactEntity saveContact(ContactEntity contact) {
        return contactRepo.save(contact);
    }

    @Override
    public List<ContactEntity> getAllContacts() {
        return contactRepo.findAll();
    }

    @Override
    public ContactEntity updateContact(ContactEntity contact, Long contactId) {
        ContactEntity existingContact = contactRepo.findById(contactId).orElseThrow(()->
        new NotFoundException("Contact not found with given contactId:"+contactId));
        if(contact != null){
            existingContact.setContactName(contact.getContactName());
            existingContact.setDesignation(contact.getDesignation());
        }
        else{
            throw new IllegalArgumentException("Contact object cannot be null");
        }
        return contactRepo.save(existingContact);   
    }

    @Override
    public void deleteContact(Long contactId) {
        contactRepo.deleteById(contactId);
    }


}   
