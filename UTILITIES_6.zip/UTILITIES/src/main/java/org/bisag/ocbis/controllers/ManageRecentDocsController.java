package org.bisag.ocbis.controllers;

import java.time.ZonedDateTime;

import org.bisag.ocbis.models.ManageIGCcontacts;
import org.bisag.ocbis.models.ManageIGCdocs;
import org.bisag.ocbis.models.ManageIGCphotos;
import org.bisag.ocbis.models.ManageRecentDocs;
import org.bisag.ocbis.models.User;
import org.bisag.ocbis.payloads.request.EncryptedRequest;
import org.bisag.ocbis.payloads.request.Report;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.ManageIGCcontactRepository;
import org.bisag.ocbis.repository.ManageIGCdocsRepository;
import org.bisag.ocbis.repository.ManageIGCphotosRepository;
import org.bisag.ocbis.repository.ManageRecentDocsRepository;
import org.bisag.ocbis.services.ManageIGCservice;
import org.bisag.ocbis.services.ManageRecentDocsService;
import org.bisag.ocbis.utils.Json;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.micrometer.common.util.StringUtils;
import jakarta.servlet.http.HttpServletRequest;

@RestController
@CrossOrigin("*")
@RequestMapping("/fileupload")
public class ManageRecentDocsController {

    @Autowired
    private ManageRecentDocsService managerecentdocservice;

    @Autowired
    private ManageRecentDocsRepository managerecentdocsrepo ;
    
    @Autowired
    private ManageIGCservice manageigcservice;
    
    @Autowired
    private ManageIGCcontactRepository manageigccontactrepo ;

    @Autowired
    private ManageIGCdocsRepository docsRepository;

    @Autowired 
    private ManageIGCphotosRepository manageigcphotorepo ;


    // 1- Save user details and uploading recent docs
    @PostMapping("/save-recent-docs")
    public <json> EncryptedResponse SaveRecentDocs(@RequestBody EncryptedRequest req, HttpServletRequest request,
            @AuthenticationPrincipal User user) throws Exception {
        try {
            var body = Json.deserialize(ManageRecentDocs.class, req.getData());
            managerecentdocservice.saveRecentDocs(body);
            return new EncryptedResponse("Manage Recent Doc saved");

        } catch (Exception e) {
            return new EncryptedResponse("Manage Recent Doc not saved ");
        }
    }


    // 2 - Getting Doc uploaded by me - searching filter
    @GetMapping("/get-doc-upload-by-me")
    public EncryptedResponse getDocUploadByMe(@RequestBody EncryptedRequest req) throws Exception {
        var reportReq = Json.deserialize(Report.class, req.getData());
        var pageable = PageRequest.of(reportReq.pagination().page(), reportReq.pagination().size());
        var searchQuery = StringUtils.isBlank(reportReq.search()) ? null : "%" + reportReq.search() + "%";
        var custom = reportReq.custom();

        String title = StringUtils.isNotBlank((String) custom.get("title"))
                ? (String) custom.get("title")
                : null;
        String documentType = StringUtils.isNotBlank((String) custom.get("documentType"))
                ? (String) custom.get("documentType")
                : null;
        String type = StringUtils.isNotBlank((String) custom.get("type"))
                ? (String) custom.get("type")
                : null;
        ZonedDateTime receivedDateFrom = (ZonedDateTime) custom.get("receivedDateFrom");
        ZonedDateTime receivedDateTo = (ZonedDateTime) custom.get("receivedDateTo");

        Page <ManageRecentDocs> result = managerecentdocsrepo.findByFilters(searchQuery, title, documentType, type,receivedDateFrom,receivedDateTo, pageable);

        return new EncryptedResponse(result);
    }


    // 3. Edit Manage Recent Docs
    @PostMapping("/edit-managerecentdoc")
    public <json> EncryptedResponse editManageRecentDocs(@RequestBody EncryptedRequest req) throws Exception {
        var body = Json.deserialize(ManageRecentDocs.class , req.getData());
        try{
            managerecentdocservice.editManageRecentDocs(body);
                return new EncryptedResponse("Manage recent doc edited successfully");
        }catch (Exception e){
                return new EncryptedResponse("Manage recent doc doesn't exist ");
        }
    }


    // 4. Delete Manage Recent Docs 
    @DeleteMapping("/delete-managerecentdoc")
    public <json> EncryptedResponse deleteManageRecentDocs(@RequestBody EncryptedRequest req) throws Exception {
    var body = Json.deserialize(ManageRecentDocs.class, req.getData());
    try {
        managerecentdocservice.deleteManageRecentDoc(body);
            return new EncryptedResponse("Manage Recent Doc deleted successfully");
    } catch (Exception e) {
            return new EncryptedResponse("Manage Recent Doc doesn't exists.");
       }
    }
   

    // 5. Save Manage IGC Contact
    @PostMapping("/save-manage-igc-contact")
    public <json> EncryptedResponse SaveManageIGCcontact(@RequestBody EncryptedRequest req, HttpServletRequest request,
            @AuthenticationPrincipal User user) throws Exception {
        try {
            var body = Json.deserialize(ManageIGCcontacts.class, req.getData());
            manageigcservice.saveManageIGCcontacts(body);
                return new EncryptedResponse("IGC contact saved");

        } catch (Exception e) {
                return new EncryptedResponse("contact not saved ");
        }
    }

    // 6. Get Mangage IGC contacts 
    @GetMapping("/get-igc-contacts")
    public EncryptedResponse getIGCcontacts(@RequestBody EncryptedRequest req) throws Exception {
        var reportReq = Json.deserialize(Report.class, req.getData());
        var pageable = PageRequest.of(reportReq.pagination().page(), reportReq.pagination().size());
        var searchQuery = StringUtils.isBlank(reportReq.search()) ? null : "%" + reportReq.search() + "%";
        Page <ManageIGCcontacts> result =  manageigccontactrepo.findByFilters( searchQuery , pageable);

        return new EncryptedResponse(result);
       
    }
    
    // 7. Edit Manage IGC Contact 
    @PostMapping("/edit-igc-contact")
    public <json> EncryptedResponse editManageIGCcontact(@RequestBody EncryptedRequest req) throws Exception {
        var body = Json.deserialize(ManageIGCcontacts.class , req.getData());
        try{
            manageigcservice.editIGCcontact(body);
                return new EncryptedResponse("Manage IGC doc edited successfully");
        } catch (Exception e){
                return new EncryptedResponse("Manage IGC doc does not exist ");
        }
    }

    // 8. Delete Manage IGC Contacts
    @DeleteMapping("/delete-igc-contact")
    public <json> EncryptedResponse deleteIGCcontact(@RequestBody EncryptedRequest req)
    throws Exception {
      var body = Json.deserialize(ManageIGCcontacts.class, req.getData());
      try {
          manageigcservice.deleteIGCcontact(body);
            return new EncryptedResponse("Manage IGC contact deleted successfully");
    } catch (Exception e) {
            return new EncryptedResponse("contact doesn't exists.");
    }
  }


    // 9. Manage IGC doc save
    @PostMapping("/save-manage-igc-doc")
    public <json> EncryptedResponse SaveManageIGCdoc(@RequestBody EncryptedRequest req, HttpServletRequest request,
            @AuthenticationPrincipal User user) throws Exception {
        try {
            var body = Json.deserialize(ManageIGCdocs.class, req.getData());
            manageigcservice.saveManageIGCdocs(body);
            return new EncryptedResponse("IGC document saved");

        } catch (Exception e) {
            return new EncryptedResponse("document not saved ");
        }
    }

    @PostMapping("/get-igcDoc")
    public EncryptedResponse reportUsers(@RequestBody EncryptedRequest req)
            throws Exception {
        var reportReq = Json.deserialize(Report.class, req.getData());
        // var pagination = reportReq.pagination();
        var pageable = PageRequest.of(reportReq.pagination().page(), reportReq.pagination().size());
        var searchQuery = StringUtils.isBlank(reportReq.search()) ? null : "%" + reportReq.search() + "%";
        var custom = reportReq.custom();

                System.out.println("custom: " + custom);

                String documentType = StringUtils.isNotBlank((String) custom.get("documentType"))
                                ? (String) custom.get("documentType")
                                : null;
                String accessibility = StringUtils.isNotBlank((String) custom.get("accessibility"))
                                ? (String) custom.get("accessibility")
                                : null;
                String documentTitle = StringUtils.isNotBlank((String) custom.get("documentTitle"))
                                ? (String) custom.get("documentTitle")
                                : null;
        var result = docsRepository.findByFilters(searchQuery,documentType,accessibility,documentTitle,pageable);
        return new EncryptedResponse(result);
    }
    // 11. Edit Manage IGC doc


    // 12. Delete Manage IGC doc 


    // 13. Save Mangage IGC photo
    @PostMapping("/save-manage-igc-photo")
    public <json> EncryptedResponse SaveManageIGCphoto(@RequestBody EncryptedRequest req, HttpServletRequest request,
            @AuthenticationPrincipal User user) throws Exception {
        try {
            var body = Json.deserialize(ManageIGCphotos.class, req.getData());
            manageigcservice.saveManageIGCphotos(body);
            return new EncryptedResponse("Manage IGC Photo saved");
            
        } catch (Exception e) {
            return new EncryptedResponse("Manage Photo not saved ");
        }
    }
    
    // 14. Get / Search Manage IGC photos 
    @GetMapping("/get-igc-photos")
    public EncryptedResponse getIGCphotos(@RequestBody EncryptedRequest req) throws Exception 
    {
        var reportReq = Json.deserialize(Report.class, req.getData());
        // var pagination = reportReq.pagination();
        var pageable = PageRequest.of(reportReq.pagination().page(), reportReq.pagination().size());
        var searchQuery = StringUtils.isBlank(reportReq.search()) ? null : "%" + reportReq.search() + "%";
        
        var custom = reportReq.custom();
        
        String photoType = StringUtils.isNotBlank((String) custom.get("photoType"))
        ? (String) custom.get("photoType")
        : null;
        String photoTitle = StringUtils.isNotBlank((String) custom.get("photoTitle"))
        ? (String) custom.get("photoTitle")
        : null;
        ZonedDateTime receivedDateFrom = (ZonedDateTime) custom.get("receivedDateFrom");
        ZonedDateTime receivedDateTo = (ZonedDateTime) custom.get("receivedDateTo");
        
        Page <ManageIGCphotos> result = manageigcphotorepo.findByFilters(searchQuery, photoType, photoTitle,receivedDateFrom,receivedDateTo, pageable);
        
        return new EncryptedResponse(result);
    }


    // 15. Edit Manage IGC photos 
    @PostMapping("/edit-igc-photo")
    public <json> EncryptedResponse editIGCphoto(@RequestBody EncryptedRequest req) throws Exception {
        var body = Json.deserialize(ManageIGCphotos.class , req.getData());
        try{
            manageigcservice.editIGCphoto(body);
                return new EncryptedResponse("Photo edited successfully");
        } catch (Exception e){
            return new EncryptedResponse("Photo does not exist ");
        }
    }

    // 16. Delete Manage IGC photos
    @DeleteMapping("/deleteIGCphotoById")
    public <json> EncryptedResponse deleteIGCphoto(@RequestBody EncryptedRequest req)
    throws Exception {
      var body = Json.deserialize(ManageIGCphotos.class, req.getData());
      try {
          manageigcservice.deleteIGCphoto(body);
              return new EncryptedResponse("IGC photo deleted successfully");
    } catch (Exception e) {
          return new EncryptedResponse("IGC photo doesn't exists.");
    }
  }  
}
