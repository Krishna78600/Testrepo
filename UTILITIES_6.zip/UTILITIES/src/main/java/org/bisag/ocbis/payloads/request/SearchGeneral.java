package org.bisag.ocbis.payloads.request;

public record SearchGeneral(String searchstring) {}
