package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.ManageIGCdocs;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ManageIGCdocsRepository extends JpaRepository<ManageIGCdocs, Long> {
    @Query(nativeQuery = true, value = """
        SELECT * FROM igc_docs b
        WHERE (?1\\:\\:text IS NULL OR b\\:\\:text ILIKE ?1)
           AND (?2\\:\\:text IS NULL OR b.document_type = ?2)
           AND (?3\\:\\:text IS NULL OR b.accessibility = ?3)
           AND (?4\\:\\:text IS NULL OR b.document_title = ?4)
        """)
    Page<ManageIGCdocs> findByFilters(String search,String documentType,String accessibility,String documentTitle,
      Pageable pageable);
}
