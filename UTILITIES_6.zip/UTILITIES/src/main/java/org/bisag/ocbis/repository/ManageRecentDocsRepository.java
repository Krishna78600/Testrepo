package org.bisag.ocbis.repository;

import java.time.ZonedDateTime;
import java.util.Optional;

import org.bisag.ocbis.models.ManageRecentDocs;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ManageRecentDocsRepository extends JpaRepository<ManageRecentDocs, Long> {

     @Override
     Optional<ManageRecentDocs> findById(Long id);

    // searching my uploads docs
    @Query( nativeQuery = true , 
            value = """
                    SELECT * FROM save_recent_docs s
                    WHERE (?1 \\:\\: text IS NULL OR s\\:\\: ILIKE ?1)
                    AND ?2 \\:\\: text is NULL or s.title ILIKE CONCAT('%', ?1, '%')) 
                    AND (?3 \\:\\: text IS NULL OR s.document_type = ?2) 
                    AND (?4 \\:\\: text IS NULL OR s.type = ?3) 
                    AND (?5 \\:\\: text IS NULL OR s.received_dateFrom >= ?4) 
                    AND (?6 \\:\\: text IS NULL OR s.received_dateTo <= ?5)
                    ORDER BY id
                   """)
    Page<ManageRecentDocs> findByFilters(String searchQuery, String title, String documentType, String type,ZonedDateTime receivedDateFrom, ZonedDateTime receivedDateTo,  PageRequest pageable);



}







    

    
    

