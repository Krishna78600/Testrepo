package org.bisag.ocbis.enums;

public enum Designation {
    Director("1"),
    SuperintendingGeologist("2"),
    SuperintendingGeophysicist("3"),
    ProjectDirector("4"),
    RMH("5"),
    NMH("6"),
    ADG("7"),
    DDG("8"),
    HOD("9"),
    StateUnitDDG("10"),
    StateUnitHead("11"),
    RegionalDirector("12"),
    RHOD("13"),
    PSS("14"),
    RTI("15"),
    RTIH("16"),
    TIHQ("17"),
    RHODBisag("18"),
    TIHQDH("19"),
    TIHOD("20"),
    DrillingDivisionAdmin("21"),
    DrillingDivisionUser("22");

    private final String value;

    Designation(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}