package org.bisag.ocbis.payloads.request;

import java.util.List;

import org.bisag.ocbis.models.CruiseActivity;
import org.bisag.ocbis.models.FieldActivity;

public record AddWorkPlanRequest(
                String fspId,
                String proposalId,
                String labStudies,
                String postFieldActivity,
                String preFieldActivity,
                String reportSubmission,
                List<FieldActivity> fieldActivity,
                List<CruiseActivity> cruiseActivity) {

}
