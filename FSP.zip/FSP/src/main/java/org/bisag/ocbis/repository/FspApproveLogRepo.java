package org.bisag.ocbis.repository;

import java.time.ZonedDateTime;

import org.bisag.ocbis.models.FspApproveLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface FspApproveLogRepo extends JpaRepository<FspApproveLog, Long> {

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_approve_levels_details WHERE fsp_form_id = ?1
                        """)
        FspApproveLog findByFspFormId(long id);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details_log SET forwarded_by_fsp_creater = ?1,forwarded_to_suhead = ?2, fsp_creater_created_date = ?3,
                        auto_push_status='Approve'
                        WHERE fsp_form_id = ?4 AND is_currently_active = true
                        """)
        void forwardToSUheadLog(Long forwardedByFspCreaterId, Long forwardedToSuHeadId, ZonedDateTime createdDate,
                        Long fspFormId, String stateId, String remakrs, String status);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details_log SET forwarded_by_suhead = ?1,forwarded_to_rmh_of_pm = ?2, su_head_created_date = ?3,su_head_remarks = ?5,su_head_status = ?6
                        WHERE fsp_form_id = ?4 AND is_currently_active = true
                        """)
        void forwardToRmhOfPmBySuHeadLog(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate,
                        Long fspFormId, String remakrs, String status, String stateId);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details_log SET forwarded_by_rmh_of_pm = ?1,forwarded_to_hod = ?2, rmh_of_pm_created_date = ?3,rmh_of_pm_remarks = ?5,rmh_of_pm_status = ?6
                        WHERE fsp_form_id = ?4 AND is_currently_active = true
                        """)
        void forwardToHodByRmhOfPmLog(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate,
                        Long fspFormId, String remakrs, String status, String stateId);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details_log SET forwarded_by_hod = ?1,forwarded_to_ddg_of_sm = ?2, hod_created_date = ?3,hod_remarks = ?5,hod_status = ?6
                        WHERE fsp_form_id = ?4 AND is_currently_active = true
                        """)
        void forwardToDdgofSmByHodLog(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate,
                        Long fspFormId, String remakrs, String status, String stateId);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details_log SET forwarded_by_ddg_of_sm = ?1,forwarded_to_adg_of_pss = ?2, ddg_of_sm_created_date = ?3,ddg_of_sm_remarks = ?5,ddg_of_sm_status = ?6
                        WHERE fsp_form_id = ?4 AND is_currently_active = true
                        """)
        void forwardToAdgOfPssByDdgofSmLog(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate,
                        Long fspFormId, String remakrs, String status, String stateId);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details_log SET forwarded_by_suhead = ?1,forwarded_to_hod = ?2, su_head_created_date = ?3,su_head_remarks = ?5,su_head_status = ?6
                        WHERE fsp_form_id = ?4 AND is_currently_active = true
                        """)
        void forwardToHodBySuLog(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate,
                        Long fspFormId, String remakrs, String status, String stateId);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details_log SET forwarded_by_adg_of_pss = ?1, adg_of_pss_created_date = ?2,adg_of_pss_remarks = ?4,adg_of_pss_status = ?5
                        WHERE fsp_form_id = ?3 AND is_currently_active = true
                        """)
        void forwardedByAdgOfPssLog(Long forwardeByOfficerUserId,
                        ZonedDateTime createdDate,
                        Long fspFormId, String remakrs, String status, String stateId);

        @Modifying
        @Query(nativeQuery = true, value = """
                        WITH CTE AS (
                            SELECT *
                            FROM FSP_APPROVE_LEVELS_DETAILS_LOG
                            WHERE FSP_FORM_ID = ?1
                        )
                        UPDATE FSP_APPROVE_LEVELS_DETAILS_LOG
                        SET
                            IS_CURRENTLY_ACTIVE = False,
                            FORWARDED_TO_FSP_CREATER_ID = CASE
                                WHEN FSP_FORM_ID = ?1 THEN ?3
                                ELSE FORWARDED_TO_FSP_CREATER_ID
                            END
                        WHERE ID IN (SELECT ID FROM CTE WHERE ID != ?2);
                                                                                                       """)
        void setCurrentlyActiveFlag(Long fspFormId, Long Id, Long forwardeToOfficerUserId);

}