package org.bisag.ocbis.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "SiteID")
public class SiteId {

    @Id
    @Column(name = "CSI_SITE_ID")
    private Long csi_site_id;
    private String csi_site_name;
    private String csi_site_short_name;
    private String csi_parent_site_id;

    public Long getCsi_site_id() {
        return csi_site_id;
    }

    public void setCsi_site_id(Long csi_site_id) {
        this.csi_site_id = csi_site_id;
    }

    public String getCsi_site_name() {
        return csi_site_name;
    }

    public void setCsi_site_name(String csi_site_name) {
        this.csi_site_name = csi_site_name;
    }

    public String getCsi_site_short_name() {
        return csi_site_short_name;
    }

    public void setCsi_site_short_name(String csi_site_short_name) {
        this.csi_site_short_name = csi_site_short_name;
    }

    public String getCsi_parent_site_id() {
        return csi_parent_site_id;
    }

    public void setCsi_parent_site_id(String csi_parent_site_id) {
        this.csi_parent_site_id = csi_parent_site_id;
    }

}
