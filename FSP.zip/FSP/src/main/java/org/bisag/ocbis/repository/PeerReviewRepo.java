package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.PeerReview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface PeerReviewRepo extends JpaRepository<PeerReview, Long> {
        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_approve_levels_details WHERE fsp_form_id = ?1
                        """)
        PeerReview findByFormId(long id);

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_peer_review WHERE id = ?1
                        """)
        PeerReview findByPeerId(long id);

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_peer_review WHERE fsp_form_id = ?1
                        """)
        PeerReview findByPssFormId(long id);
}
