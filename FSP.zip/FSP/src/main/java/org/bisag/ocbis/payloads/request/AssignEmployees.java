package org.bisag.ocbis.payloads.request;

import java.util.List;

public record AssignEmployees(String fsp_id, List<Long> employees_list, String designation) {

}
