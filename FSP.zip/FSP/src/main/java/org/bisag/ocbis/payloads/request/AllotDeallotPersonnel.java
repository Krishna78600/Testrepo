package org.bisag.ocbis.payloads.request;

public record AllotDeallotPersonnel(String fspId, String proposalId, String employeeId, String employeeName,
                String newEmployeeId,
                String employeeDesignation,
                String status, String deallocateDate) {

}
