package org.bisag.ocbis.controllers;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.bisag.ocbis.exceptions.NotFoundException;
import org.bisag.ocbis.repository.PeerReviewRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.micrometer.common.util.StringUtils;
import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/files")
public class FilesController {

  @Autowired
  PeerReviewRepo peerReviewRepo;

  @Value("${fileServerPath}")
  String fileServerPath;

  @GetMapping("/docs/{file}")
  public void verifyPdf(@PathVariable(value = "file") String file,
      HttpServletResponse response)
      throws Exception {
    try {
      response.setStatus(200);
      response.setContentType("application/pdf");
      IOUtils.copy(FileUtils.openInputStream(
          new File(fileServerPath + "PeerReview/" + file)),
          response.getOutputStream());
    } catch (Exception ex) {
      System.out.println("ex: " + ex.getMessage());
      throw new NotFoundException("Pdf not found.");
    }
  }

  @GetMapping("/documents/{file}")
  public void verifyPdfFile(@PathVariable(value = "file") String file,
      HttpServletResponse response)
      throws Exception {
    try {
      response.setStatus(200);
      response.setContentType("application/pdf");
      IOUtils.copy(FileUtils.openInputStream(
          new File(fileServerPath + "ExternalPeerReview/" + file)),
          response.getOutputStream());
    } catch (Exception ex) {
      System.out.println("ex: " + ex.getMessage());
      throw new NotFoundException("Pdf not found.");
    }
  }

  // @GetMapping("/docsdpr/{file}")
  // public void verifyPdfDpr(@PathVariable(value = "file") String file,
  // HttpServletResponse response)
  // throws Exception {
  // try {
  // response.setStatus(200);
  // response.setContentType("application/pdf");
  // IOUtils.copy(FileUtils.openInputStream(
  // new File(fileServerPath2 + "/documents/" + file + ".pdf")),
  // response.getOutputStream());
  // } catch (Exception ex) {
  // System.out.println("ex: " + ex.getMessage());
  // throw new NotFoundException("Pdf not found.");
  // }
  // }

  @GetMapping("/imgs/{file}")
  public void verifyImage(@PathVariable(value = "file") String file,
      HttpServletResponse response)
      throws Exception {
    try {
      response.setStatus(200);
      response.setContentType("image/png");
      IOUtils.copy(FileUtils.openInputStream(
          new File(fileServerPath + "/images/" + file + ".png")),
          response.getOutputStream());
    } catch (Exception ex) {
      throw new NotFoundException("Image not found.");
    }
  }

  @GetMapping("/get-file-by-path")
  public void getPhotoByPath(@RequestParam String path, HttpServletResponse response)
      throws Exception {

    if (StringUtils.isBlank(path)) {
      throw new NotFoundException("Image not found.");
    }
    try {
      response.setStatus(200);
      response.setContentType("image/png");

      IOUtils.copy(FileUtils.openInputStream(new File(path)),
          response.getOutputStream());
    } catch (Exception ex) {
      System.err.println("--- Caught error in get-photo-by-path ---");
      ex.printStackTrace();
      System.err.println("--- x ---");
      throw new NotFoundException("Image not found.");
    }
  }

}
