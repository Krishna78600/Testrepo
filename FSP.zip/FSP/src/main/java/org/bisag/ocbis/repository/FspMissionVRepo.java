package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.MissionVDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface FspMissionVRepo extends JpaRepository<MissionVDetails, Long> {

    @Query(nativeQuery = true, value = """
     select * from fsp_missionv_details where fsp_form_id = ?1
    """)
    
    MissionVDetails findByFspFormId(Long fspFormId);
}
