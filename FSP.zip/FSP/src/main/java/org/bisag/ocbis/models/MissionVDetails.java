package org.bisag.ocbis.models;

import java.time.ZonedDateTime;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Table
@Entity(name = "fsp_missionv_details")
public class MissionVDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;
    // fsp course details tab start
    private String cuCourseId;
    private String cuCourseSubType;
    private String cuSelfNomination;
    private String cuCourseSubTypeOther;
    private String cuOrganisedFor;
    private String cuProposedStartDate;
    private String cuProposedEndDate;
    private String cuDurationOfCourse;
    private String cuBackgroundInfo;
    private String cuObjective;

    private String cuFundingAgencyName;
    private Integer cuMinimumNumberOfPeople;
    private Integer cuNumberOfCoreFaculty;
    private Integer cuNumberOfGuestFaculty;
    private Integer cuCourseCoordinatorEmployeeId;
    private Integer cuVehicleBudget;
    private Integer cuLogisticsBudget;
    private Integer cuOtherBudget;
    private String cuCourseContent;
    private ZonedDateTime courseCreatedDate;
    // fsp course details tab end

    private String organisedBy;
    private String organisedFor;
    private ZonedDateTime orgCreatedDate;

    private String targetAudienceDesignation;
    private String targetAudienceSpecialization;
    private String targetAudienceProject;
    private String targetAudienceAge;
    private ZonedDateTime targetCreatedDate;

    private String venue;
    private ZonedDateTime venueCreatedDateTime;

    private String labLocation;
    private List<String> labType;
    private ZonedDateTime labCreationDateTime;

    private List<String> participateUnit;
    private ZonedDateTime participateUnitCreationDateTime;

    private Long fspFormId;
    private Long userId;
    private Integer stepsCompleted;

    

    public ZonedDateTime getTargetCreatedDate() {
        return targetCreatedDate;
    }

    public void setTargetCreatedDate(ZonedDateTime targetCreatedDate) {
        this.targetCreatedDate = targetCreatedDate;
    }

    public List<String> getParticipateUnit() {
        return participateUnit;
    }

    public void setParticipateUnit(List<String> participateUnit) {
        this.participateUnit = participateUnit;
    }

    public ZonedDateTime getParticipateUnitCreationDateTime() {
        return participateUnitCreationDateTime;
    }

    public void setParticipateUnitCreationDateTime(ZonedDateTime participateUnitCreationDateTime) {
        this.participateUnitCreationDateTime = participateUnitCreationDateTime;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getCuCourseId() {
        return cuCourseId;
    }

    public void setCuCourseId(String cuCourseId) {
        this.cuCourseId = cuCourseId;
    }

    public String getCuCourseSubType() {
        return cuCourseSubType;
    }

    public void setCuCourseSubType(String cuCourseSubType) {
        this.cuCourseSubType = cuCourseSubType;
    }

    public String getCuSelfNomination() {
        return cuSelfNomination;
    }

    public void setCuSelfNomination(String cuSelfNomination) {
        this.cuSelfNomination = cuSelfNomination;
    }

    public String getCuCourseSubTypeOther() {
        return cuCourseSubTypeOther;
    }

    public void setCuCourseSubTypeOther(String cuCourseSubTypeOther) {
        this.cuCourseSubTypeOther = cuCourseSubTypeOther;
    }

    public String getCuOrganisedFor() {
        return cuOrganisedFor;
    }

    public void setCuOrganisedFor(String cuOrganisedFor) {
        this.cuOrganisedFor = cuOrganisedFor;
    }

    public String getCuProposedStartDate() {
        return cuProposedStartDate;
    }

    public void setCuProposedStartDate(String cuProposedStartDate) {
        this.cuProposedStartDate = cuProposedStartDate;
    }

    public String getCuProposedEndDate() {
        return cuProposedEndDate;
    }

    public void setCuProposedEndDate(String cuProposedEndDate) {
        this.cuProposedEndDate = cuProposedEndDate;
    }

    public String getCuDurationOfCourse() {
        return cuDurationOfCourse;
    }

    public void setCuDurationOfCourse(String cuDurationOfCourse) {
        this.cuDurationOfCourse = cuDurationOfCourse;
    }

    public String getCuBackgroundInfo() {
        return cuBackgroundInfo;
    }

    public void setCuBackgroundInfo(String cuBackgroundInfo) {
        this.cuBackgroundInfo = cuBackgroundInfo;
    }

    public String getCuObjective() {
        return cuObjective;
    }

    public void setCuObjective(String cuObjective) {
        this.cuObjective = cuObjective;
    }

    public String getCuFundingAgencyName() {
        return cuFundingAgencyName;
    }

    public void setCuFundingAgencyName(String cuFundingAgencyName) {
        this.cuFundingAgencyName = cuFundingAgencyName;
    }

    public Integer getCuMinimumNumberOfPeople() {
        return cuMinimumNumberOfPeople;
    }

    public void setCuMinimumNumberOfPeople(Integer cuMinimumNumberOfPeople) {
        this.cuMinimumNumberOfPeople = cuMinimumNumberOfPeople;
    }

    public Integer getCuNumberOfCoreFaculty() {
        return cuNumberOfCoreFaculty;
    }

    public void setCuNumberOfCoreFaculty(Integer cuNumberOfCoreFaculty) {
        this.cuNumberOfCoreFaculty = cuNumberOfCoreFaculty;
    }

    public Integer getCuNumberOfGuestFaculty() {
        return cuNumberOfGuestFaculty;
    }

    public void setCuNumberOfGuestFaculty(Integer cuNumberOfGuestFaculty) {
        this.cuNumberOfGuestFaculty = cuNumberOfGuestFaculty;
    }

    public Integer getCuCourseCoordinatorEmployeeId() {
        return cuCourseCoordinatorEmployeeId;
    }

    public void setCuCourseCoordinatorEmployeeId(Integer cuCourseCoordinatorEmployeeId) {
        this.cuCourseCoordinatorEmployeeId = cuCourseCoordinatorEmployeeId;
    }

    public Integer getCuVehicleBudget() {
        return cuVehicleBudget;
    }

    public void setCuVehicleBudget(Integer cuVehicleBudget) {
        this.cuVehicleBudget = cuVehicleBudget;
    }

    public Integer getCuLogisticsBudget() {
        return cuLogisticsBudget;
    }

    public void setCuLogisticsBudget(Integer cuLogisticsBudget) {
        this.cuLogisticsBudget = cuLogisticsBudget;
    }

    public Integer getCuOtherBudget() {
        return cuOtherBudget;
    }

    public void setCuOtherBudget(Integer cuOtherBudget) {
        this.cuOtherBudget = cuOtherBudget;
    }

    public String getCuCourseContent() {
        return cuCourseContent;
    }

    public void setCuCourseContent(String cuCourseContent) {
        this.cuCourseContent = cuCourseContent;
    }

    public ZonedDateTime getCourseCreatedDate() {
        return courseCreatedDate;
    }

    public void setCourseCreatedDate(ZonedDateTime courseCreatedDate) {
        this.courseCreatedDate = courseCreatedDate;
    }


    public String getOrganisedBy() {
        return organisedBy;
    }

    public void setOrganisedBy(String organisedBy) {
        this.organisedBy = organisedBy;
    }

    public String getOrganisedFor() {
        return organisedFor;
    }

    public void setOrganisedFor(String organisedFor) {
        this.organisedFor = organisedFor;
    }

    
    public String getTargetAudienceDesignation() {
        return targetAudienceDesignation;
    }

    public void setTargetAudienceDesignation(String targetAudienceDesignation) {
        this.targetAudienceDesignation = targetAudienceDesignation;
    }

    public String getTargetAudienceSpecialization() {
        return targetAudienceSpecialization;
    }

    public void setTargetAudienceSpecialization(String targetAudienceSpecialization) {
        this.targetAudienceSpecialization = targetAudienceSpecialization;
    }

    public String getTargetAudienceProject() {
        return targetAudienceProject;
    }

    public void setTargetAudienceProject(String targetAudienceProject) {
        this.targetAudienceProject = targetAudienceProject;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public ZonedDateTime getVenueCreatedDateTime() {
        return venueCreatedDateTime;
    }

    public void setVenueCreatedDateTime(ZonedDateTime venueCreatedDateTime) {
        this.venueCreatedDateTime = venueCreatedDateTime;
    }

    public String getTargetAudienceAge() {
        return targetAudienceAge;
    }

    public void setTargetAudienceAge(String targetAudienceAge) {
        this.targetAudienceAge = targetAudienceAge;
    }

    public Integer getStepsCompleted() {
        return stepsCompleted;
    }

    public void setStepsCompleted(Integer stepsCompleted) {
        this.stepsCompleted = stepsCompleted;
    }

    public Long getFspFormId() {
        return fspFormId;
    }

    public void setFspFormId(Long fspFormId) {
        this.fspFormId = fspFormId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public ZonedDateTime getOrgCreatedDate() {
        return orgCreatedDate;
    }

    public void setOrgCreatedDate(ZonedDateTime orgCreatedDate) {
        this.orgCreatedDate = orgCreatedDate;
    }

    public String getLabLocation() {
        return labLocation;
    }

    public void setLabLocation(String labLocation) {
        this.labLocation = labLocation;
    }

    public List<String> getLabType() {
        return labType;
    }

    public void setLabType(List<String> labType) {
        this.labType = labType;
    }

    public ZonedDateTime getLabCreationDateTime() {
        return labCreationDateTime;
    }

    public void setLabCreationDateTime(ZonedDateTime labCreationDateTime) {
        this.labCreationDateTime = labCreationDateTime;
    }

    
}
