package org.bisag.ocbis.controllers;

import java.time.ZonedDateTime;
import java.util.Optional;

import org.bisag.ocbis.models.CreateFsp;
import org.bisag.ocbis.models.MissionVDetails;
import org.bisag.ocbis.models.User;
import org.bisag.ocbis.payloads.request.EncryptedRequest;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.FspMissionVRepo;
import org.bisag.ocbis.repository.FspRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@RestController
@CrossOrigin("*")
@RequestMapping("/createfspmissionv")
public class CreateFSPMissionVController {

    @Autowired
    FspRepo fspRepo;

    @Autowired
    FspMissionVRepo fspMissionVRepo;

    @Transactional
    @PostMapping("/save-course-details")
    public EncryptedResponse saveCourseDetails(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        try {
            var body = req.bodyAs(MissionVDetails.class);
            body.setCourseCreatedDate(ZonedDateTime.now());

            if (body.getFspFormId() != null) {
                fspMissionVRepo.save(body);
            } else {
                MissionVDetails existingCuDetails = fspMissionVRepo.findByFspFormId(body.getFspFormId());

                ObjectMapper objectMapper = new ObjectMapper();

                objectMapper.registerModule(new JavaTimeModule()); // Register the JavaTimeModule

                String jsonBody = objectMapper.writeValueAsString(existingCuDetails);
                System.out.println("jsonBodyyyyyyyy: " + jsonBody);

                existingCuDetails.setCuCourseId(body.getCuCourseId());
                existingCuDetails.setCuCourseSubType(body.getCuCourseSubType());
                existingCuDetails.setCuSelfNomination(body.getCuSelfNomination());
                existingCuDetails.setCuCourseSubTypeOther(body.getCuCourseSubTypeOther());
                existingCuDetails.setCuOrganisedFor(body.getCuOrganisedFor());
                existingCuDetails.setCuProposedStartDate(body.getCuProposedStartDate());
                existingCuDetails.setCuProposedEndDate(body.getCuProposedEndDate());
                existingCuDetails.setCuDurationOfCourse(body.getCuDurationOfCourse());
                existingCuDetails.setCuBackgroundInfo(body.getCuBackgroundInfo());
                existingCuDetails.setCuObjective(body.getCuObjective());
                existingCuDetails.setCuFundingAgencyName(body.getCuFundingAgencyName());
                existingCuDetails.setCuMinimumNumberOfPeople(body.getCuMinimumNumberOfPeople());
                existingCuDetails.setCuNumberOfCoreFaculty(body.getCuNumberOfCoreFaculty());
                existingCuDetails.setCuNumberOfGuestFaculty(body.getCuNumberOfGuestFaculty());
                existingCuDetails.setCuCourseCoordinatorEmployeeId(body.getCuCourseCoordinatorEmployeeId());
                existingCuDetails.setCuVehicleBudget(body.getCuVehicleBudget());
                existingCuDetails.setCuLogisticsBudget(body.getCuLogisticsBudget());
                existingCuDetails.setCuOtherBudget(body.getCuOtherBudget());
                existingCuDetails.setCuCourseContent(body.getCuCourseContent());

                existingCuDetails.setStepsCompleted(body.getStepsCompleted());
                existingCuDetails.setCourseCreatedDate(ZonedDateTime.now());
                existingCuDetails.setUserId(user.getId());

            }

            return new EncryptedResponse("saved successfully");

        } catch (Exception e) {
            return new EncryptedResponse("false");
        }
    }

    @Transactional
    @PostMapping("/save-organization-details")
    public EncryptedResponse saveOrganizationDetails(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        try {
            System.out.println("calleddddddddddddd try");
            var body = req.bodyAs(MissionVDetails.class);
            System.out.println("bodyyyyyy" + body.getFspFormId());

            if (body.getFspFormId() != null) {

                MissionVDetails existingOrgDetails = fspMissionVRepo.findByFspFormId(body.getFspFormId());

                existingOrgDetails.setOrganisedBy(body.getOrganisedBy());
                existingOrgDetails.setOrganisedFor(body.getOrganisedFor());
                existingOrgDetails.setOrgCreatedDate(ZonedDateTime.now());
                existingOrgDetails.setStepsCompleted(body.getStepsCompleted());
            }

            return new EncryptedResponse("saved successfully");

        } catch (Exception e) {
            return new EncryptedResponse("false");
        }

    }

    @Transactional
    @PostMapping("/save-eligibility-details")
    public EncryptedResponse saveEligiblityDetails(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        try {
            System.out.println("calleddddddddddddd try");
            var body = req.bodyAs(MissionVDetails.class);
            System.out.println("bodyyyyyy" + body.getFspFormId());

            if (body.getFspFormId() != null) {

                System.out.println("calleddddddddddddd");
                MissionVDetails existingDetails = fspMissionVRepo.findByFspFormId(body.getFspFormId());

                existingDetails.setTargetAudienceAge(body.getTargetAudienceAge());
                existingDetails.setTargetAudienceProject(body.getTargetAudienceProject());
                existingDetails.setTargetAudienceSpecialization(body.getTargetAudienceSpecialization());
                existingDetails.setTargetAudienceDesignation(body.getTargetAudienceDesignation());
                existingDetails.setTargetCreatedDate(ZonedDateTime.now());
                existingDetails.setStepsCompleted(body.getStepsCompleted());
            }

            return new EncryptedResponse("saved successfully");

        } catch (Exception e) {
            return new EncryptedResponse("false");
        }
    }

    @Transactional
    @PostMapping("/save-venue-details")
    public EncryptedResponse saveVenueDetails(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        try {
            var body = req.bodyAs(MissionVDetails.class);

            if (body.getFspFormId() != null) {

                MissionVDetails existingVenueDetails = fspMissionVRepo.findByFspFormId(body.getFspFormId());

                existingVenueDetails.setVenue(body.getVenue());
                existingVenueDetails.setVenueCreatedDateTime(ZonedDateTime.now());
                existingVenueDetails.setStepsCompleted(body.getStepsCompleted());
            }

            return new EncryptedResponse("saved successfully");

        } catch (Exception e) {
            return new EncryptedResponse("false");
        }
    }

    @Transactional
    @PostMapping("/save-lab-details")
    public EncryptedResponse saveLabDetails(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        try {
            System.out.println("calleddddddddddddd try");
            var body = req.bodyAs(MissionVDetails.class);
            System.out.println("bodyyyyyy" + body.getFspFormId());

            if (body.getFspFormId() != null) {

                System.out.println("calleddddddddddddd");
                MissionVDetails existingLabDetails = fspMissionVRepo.findByFspFormId(body.getFspFormId());

                existingLabDetails.setLabLocation(body.getLabLocation());
                existingLabDetails.setLabType(body.getLabType());
                existingLabDetails.setLabCreationDateTime(ZonedDateTime.now());
                existingLabDetails.setStepsCompleted(body.getStepsCompleted());
            }

            return new EncryptedResponse("saved successfully");

        } catch (Exception e) {
            return new EncryptedResponse("false");
        }
    }

    @Transactional
    @PostMapping("/save-participatingunit-details")
    public EncryptedResponse saveParticipatingUnitDetails(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        // try {
        System.out.println("calleddddddddddddd try");
        var body = req.bodyAs(MissionVDetails.class);
        System.out.println("bodyyyyyy" + body.getFspFormId());

        if (body.getFspFormId() != null) {

            System.out.println("calleddddddddddddd");
            MissionVDetails existingPuDetails = fspMissionVRepo.findByFspFormId(body.getFspFormId());
            System.out.println("bodyyyyyyyyy" + body.getParticipateUnit());
            ObjectMapper objectMapper = new ObjectMapper();

            objectMapper.registerModule(new JavaTimeModule()); // Register the JavaTimeModule
            String jsonBody = objectMapper.writeValueAsString(existingPuDetails);
            System.out.println("jsonBodyyyyyyyy: " + jsonBody);

            existingPuDetails.setParticipateUnit(body.getParticipateUnit());
            existingPuDetails.setParticipateUnitCreationDateTime(ZonedDateTime.now());
            existingPuDetails.setStepsCompleted(body.getStepsCompleted());
        }

        return new EncryptedResponse("saved successfully");

        // } catch (Exception e) {
        // return new EncryptedResponse("false");
        // }
    }
}
