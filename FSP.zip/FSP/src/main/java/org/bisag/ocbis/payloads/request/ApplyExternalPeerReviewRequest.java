package org.bisag.ocbis.payloads.request;

public record ApplyExternalPeerReviewRequest(String region,
                String proposalId, Long fspFormId, Long id,
                String pss_external_peer_remarks, String pss_external_peer_status, String adgDoc) {

}
