package org.bisag.ocbis.repository;

import java.util.Map;

import org.bisag.ocbis.models.FspForwardAfterApproved;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface FspForwardAfterApprovedRepo extends JpaRepository<FspForwardAfterApproved, Long> {

    @Query(nativeQuery = true, value = """
                        SELECT ffap.*
            FROM save_created_fsp scf
            JOIN fsp_forwarded_after_approved ffap ON scf.fsp_id = ffap.fsp_id
            JOIN ocbis_users ou ON ou.employee_id::bigint = ANY(ffap.fsp_allocated_ps_by_director_of_pu_ids)
            JOIN fsp_approve_levels_details fald ON fald.fsp_form_id = scf.id
            left join fsp_peer_review fpr on fpr.proposal_id = fald.proposal_id

            WHERE scf.steps_completed = 9 AND ou.employee_id = ?1 And scf.fsp_id is not null

                                   """)
    Page<Map<String, Object>> getApprovedFspForPersonnelStream(String stateId, Pageable pageable);

}
