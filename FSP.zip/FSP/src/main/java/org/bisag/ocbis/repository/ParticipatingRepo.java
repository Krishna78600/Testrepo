package org.bisag.ocbis.repository;

import java.util.Map;

import org.bisag.ocbis.models.ParticipatingUnits;
import org.bisag.ocbis.models.PeerReview;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ParticipatingRepo extends JpaRepository<ParticipatingUnits, Long> {

    @Query(nativeQuery = true, value = """
            SELECT scf.*,fpu.*
                FROM save_created_fsp scf
                LEFT JOIN fsp_forwarded_after_approved ffap ON scf.fsp_id = ffap.fsp_id
                LEFT JOIN fsp_participating_units fpu ON fpu.fsp_id = scf.fsp_id
                LEFT JOIN fsp_peer_review fpr ON fpr.proposal_id = scf.proposal_id
                LEFT JOIN ocbis_users ou ON ou.employee_id::bigint = ANY(ffap.fsp_allocated_ps_by_director_of_pu_ids)
                WHERE fpu.employee_id = ?1

                                   """)
    Page<Map<String, Object>> getAllotmentFspToPersonnel(String stateId, Pageable pageable);

    @Query(nativeQuery = true, value = """
            SELECT * FROM fsp_participating_units fpu WHERE fpu.fsp_id = ?1 and fpu.employee_id = ?2
            """)
    ParticipatingUnits findByFspId(String fspId, String empId);

}
