package org.bisag.ocbis.models;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "fsp_participating_units")
public class ParticipatingUnits {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String activityName;
    private String cruiseNo;
    private String employeeDesignation;
    private String employeeId;
    private String employeeName;
    private Integer expectedDuration;
    private ZonedDateTime expectedTimeArrival;
    private ZonedDateTime expectedTimeDeparture;
    private String fspId;
    private String leg;
    private String noOfPersons;
    private String personnelStream;
    private String portOfDisembarkation;
    private String portOfEmbarkation;
    private String proposalId;
    private String role;
    private String scheduledMonth;
    private String siteId;
    private String siteName;
    private String timeIndicator;
    private String labStudies;

    private String postFieldActivity;
    private String preFieldActivity;
    private String reportSubmission;
    private String status;

    private String deAllocateDate;
    private Boolean flagForDeallocateEmp;
    private Long deallocateByDirectorId;
    private Long replaceByDirectorId;
    private ZonedDateTime createDateForDeallocateEmp;
    private ZonedDateTime createDateForReplaceEmp;

    private String region;
    private String state;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @OneToMany(mappedBy = "participatingUnits", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CruiseActivity> cruiseActivities = new ArrayList<>();

    @OneToMany(mappedBy = "participatingUnits", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FieldActivity> fieldActivities = new ArrayList<>();

    public List<CruiseActivity> getCruiseActivities() {
        return cruiseActivities;
    }

    public void setCruiseActivities(List<CruiseActivity> cruiseActivities) {
        this.cruiseActivities = cruiseActivities;
    }

    public List<FieldActivity> getFieldActivities() {
        return fieldActivities;
    }

    public void setFieldActivities(List<FieldActivity> fieldActivities) {
        this.fieldActivities = fieldActivities;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getCruiseNo() {
        return cruiseNo;
    }

    public void setCruiseNo(String cruiseNo) {
        this.cruiseNo = cruiseNo;
    }

    public String getEmployeeDesignation() {
        return employeeDesignation;
    }

    public void setEmployeeDesignation(String employeeDesignation) {
        this.employeeDesignation = employeeDesignation;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public Integer getExpectedDuration() {
        return expectedDuration;
    }

    public void setExpectedDuration(Integer expectedDuration) {
        this.expectedDuration = expectedDuration;
    }

    public ZonedDateTime getExpectedTimeArrival() {
        return expectedTimeArrival;
    }

    public void setExpectedTimeArrival(ZonedDateTime expectedTimeArrival) {
        this.expectedTimeArrival = expectedTimeArrival;
    }

    public ZonedDateTime getExpectedTimeDeparture() {
        return expectedTimeDeparture;
    }

    public void setExpectedTimeDeparture(ZonedDateTime expectedTimeDeparture) {
        this.expectedTimeDeparture = expectedTimeDeparture;
    }

    public String getFspId() {
        return fspId;
    }

    public void setFspId(String fspId) {
        this.fspId = fspId;
    }

    public String getLeg() {
        return leg;
    }

    public void setLeg(String leg) {
        this.leg = leg;
    }

    public String getNoOfPersons() {
        return noOfPersons;
    }

    public void setNoOfPersons(String noOfPersons) {
        this.noOfPersons = noOfPersons;
    }

    public String getPersonnelStream() {
        return personnelStream;
    }

    public void setPersonnelStream(String personnelStream) {
        this.personnelStream = personnelStream;
    }

    public String getPortOfDisembarkation() {
        return portOfDisembarkation;
    }

    public void setPortOfDisembarkation(String portOfDisembarkation) {
        this.portOfDisembarkation = portOfDisembarkation;
    }

    public String getPortOfEmbarkation() {
        return portOfEmbarkation;
    }

    public void setPortOfEmbarkation(String portOfEmbarkation) {
        this.portOfEmbarkation = portOfEmbarkation;
    }

    public String getProposalId() {
        return proposalId;
    }

    public void setProposalId(String proposalId) {
        this.proposalId = proposalId;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getScheduledMonth() {
        return scheduledMonth;
    }

    public void setScheduledMonth(String scheduledMonth) {
        this.scheduledMonth = scheduledMonth;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getTimeIndicator() {
        return timeIndicator;
    }

    public void setTimeIndicator(String timeIndicator) {
        this.timeIndicator = timeIndicator;
    }

    public String getLabStudies() {
        return labStudies;
    }

    public void setLabStudies(String labStudies) {
        this.labStudies = labStudies;
    }

    public String getPostFieldActivity() {
        return postFieldActivity;
    }

    public void setPostFieldActivity(String postFieldActivity) {
        this.postFieldActivity = postFieldActivity;
    }

    public String getPreFieldActivity() {
        return preFieldActivity;
    }

    public void setPreFieldActivity(String preFieldActivity) {
        this.preFieldActivity = preFieldActivity;
    }

    public String getReportSubmission() {
        return reportSubmission;
    }

    public void setReportSubmission(String reportSubmission) {
        this.reportSubmission = reportSubmission;
    }

    public String getDeAllocateDate() {
        return deAllocateDate;
    }

    public void setDeAllocateDate(String deAllocateDate) {
        this.deAllocateDate = deAllocateDate;
    }

    public Boolean getFlagForDeallocateEmp() {
        return flagForDeallocateEmp;
    }

    public void setFlagForDeallocateEmp(Boolean flagForDeallocateEmp) {
        this.flagForDeallocateEmp = flagForDeallocateEmp;
    }

    public Long getDeallocateByDirectorId() {
        return deallocateByDirectorId;
    }

    public void setDeallocateByDirectorId(Long deallocateByDirectorId) {
        this.deallocateByDirectorId = deallocateByDirectorId;
    }

    public Long getReplaceByDirectorId() {
        return replaceByDirectorId;
    }

    public void setReplaceByDirectorId(Long replaceByDirectorId) {
        this.replaceByDirectorId = replaceByDirectorId;
    }

    public ZonedDateTime getCreateDateForDeallocateEmp() {
        return createDateForDeallocateEmp;
    }

    public void setCreateDateForDeallocateEmp(ZonedDateTime createDateForDeallocateEmp) {
        this.createDateForDeallocateEmp = createDateForDeallocateEmp;
    }

    public ZonedDateTime getCreateDateForReplaceEmp() {
        return createDateForReplaceEmp;
    }

    public void setCreateDateForReplaceEmp(ZonedDateTime createDateForReplaceEmp) {
        this.createDateForReplaceEmp = createDateForReplaceEmp;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

}
