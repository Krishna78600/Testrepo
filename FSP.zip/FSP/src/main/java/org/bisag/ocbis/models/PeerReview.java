package org.bisag.ocbis.models;

import java.io.File;
import java.time.ZonedDateTime;
import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "fsp_peer_review")
public class PeerReview {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String proposalId;
    private Long fspFormId;

    private Long appliedForPeerReviewByPss;
    private Long appliedForPeerReviewToRmh;

    private Long appliedForPeerReviewToNmh;
    private String remarks;
    private String rmhRemarks;
    private String nmhRemarks;
    private String fsp_id;

    private String status;
    private ZonedDateTime rmhPeerReviewDate;
    private ZonedDateTime nmhPeerReviewDate;

    public String getNmhStatus() {
        return nmhStatus;
    }

    public void setNmhStatus(String nmhStatus) {
        this.nmhStatus = nmhStatus;
    }

    public String getRmhStatus() {
        return rmhStatus;
    }

    public void setRmhStatus(String rmhStatus) {
        this.rmhStatus = rmhStatus;
    }

    private ZonedDateTime pssAppliedCreatedDate;
    private String pssStatus;
    private Long fspApprovedByPssId;
    private ZonedDateTime pssExternalPeerCreatedDate;
    private ZonedDateTime pssUpdatedApprovalDate;
    private Long forwardedToDirectorOfPuId;
    private String filePathForNmh;
    private String filePathForRmh;
    private String filePathForAdg;
    private String nmhStatus;
    private String rmhStatus;

    public Long getFspApprovedByPssId() {
        return fspApprovedByPssId;
    }

    public String getFilePathForNmh() {
        return filePathForNmh;
    }

    public void setFilePathForNmh(String filePathForNmh) {
        this.filePathForNmh = filePathForNmh;
    }

    public String getFilePathForRmh() {
        return filePathForRmh;
    }

    public void setFilePathForRmh(String filePathForRmh) {
        this.filePathForRmh = filePathForRmh;
    }

    public void setFspApprovedByPssId(Long fspApprovedByPssId) {
        this.fspApprovedByPssId = fspApprovedByPssId;
    }

    private Long appliedForExternalPeerReviewByPss;
    private String pssExternalPeerRemarks;

    private String pssExternalPeerStatus;
    private ZonedDateTime pssExternalPeerUpdatedDate;

    private String pssPeerReviewRemarks;
    private String pssPeerReviewStatus;
    private ZonedDateTime pssPeerReviewDate;

    public String getRmhRemarks() {
        return rmhRemarks;
    }

    public String getPssStatus() {
        return pssStatus;
    }

    public void setPssStatus(String pssStatus) {
        this.pssStatus = pssStatus;
    }

    public ZonedDateTime getPssExternalPeerCreatedDate() {
        return pssExternalPeerCreatedDate;
    }

    public void setPssExternalPeerCreatedDate(ZonedDateTime pssExternalPeerCreatedDate) {
        this.pssExternalPeerCreatedDate = pssExternalPeerCreatedDate;
    }

    public ZonedDateTime getPssUpdatedApprovalDate() {
        return pssUpdatedApprovalDate;
    }

    public void setPssUpdatedApprovalDate(ZonedDateTime pssUpdatedApprovalDate) {
        this.pssUpdatedApprovalDate = pssUpdatedApprovalDate;
    }

    public Long getAppliedForExternalPeerReviewByPss() {
        return appliedForExternalPeerReviewByPss;
    }

    public void setAppliedForExternalPeerReviewByPss(Long appliedForExternalPeerReviewByPss) {
        this.appliedForExternalPeerReviewByPss = appliedForExternalPeerReviewByPss;
    }

    public String getPssExternalPeerRemarks() {
        return pssExternalPeerRemarks;
    }

    public void setPssExternalPeerRemarks(String pssExternalPeerRemarks) {
        this.pssExternalPeerRemarks = pssExternalPeerRemarks;
    }

    public String getPssExternalPeerStatus() {
        return pssExternalPeerStatus;
    }

    public void setPssExternalPeerStatus(String pssExternalPeerStatus) {
        this.pssExternalPeerStatus = pssExternalPeerStatus;
    }

    public ZonedDateTime getPssExternalPeerUpdatedDate() {
        return pssExternalPeerUpdatedDate;
    }

    public void setPssExternalPeerUpdatedDate(ZonedDateTime pssExternalPeerUpdatedDate) {
        this.pssExternalPeerUpdatedDate = pssExternalPeerUpdatedDate;
    }

    public void setRmhRemarks(String rmhRemarks) {
        this.rmhRemarks = rmhRemarks;
    }

    public String getNmhRemarks() {
        return nmhRemarks;
    }

    public void setNmhRemarks(String nmhRemarks) {
        this.nmhRemarks = nmhRemarks;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProposalId() {
        return proposalId;
    }

    public void setProposalId(String proposalId) {
        this.proposalId = proposalId;
    }

    public Long getFspFormId() {
        return fspFormId;
    }

    public void setFspFormId(Long fspFormId) {
        this.fspFormId = fspFormId;
    }

    public Long getAppliedForPeerReviewByPss() {
        return appliedForPeerReviewByPss;
    }

    public void setAppliedForPeerReviewByPss(Long appliedForPeerReviewByPss) {
        this.appliedForPeerReviewByPss = appliedForPeerReviewByPss;
    }

    public Long getAppliedForPeerReviewToRmh() {
        return appliedForPeerReviewToRmh;
    }

    public void setAppliedForPeerReviewToRmh(Long appliedForPeerReviewToRmh) {
        this.appliedForPeerReviewToRmh = appliedForPeerReviewToRmh;
    }

    public Long getAppliedForPeerReviewToNmh() {
        return appliedForPeerReviewToNmh;
    }

    public void setAppliedForPeerReviewToNmh(Long appliedForPeerReviewToNmh) {
        this.appliedForPeerReviewToNmh = appliedForPeerReviewToNmh;
    }

    public ZonedDateTime getPssAppliedCreatedDate() {
        return pssAppliedCreatedDate;
    }

    public void setPssAppliedCreatedDate(ZonedDateTime pssAppliedCreatedDate) {
        this.pssAppliedCreatedDate = pssAppliedCreatedDate;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFsp_id() {
        return fsp_id;
    }

    public void setFsp_id(String fsp_id) {
        this.fsp_id = fsp_id;
    }

    public ZonedDateTime getRmhPeerReviewDate() {
        return rmhPeerReviewDate;
    }

    public void setRmhPeerReviewDate(ZonedDateTime rmhPeerReviewDate) {
        this.rmhPeerReviewDate = rmhPeerReviewDate;
    }

    public ZonedDateTime getNmhPeerReviewDate() {
        return nmhPeerReviewDate;
    }

    public void setNmhPeerReviewDate(ZonedDateTime nmhPeerReviewDate) {
        this.nmhPeerReviewDate = nmhPeerReviewDate;
    }

    public Long getForwardedToDirectorOfPuId() {
        return forwardedToDirectorOfPuId;
    }

    public void setForwardedToDirectorOfPuId(Long forwardedToDirectorOfPuId) {
        this.forwardedToDirectorOfPuId = forwardedToDirectorOfPuId;
    }

    public String getPssPeerReviewRemarks() {
        return pssPeerReviewRemarks;
    }

    public void setPssPeerReviewRemarks(String pssPeerReviewRemarks) {
        this.pssPeerReviewRemarks = pssPeerReviewRemarks;
    }

    public String getPssPeerReviewStatus() {
        return pssPeerReviewStatus;
    }

    public void setPssPeerReviewStatus(String pssPeerReviewStatus) {
        this.pssPeerReviewStatus = pssPeerReviewStatus;
    }

    public ZonedDateTime getPssPeerReviewDate() {
        return pssPeerReviewDate;
    }

    public void setPssPeerReviewDate(ZonedDateTime pssPeerReviewDate) {
        this.pssPeerReviewDate = pssPeerReviewDate;
    }

    public String getFilePathForAdg() {
        return filePathForAdg;
    }

    public void setFilePathForAdg(String filePathForAdg) {
        this.filePathForAdg = filePathForAdg;
    }

}
