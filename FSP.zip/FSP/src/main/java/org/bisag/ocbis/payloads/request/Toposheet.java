package org.bisag.ocbis.payloads.request;

public record Toposheet(String toposheet_num) {
    
}