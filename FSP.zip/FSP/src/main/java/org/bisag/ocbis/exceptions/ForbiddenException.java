package org.bisag.ocbis.exceptions;

public class ForbiddenException extends Exception {
  public ForbiddenException(String msg) {
    super(msg);
  }
}
