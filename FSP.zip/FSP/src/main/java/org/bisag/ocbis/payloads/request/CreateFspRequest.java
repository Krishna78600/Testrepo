package org.bisag.ocbis.payloads.request;

public record CreateFspRequest(Long missionId, Long regionId, String missionName,
        String subMissionName, String themeName, String typeCode, String commercialCode,
        String regionName, String stateUnitName, String yearOfInitiation,
        String yearOfCompletion, String fieldSeasonYear, String proposalId, Integer stepsCompleted,
        String activityType) {
}
