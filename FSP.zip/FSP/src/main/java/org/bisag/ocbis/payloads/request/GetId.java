package org.bisag.ocbis.payloads.request;

public record GetId(String id, String code, String fspId, Long fspFormId) {
}
