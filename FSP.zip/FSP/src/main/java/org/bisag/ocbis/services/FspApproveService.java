package org.bisag.ocbis.services;

import java.time.ZonedDateTime;
import org.bisag.ocbis.models.FspApproveLog;
import org.bisag.ocbis.models.User;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.FspApproveLogRepo;
import org.bisag.ocbis.repository.FspApproveRepo;
import org.bisag.ocbis.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class FspApproveService {

        @Autowired
        FspApproveRepo fspApproveRepo;

        @Autowired
        FspApproveLogRepo fspApproveLogRepo;

        @Autowired
        UserRepository userRepo;

        @Transactional
        public EncryptedResponse forwardToSUhead(Long forwardedByOfficerUserId, Long forwardedToSuHeadId,
                        ZonedDateTime createdDate, Long fspFormId, String stateId, String Remarks, String status)
                        throws Exception {

                // AutoPush to suhead--> logic for finding suHead
                User userDetails = userRepo.findSuHeadStateWise(stateId);
                forwardedToSuHeadId = userDetails.getId();

                fspApproveLogRepo.forwardToSUheadLog(forwardedByOfficerUserId, forwardedToSuHeadId, createdDate,
                                fspFormId,
                                null,
                                null, null);

                fspApproveRepo.forwardToSUhead(forwardedByOfficerUserId, forwardedToSuHeadId, createdDate, fspFormId,
                                null,
                                null, null);

                return new EncryptedResponse("Forwarded to SU Head successfully");
        }

        @Transactional
        public EncryptedResponse forwardToRmhOfPmBySuHead(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {

                fspApproveRepo.forwardToRmhOfPmBySuHead(forwardeByOfficerUserId, forwardeToOfficerUserId, createdDate,
                                fspFormId, remarks, status, null);

                fspApproveLogRepo.forwardToRmhOfPmBySuHeadLog(forwardeByOfficerUserId, forwardeToOfficerUserId,
                                createdDate,
                                fspFormId, remarks, status, null);

                return new EncryptedResponse("Forwarded to RMH of Parent Mission successfully");
        }

        @Transactional
        public EncryptedResponse forwardToHodByRmhOfPm(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {
                fspApproveRepo.forwardToHodByRmhOfPm(forwardeByOfficerUserId, forwardeToOfficerUserId, createdDate,
                                fspFormId,
                                remarks, status, null);

                System.out.println("fspFormId in service" + fspFormId);
                fspApproveLogRepo.forwardToHodByRmhOfPmLog(forwardeByOfficerUserId, forwardeToOfficerUserId,
                                createdDate,
                                fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded to HOD successfully");
        }

        @Transactional
        public EncryptedResponse forwardToDdgofSmByHod(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {

                fspApproveRepo.forwardToDdgofSmByHod(forwardeByOfficerUserId, forwardeToOfficerUserId, createdDate,
                                fspFormId,
                                remarks, status, null);

                fspApproveLogRepo.forwardToDdgofSmByHodLog(forwardeByOfficerUserId, forwardeToOfficerUserId,
                                createdDate,
                                fspFormId,
                                remarks, status, null);
                return new EncryptedResponse("Forwarded to DDG of Submission successfully");
        }

        @Transactional
        public EncryptedResponse forwardToAdgOfPssByDdgofSm(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {

                fspApproveRepo.forwardToAdgOfPssByDdgofSm(forwardeByOfficerUserId, forwardeToOfficerUserId, createdDate,
                                fspFormId, remarks, status, null);

                fspApproveLogRepo.forwardToAdgOfPssByDdgofSmLog(forwardeByOfficerUserId, forwardeToOfficerUserId,
                                createdDate,
                                fspFormId, remarks, status, null);

                return new EncryptedResponse("Forwarded to DDG of Submission successfully");
        }

        @Transactional
        public EncryptedResponse forwardToHodBySu(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {

                fspApproveRepo.forwardToHodBySu(forwardeByOfficerUserId, forwardeToOfficerUserId, createdDate,
                                fspFormId,
                                remarks, status, null);

                fspApproveLogRepo.forwardToHodBySuLog(forwardeByOfficerUserId, forwardeToOfficerUserId, createdDate,
                                fspFormId,
                                remarks, status, null);
                return new EncryptedResponse("Forwarded to DDG of Submission successfully");
        }

        @Transactional
        public EncryptedResponse forwardedByAdgOfPss(Long forwardeByOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {

                fspApproveRepo.forwardedByAdgOfPss(forwardeByOfficerUserId, createdDate, fspFormId, remarks, status,
                                null);

                fspApproveLogRepo.forwardedByAdgOfPssLog(forwardeByOfficerUserId, createdDate, fspFormId, remarks,
                                status,
                                null);
                return new EncryptedResponse("Forwarded to DDG of Submission successfully");
        }

        @Transactional
        public EncryptedResponse forwardedToRhod(Long forwardedByOfficerUserId, Long forwardedToRhodId,
                        ZonedDateTime createdDate, Long fspFormId, String stateId, String Remarks, String status)
                        throws Exception {

                // AutoPush to Rhod--> logic for finding Rhod
                User userDetails = userRepo.findRhodStateWise(stateId);
                forwardedToRhodId = userDetails.getId();

                fspApproveRepo.forwardedToRhod(forwardedByOfficerUserId, forwardedToRhodId, createdDate, fspFormId,
                                null,
                                null, null);
                return new EncryptedResponse("forwarded to Rhod Succesfully");
        }

        @Transactional
        public EncryptedResponse forwardToHqdhByRhod(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {
                System.out.println("forwardedbyofficeuserid" + forwardeByOfficerUserId);
                fspApproveRepo.forwardToHqdhByRhod(forwardeByOfficerUserId, forwardeToOfficerUserId, createdDate,
                                fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded to RMH of Parent Mission successfully");
        }

        @Transactional
        public EncryptedResponse forwardToTrainingInstitueHodByHqdh(Long forwardeByOfficerUserId,
                        Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {
                System.out.println("forwardedbyofficeuserid" + forwardeByOfficerUserId);
                fspApproveRepo.forwardToTrainingInstitueHodByHqdh(forwardeByOfficerUserId, forwardeToOfficerUserId,
                                createdDate,
                                fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded to RMH of Parent Mission successfully");
        }

        @Transactional
        public EncryptedResponse forwardToAdgOfPssByTIHod(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {
                System.out.println("forwardedbyofficeuserid" + forwardeByOfficerUserId);
                fspApproveRepo.forwardToAdgOfPssByTIHod(forwardeByOfficerUserId, forwardeToOfficerUserId, createdDate,
                                fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded to RMH of Parent Mission successfully");
        }

        @Transactional
        public EncryptedResponse rejectFsp(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        String status, String remarks, Long fspFormId, ZonedDateTime createdDate) throws Exception {
                fspApproveRepo.rejectFsp(forwardeByOfficerUserId, forwardeToOfficerUserId, status, remarks,
                                fspFormId, createdDate);
                return new EncryptedResponse("Forwarded to DDG of Submission successfully");
        }

        @Transactional
        public EncryptedResponse returnFsp(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        String status, String remarks, Long fspFormId, ZonedDateTime createdDate) throws Exception {

                fspApproveRepo.returnFsp(forwardeByOfficerUserId, forwardeToOfficerUserId, status, remarks,
                                fspFormId, createdDate);
                return new EncryptedResponse("Forwarded to DDG of Submission successfully");
        }

        @Transactional
        public EncryptedResponse returnFspLog(Long fspFormId,
                        String proposalId, String firstApprovingAuthorityName, String parentMissionCode,
                        String subMissionCode,Long forwardedByOfficerUserId,Long forwardeToOfficerUserId, String status, String remarks) throws Exception {

                FspApproveLog fspApproveLog = new FspApproveLog();

                fspApproveLog.setCreateFspUserId(forwardeToOfficerUserId);
                fspApproveLog.setFspFormId(fspFormId);
                fspApproveLog.setProposalId(proposalId);
                fspApproveLog.setFirstApprovingAuthorityName(firstApprovingAuthorityName);
                fspApproveLog.setParentMissionCode(parentMissionCode);
                fspApproveLog.setSubMissionCode(subMissionCode);
                fspApproveLog.setIsCurrentlyActive(true);

                fspApproveLog.setReturnForwardedById(forwardedByOfficerUserId);
                fspApproveLog.setForwardedToFspCreaterId(forwardeToOfficerUserId);
                fspApproveLog.setReturnFspStatus(status);
                fspApproveLog.setReturnFspRemarks(remarks);
                fspApproveLog.setReturnFspCreatedDate(ZonedDateTime.now());

                FspApproveLog savedFspLog = fspApproveLogRepo.save(fspApproveLog);
                
                System.out.println("savedfsplogid"+ savedFspLog.getId());
                fspApproveLogRepo.setCurrentlyActiveFlag(fspFormId, savedFspLog.getId(), forwardeToOfficerUserId);

                return new EncryptedResponse("Forwarded to DDG of Submission successfully");
        }

}
