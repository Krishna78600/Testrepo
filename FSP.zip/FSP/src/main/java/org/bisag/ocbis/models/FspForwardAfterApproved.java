package org.bisag.ocbis.models;

import java.time.ZonedDateTime;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "fsp_forwarded_after_approved")
public class FspForwardAfterApproved {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String fsp_id;
    private Long fspForwardedByPssId;
    private ZonedDateTime fspForwardedByPssDate;
    private Long fspForwardedToDirectorOfPuId;
    private List<Long> fspAllocatedPsByDirectorOfPuIds;
    private Long forwardedToDrillingId;
    private ZonedDateTime assignToDrillingDate;
    private ZonedDateTime assignToPersonnelDate;

    public Long getFspForwardedToDirectorOfPuId() {
        return fspForwardedToDirectorOfPuId;
    }

    public void setFspForwardedToDirectorOfPuId(Long fspForwardedToDirectorOfPuId) {
        this.fspForwardedToDirectorOfPuId = fspForwardedToDirectorOfPuId;
    }

    public List<Long> getFspAllocatedPsByDirectorOfPuIds() {
        return fspAllocatedPsByDirectorOfPuIds;
    }

    public void setFspAllocatedPsByDirectorOfPuIds(List<Long> fspAllocatedPsByDirectorOfPuIds) {
        this.fspAllocatedPsByDirectorOfPuIds = fspAllocatedPsByDirectorOfPuIds;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFsp_id() {
        return fsp_id;
    }

    public void setFsp_id(String fsp_id) {
        this.fsp_id = fsp_id;
    }

    public Long getFspForwardedByPssId() {
        return fspForwardedByPssId;
    }

    public void setFspForwardedByPssId(Long fspForwardedByPssId) {
        this.fspForwardedByPssId = fspForwardedByPssId;
    }

    public Long getForwardedToDrillingId() {
        return forwardedToDrillingId;
    }

    public void setForwardedToDrillingId(Long forwardedToDrillingId) {
        this.forwardedToDrillingId = forwardedToDrillingId;
    }

    public ZonedDateTime getFspForwardedByPssDate() {
        return fspForwardedByPssDate;
    }

    public void setFspForwardedByPssDate(ZonedDateTime fspForwardedByPssDate) {
        this.fspForwardedByPssDate = fspForwardedByPssDate;
    }

    public ZonedDateTime getAssignToDrillingDate() {
        return assignToDrillingDate;
    }

    public void setAssignToDrillingDate(ZonedDateTime assignToDrillingDate) {
        this.assignToDrillingDate = assignToDrillingDate;
    }

    public ZonedDateTime getAssignToPersonnelDate() {
        return assignToPersonnelDate;
    }

    public void setAssignToPersonnelDate(ZonedDateTime assignToPersonnelDate) {
        this.assignToPersonnelDate = assignToPersonnelDate;
    }

}
