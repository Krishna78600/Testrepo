package org.bisag.ocbis.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Table
@Entity(name = "fsp_commodity")
public class Commodity {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
private Long fspFormId;
private String fspCommodityName;
private String fspSubCommodityName;
private String fspMineralType;
private String proposalId;

public Long getId() {
    return id;
}

public void setId(Long id) {
    this.id = id;
}

public Long getFspFormId() {
    return fspFormId;
}

public void setFspFormId(Long fspFormId) {
    this.fspFormId = fspFormId;
}

public String getFspCommodityName() {
    return fspCommodityName;
}

public void setFspCommodityName(String fspCommodityName) {
    this.fspCommodityName = fspCommodityName;
}

public String getFspSubCommodityName() {
    return fspSubCommodityName;
}

public void setFspSubCommodityName(String fspSubCommodityName) {
    this.fspSubCommodityName = fspSubCommodityName;
}

public String getFspMineralType() {
    return fspMineralType;
}

public void setFspMineralType(String fspMineralType) {
    this.fspMineralType = fspMineralType;
}

public String getProposalId() {
    return proposalId;
}

public void setProposalId(String proposalId) {
    this.proposalId = proposalId;
}

}
