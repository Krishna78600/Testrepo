package org.bisag.ocbis.controllers;

import org.apache.commons.io.FileUtils;
import org.bisag.ocbis.models.CreateFsp;
import org.bisag.ocbis.models.CruiseActivity;
import org.bisag.ocbis.models.FieldActivity;
import org.bisag.ocbis.models.FspApprove;
import org.bisag.ocbis.models.FspApproveLog;
import org.bisag.ocbis.models.FspForwardAfterApproved;
import org.bisag.ocbis.models.ParticipatingUnits;
import org.bisag.ocbis.models.PeerReview;
import org.bisag.ocbis.models.User;
import org.bisag.ocbis.payloads.request.AddWorkPlanRequest;
import org.bisag.ocbis.payloads.request.AllotDeallotPersonnel;
import org.bisag.ocbis.payloads.request.ApplyExternalPeerReviewRequest;
import org.bisag.ocbis.payloads.request.ApplyPeerReviewRequest;
import org.bisag.ocbis.payloads.request.ApprovalConsiderations;
import org.bisag.ocbis.payloads.request.AssignEmployees;
import org.bisag.ocbis.payloads.request.EncryptedRequest;
import org.bisag.ocbis.payloads.request.GetId;
import org.bisag.ocbis.payloads.request.Report;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.FspApproveLogRepo;
import org.bisag.ocbis.repository.FspApproveRepo;
import org.bisag.ocbis.repository.FspForwardAfterApprovedRepo;
import org.bisag.ocbis.repository.FspRepo;
import org.bisag.ocbis.repository.ParticipatingRepo;
import org.bisag.ocbis.repository.PeerReviewRepo;
import org.bisag.ocbis.repository.UserRepository;
import org.bisag.ocbis.services.FspApproveService;
import org.bisag.ocbis.utils.FileValidator;
import org.springframework.data.domain.Page;
import org.bisag.ocbis.enums.Designation;

import java.io.File;
import java.io.OutputStream;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.micrometer.common.util.StringUtils;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@RestController
@CrossOrigin("*")
@RequestMapping("/fspapprove")
public class FspApproveController {

    @Value("${fileServerPath}")
    String fileServerPath;

    @Autowired
    FspApproveRepo fspApproveRepo;

    @Autowired
    FspApproveLogRepo fspApproveLogRepo;

    @Autowired
    PeerReviewRepo peerReviewRepo;

    @Autowired
    FspApproveService fspApproveService;

    @Autowired
    FspRepo fsprepo;

    @Autowired
    UserRepository userRepo;

    @Autowired
    FspForwardAfterApprovedRepo fspForwardAfterApprovedRepo;

    @Autowired
    ParticipatingRepo participatingRepo;

    @PostMapping("/get-fsp-approve-factors")
    public <json> EncryptedResponse getFspApproveFactors(@Valid @RequestBody EncryptedRequest req) throws Exception {
        var body = req.bodyAs(GetId.class);
        List<Map<String, Object>> result = fspApproveRepo.getFspApproveFactors(body.fspFormId());
        return new EncryptedResponse(result);

    }

    @PostMapping("setintial-log-factors")
    public <json> EncryptedResponse setIntialLogFactors(@Valid @RequestBody EncryptedRequest req) throws Exception {
        var body = req.bodyAs(ApprovalConsiderations.class);

        Long fspCreatorId = body.fspCreatorId();
        Long fspFormId = body.fspFormId();
        String proposalId = body.proposalId();
        String firstApprovingAuthorityName = body.firstApprovingAuthority();
        String parentMission = body.parentMission();
        String subMission = body.subMission();

        System.out.println("called");

        FspApproveLog fspApproveLog = new FspApproveLog();

        fspApproveLog.setCreateFspUserId(fspCreatorId);
        fspApproveLog.setFspFormId(fspFormId);
        fspApproveLog.setProposalId(proposalId);
        fspApproveLog.setFirstApprovingAuthorityName(firstApprovingAuthorityName);
        fspApproveLog.setParentMissionCode(parentMission);
        fspApproveLog.setSubMissionCode(subMission);
        fspApproveLog.setIsCurrentlyActive(true);

        fspApproveLogRepo.save(fspApproveLog);
        return new EncryptedResponse("saved");

    }

    @Transactional
    @PostMapping("/return-fsp")
    public <json> EncryptedResponse ReturnFsp(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {
        var body = req.bodyAs(ApprovalConsiderations.class);

        ZonedDateTime createdDate = ZonedDateTime.now();

        Long fspFormId = body.fspFormId();
        String proposalId = body.proposalId();
        String firstApprovingAuthority = body.firstApprovingAuthority();
        String parentMission = body.parentMission();
        String subMission = body.subMission();

        Long forwardeToOfficerUserId = body.fspCreatorId();
        Long forwardedByOfficerUserId = user.getId();

        String remarks = body.remarks();
        String status = body.status();

        System.out.println("called return fsp");

        fspApproveService.returnFspLog(fspFormId, proposalId, firstApprovingAuthority,
                parentMission, subMission, forwardedByOfficerUserId, forwardeToOfficerUserId, status, remarks);

        fspApproveService.returnFsp(forwardedByOfficerUserId, forwardeToOfficerUserId, status, remarks, fspFormId,
                createdDate);

        return new EncryptedResponse("saved");

    }

    @PostMapping("/approve-fsp-leval-wise")
    public <json> EncryptedResponse approveFspLevalWise(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        var body = req.bodyAs(ApprovalConsiderations.class);

        Long forwardedToSuHeadId = Long.valueOf(0);
        Long forwardedToRhodId = Long.valueOf(0);

        Long forwardedByOfficerUserId = user.getId();
        Long forwardeToOfficerUserId = body.forwardeToOfficerUserId();

        ZonedDateTime createdDate = ZonedDateTime.now();
        String stateId = user.getStateId();

        Long fspCreatorId = body.fspCreatorId();
        Long fspFormId = body.fspFormId();
        // String proposalId = body.proposalId();
        String firstApprovingAuthority = body.firstApprovingAuthority();
        String parentMission = body.parentMission();
        String subMission = body.subMission();

        String remarks = body.remarks();
        String status = body.status();
        // String keyword = body.keyword();

        FspApprove fspApprove = fspApproveRepo.findByFormId(fspFormId);

        Long suHeadForwardedId = fspApprove.getForwardedToSuhead();
        Long rmhOfPmForwardedId = fspApprove.getForwardedToRmhOfPm();
        Long hodForwardedId = fspApprove.getForwardedToHod();
        Long ddgOfSmForwardedId = fspApprove.getForwardedToDdgOfSm();
        Long adgOfPssForwardedToId = fspApprove.getForwardedToAdgOfPss();
        Long adgOfPssForwardedById = fspApprove.getForwardedByAdgOfPss();
        Long trainingInstitueHqdhForwardedId = fspApprove.getForwardedToTrainingInstituteHqdh();
        Long trainingInstitueHodForwardedId = fspApprove.getForwardedToTrainingInstituteHod();
        Long rhodForwardedId = fspApprove.getForwardedToRhod();

        // Long fspCreatorId = fspApprove.getForwardedByFspCreater();

        if (status != null && status.equals("Reject")) {
            fspApproveService.rejectFsp(forwardedByOfficerUserId, fspCreatorId, status, remarks, fspFormId,
                    createdDate);
        }

        if (parentMission.equals("V")) {

            if (rhodForwardedId == null) {
                System.out.println("forward to rhod");
                fspApproveService.forwardedToRhod(forwardedByOfficerUserId, forwardedToRhodId, createdDate, fspFormId,
                        stateId, null, null);
                return new EncryptedResponse("Forwarded successfully");
            }

            if (trainingInstitueHqdhForwardedId == null) {
                System.out.println("forward to training institute tihqdh");
                fspApproveService.forwardToHqdhByRhod(forwardedByOfficerUserId, forwardeToOfficerUserId,
                        createdDate, fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded successfully");
            }

            if (trainingInstitueHodForwardedId == null) {
                System.out.println("forward to training institue ti hod");
                fspApproveService.forwardToTrainingInstitueHodByHqdh(forwardedByOfficerUserId, forwardeToOfficerUserId,
                        createdDate, fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded successfully");
            }

            if (adgOfPssForwardedToId == null) {
                System.out.println("forward to training adgof pss");
                fspApproveService.forwardToAdgOfPssByTIHod(forwardedByOfficerUserId, forwardeToOfficerUserId,
                        createdDate, fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded successfully");
            }

            if (adgOfPssForwardedById == null) {
                System.out.println("forward by adg of pss ");
                fspApproveService.forwardedByAdgOfPss(forwardedByOfficerUserId, createdDate, fspFormId, remarks, status,
                        null);
                return new EncryptedResponse("Forwarded successfully");
            }
        }

        // Conditions for state unit as firstapproving authority

        if (firstApprovingAuthority.equals("SU") &&
                (parentMission.equals("X") || parentMission.equals("Y")) &&
                (subMission.equals("X") || subMission.equals("Y"))) {

            if (suHeadForwardedId == null) {
                System.out.println("suHeadForwardedIdnull");
                fspApproveService.forwardToSUhead(forwardedByOfficerUserId, forwardedToSuHeadId, createdDate, fspFormId,
                        stateId, null, null);
                return new EncryptedResponse("Forwarded successfully");
            }
            if (rmhOfPmForwardedId == null) {
                System.out.println("rmhOfPmForwardedIdnull");
                fspApproveService.forwardToRmhOfPmBySuHead(forwardedByOfficerUserId, forwardeToOfficerUserId,
                        createdDate, fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded successfully");
            }
            if (hodForwardedId == null) {
                System.out.println("hodForwardedId");
                System.out.println("fspformId" + fspFormId);

                fspApproveService.forwardToHodByRmhOfPm(forwardedByOfficerUserId, forwardeToOfficerUserId, createdDate,
                        fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded successfully");
            }
            if (ddgOfSmForwardedId == null) {
                System.out.println("ddgOfSmForwardedIdnull");
                fspApproveService.forwardToDdgofSmByHod(forwardedByOfficerUserId, forwardeToOfficerUserId, createdDate,
                        fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded successfully");
            }
            if (adgOfPssForwardedToId == null) {
                System.out.println("adgOfPssForwardedId");
                fspApproveService.forwardToAdgOfPssByDdgofSm(forwardedByOfficerUserId, forwardeToOfficerUserId,
                        createdDate, fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded successfully");
            }
            if (adgOfPssForwardedById == null) {
                System.out.println("adgOfPssForwardedId");
                fspApproveService.forwardedByAdgOfPss(forwardedByOfficerUserId, createdDate, fspFormId, remarks, status,
                        null);
                return new EncryptedResponse("Forwarded successfully");
            }

        }

        if (firstApprovingAuthority.equals("SU") &&
                (parentMission.equals("STSS") || parentMission.equals("PSS") || parentMission.equals("Adss")) &&
                (subMission.equals("X"))) {

            System.out.println("called supoort system of SU");
            if (suHeadForwardedId == null) {
                fspApproveService.forwardToSUhead(forwardedByOfficerUserId, forwardedToSuHeadId, createdDate, fspFormId,
                        stateId, remarks, status);
                return new EncryptedResponse("Forwarded successfully");
            }

            if (hodForwardedId == null) {
                fspApproveService.forwardToHodBySu(forwardedByOfficerUserId, forwardeToOfficerUserId, createdDate,
                        fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded successfully");
            }

            if (adgOfPssForwardedById == null) {
                System.out.println("ddgOfSmForwardedIdnull");
                fspApproveService.forwardedByAdgOfPss(forwardedByOfficerUserId, createdDate, fspFormId, remarks, status,
                        null);
                return new EncryptedResponse("Forwarded successfully");
            }

        }

        // Conditions for region as firstapproving authority

        // if (firstApprovingAuthority.equals("Region") &&
        // (parentMission.equals("X") || parentMission.equals("Y")) &&
        // (subMission.equals("X") || subMission.equals("Y"))) {
        // fspApproveService.forwardToRMHofParentMission();
        // fspApproveService.forwardToHOD();
        // fspApproveService.forwardToDDGofSubmission();
        // fspApproveService.forwardToADGofPSS();
        // }

        // if (firstApprovingAuthority.equals("Region") &&
        // (parentMission.equals("STSS") || parentMission.equals("PSS") ||
        // parentMission.equals("AdSS")) &&
        // (subMission.equals("X"))) {
        // fspApproveService.forwardToHOD();
        // fspApproveService.forwardToADGofPSS();
        // }

        // Conditions for CHQ as firstapproving authority

        // if (firstApprovingAuthority.equals("CHQ") &&
        // (parentMission.equals("X") && subMission.equals("Y"))) {
        // fspApproveService.forwardToDDGofSubmission();
        // fspApproveService.forwardToNMHofParentMission();
        // fspApproveService.forwardToADGofPSS();
        // }

        // if (firstApprovingAuthority.equals("CHQ") &&
        // (parentMission.equals("X") && subMission.equals("X"))) {
        // fspApproveService.forwardToNMHofParentMission();
        // fspApproveService.forwardToADGofPSS();
        // }

        // Conditions for STSS/AdSS CHQ as firstapproving authority

        // if (firstApprovingAuthority.equals("STSS/AdSS CHQ") &&
        // (parentMission.equals("X") && subMission.equals("Y"))) {
        // fspApproveService.forwardToDDGofSTSSorADSS();
        // fspApproveService.forwardToADGofPSS();
        // }

        // if (firstApprovingAuthority.equals("STSS/AdSS CHQ") &&
        // (parentMission.equals("X") && subMission.equals("X"))) {
        // fspApproveService.forwardToADGofSTSSorADSS();
        // fspApproveService.forwardToADGofPSS();
        // }

        // Conditions for PSS CHQ as firstapproving authority

        // if (firstApprovingAuthority.equals("PSS CHQ") &&
        // (parentMission.equals("X") && subMission.equals("Y"))) {
        // fspApproveService.forwardToDDGofSubmission();
        // fspApproveService.forwardToADGofPSS();
        // }

        // if (firstApprovingAuthority.equals("PSS CHQ") &&
        // (parentMission.equals("X") && subMission.equals("X"))) {
        // fspApproveService.forwardToADGofPSS();
        // }
        return new EncryptedResponse("Forwarded successfully");
    }

    @SuppressWarnings("unused")
    @PostMapping("/approve-fsp-level-officers")
    public <jFson> EncryptedResponse approveFspLevalWiseOfficerList(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        var body = req.bodyAs(ApprovalConsiderations.class);

        Long forwardedToSuHeadId = Long.valueOf(0);

        String stateId = user.getStateId();
        Long forwardedByFspCreaterId = user.getId();
        ZonedDateTime createdDate = ZonedDateTime.now();

        String firstApprovingAuthority = body.firstApprovingAuthority();
        String parentMission = body.parentMission();
        String subMission = body.subMission();
        Long fspFormId = body.fspFormId();

        FspApprove fspApprove = fspApproveRepo.findByFormId(fspFormId);

        Long suHeadForwardedId = fspApprove.getForwardedToSuhead();
        Long rmhOfPmForwardedId = fspApprove.getForwardedToRmhOfPm();
        Long hodForwardedId = fspApprove.getForwardedToHod();
        Long ddgOfSmForwardedId = fspApprove.getForwardedToDdgOfSm();
        Long adgOfPssForwardedToId = fspApprove.getForwardedToAdgOfPss();
        Long adgOfPssForwardedById = fspApprove.getForwardedByAdgOfPss();
        Long rhodForwardedId = fspApprove.getForwardedToRhod();
        Long trainingInstitueHqdhForwardedId = fspApprove.getForwardedToTrainingInstituteHqdh();
        Long trainingInstitueHodForwardedId = fspApprove.getForwardedToTrainingInstituteHod();

        if (parentMission.equals("V")) {

            if (rhodForwardedId != 0 && user.getDesignationId().equals(Designation.RHOD.getValue())) {
                System.out.println("return trainingInstitue HQDH list");
                List<Map<String, Object>> result = userRepo.getTrainingInstitueHqdh(user.getStateId());

                HashMap<String, Object> responseMap = new HashMap<>();
                responseMap.put("title", "trainingInstitue HQDH List");
                responseMap.put("keyword", "trainingInstituehqdh");
                responseMap.put("result", result);

                return new EncryptedResponse(responseMap);
            }

            if (trainingInstitueHqdhForwardedId != 0 && user.getDesignationId().equals(Designation.TIHQDH.getValue())) {
                System.out.println("return trainingInstitue HOD list");
                List<Map<String, Object>> result = userRepo.getTrainingInstitueHod(user.getStateId());

                HashMap<String, Object> responseMap = new HashMap<>();
                responseMap.put("title", "trainingInstitue HOD List");
                responseMap.put("keyword", "trainingInstituehod");
                responseMap.put("result", result);

                return new EncryptedResponse(responseMap);
            }

            if (trainingInstitueHodForwardedId != 0 && user.getDesignationId().equals(Designation.TIHOD.getValue())) {
                System.out.println("return trainingInstitue ADG OR PSS list");

                List<Map<String, Object>> result = userRepo.getAdditionalDirectorGeneralList(user.getStateId());

                HashMap<String, Object> responseMap = new HashMap<>();
                responseMap.put("title", "Additional Director General List");
                responseMap.put("keyword", "adg");
                responseMap.put("result", result);
                return new EncryptedResponse(responseMap);
            }
        }

        if (firstApprovingAuthority.equals("SU") &&
                (parentMission.equals("X") || parentMission.equals("Y")) &&
                (subMission.equals("X") || subMission.equals("Y"))) {

            if (suHeadForwardedId != 0 && user.getDesignationId().equals(Designation.StateUnitHead.getValue())) {
                List<Map<String, Object>> result = userRepo.getRegionalMissionHeadList(user.getStateId());

                HashMap<String, Object> responseMap = new HashMap<>();
                responseMap.put("title", "Regional Mission Head List");
                responseMap.put("keyword", "rmhofpm");
                responseMap.put("result", result);
                return new EncryptedResponse(responseMap);
            }

            if (rmhOfPmForwardedId != 0 && user.getDesignationId().equals(Designation.RMH.getValue())) {
                List<Map<String, Object>> result = userRepo.getHeadOfDepartmentList(user.getStateId());

                HashMap<String, Object> responseMap = new HashMap<>();
                responseMap.put("title", "Head of the department List");
                responseMap.put("keyword", "hod");
                responseMap.put("result", result);
                return new EncryptedResponse(responseMap);
            }

            if (hodForwardedId != 0 && user.getDesignationId().equals(Designation.HOD.getValue())) {

                System.out.println("caledddddddddddddddd");
                List<Map<String, Object>> result = userRepo.getDeputyDirectorGeneralList(user.getStateId());

                HashMap<String, Object> responseMap = new HashMap<>();
                responseMap.put("title", "Deputy Director General List");
                responseMap.put("keyword", "ddg");
                responseMap.put("result", result);
                return new EncryptedResponse(responseMap);
            }

            if (ddgOfSmForwardedId != 0 && user.getDesignationId().equals(Designation.DDG.getValue())) {
                List<Map<String, Object>> result = userRepo.getAdditionalDirectorGeneralList(user.getStateId());

                HashMap<String, Object> responseMap = new HashMap<>();
                responseMap.put("title", "Additional Director General List");
                responseMap.put("keyword", "adg");
                responseMap.put("result", result);
                return new EncryptedResponse(responseMap);
            }

        }

        if (firstApprovingAuthority.equals("SU") &&
                (parentMission.equals("STSS") || parentMission.equals("PSS") || parentMission.equals("Adss")) &&
                (subMission.equals("X"))) {

            System.out.println("called supoort system of SU");

            if (suHeadForwardedId != 0) {
                List<Map<String, Object>> result = userRepo.getHeadOfDepartmentList(user.getStateId());

                HashMap<String, Object> responseMap = new HashMap<>();
                responseMap.put("title", "Head of Department List");
                responseMap.put("keyword", "hod");
                responseMap.put("result", result);
                return new EncryptedResponse(responseMap);
            }

            if (hodForwardedId != 0) {
                List<Map<String, Object>> result = userRepo.getAdditionalDirectorGeneralList(user.getStateId());

                HashMap<String, Object> responseMap = new HashMap<>();
                responseMap.put("title", "Additional Director General List");
                responseMap.put("keyword", "adg");
                responseMap.put("result", result);
                return new EncryptedResponse(responseMap);
            }
        }

        return new EncryptedResponse("Forwarded successfully");
    }

    @Transactional
    @PostMapping("/apply-peer-review")
    public EncryptedResponse applyPeerReview(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        var body = req.bodyAs(ApplyPeerReviewRequest.class);

        System.out.println("body :" + body);

        Long appliedForPeerReviewByPssId = user.getId();
        ZonedDateTime createdDate = ZonedDateTime.now();
        String regionalId = body.region();
        Long fspFormId = body.fspFormId();
        String remark = body.remarks();
        Long rmh = body.appliedForPeerReviewToRmh();
        Long nmh = body.appliedForPeerReviewToNmh();

        System.out.println(regionalId + "regionalId" + body.fspFormId());

        PeerReview peerReview = new PeerReview();
        peerReview.setFspFormId(fspFormId);
        peerReview.setRemarks(remark);
        peerReview.setProposalId(body.proposalId());
        peerReview.setAppliedForPeerReviewByPss(appliedForPeerReviewByPssId);
        peerReview.setAppliedForPeerReviewToRmh(rmh);
        peerReview.setAppliedForPeerReviewToNmh(nmh);
        peerReview.setPssAppliedCreatedDate(createdDate);
        peerReview.setStatus(body.status());
        peerReviewRepo.save(peerReview);

        return new EncryptedResponse("Peer Review Initiated");
    }

    @PostMapping("approve-fsp-by-pss")
    public EncryptedResponse approveFspByPss(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        var body = req.bodyAs(GetId.class);
        Long fspFormId = body.fspFormId();

        System.out.println("fspFormId:++++" + fspFormId);
        PeerReview peerReview = peerReviewRepo.findByPssFormId(body.fspFormId());
        peerReview.setPssStatus("Approved");
        peerReview.setPssUpdatedApprovalDate(ZonedDateTime.now());
        peerReview.setFspApprovedByPssId(user.getId());

        CreateFsp createFsp = fsprepo.findByFormId(body.fspFormId());
        Long lastSerialNo = userRepo.findMaxSerialNo();
        long newSerialNo = lastSerialNo + 1;
        String serialNo = String.format("%05d", newSerialNo);

        String generateFspId = createFsp.getTypeCode() + "/" + createFsp.getCommercialCode() + "/"
                + createFsp.getRegionName() + "/" + createFsp.getStateUnitName() + "/" + createFsp.getYearOfInitiation()
                + "/" + serialNo;

        createFsp.setFspId(generateFspId);
        fsprepo.save(createFsp);
        peerReview.setFsp_id(generateFspId);
        peerReviewRepo.save(peerReview);
        fspApproveRepo.updateFspDirector();

        return new EncryptedResponse("Approved FSP by PSS");
    }

    @PostMapping("start-external-peer-review-by-pss")
    public EncryptedResponse applyExternalPeerReviewByPss(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        var body = req.bodyAs(GetId.class);
        Long fspFormId = body.fspFormId();

        System.out.println("fspFormId:++++" + fspFormId);
        PeerReview peerReview = peerReviewRepo.findByPssFormId(body.fspFormId());
        peerReview.setPssExternalPeerStatus("FSP send to QMS Cell");
        peerReview.setPssExternalPeerCreatedDate(ZonedDateTime.now());

        peerReviewRepo.save(peerReview);

        return new EncryptedResponse("FSP External Peer Review send to QMS Cell");
    }

    @Transactional
    @PostMapping("/apply-external-peer-review")
    public EncryptedResponse applyExternalPeerReview(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        var body = req.bodyAs(ApplyExternalPeerReviewRequest.class);

        System.out.println("body :" + body);

        Long appliedForExternalPeerReviewByPssId = user.getId();
        ZonedDateTime createdDate = ZonedDateTime.now();
        String regionalId = body.region();
        Long fspFormId = body.fspFormId();
        String remarks = body.pss_external_peer_remarks();
        String status = body.pss_external_peer_status();
        String proposalId = body.proposalId();
        Long id = body.id();
        System.out.println("body.Id() :" + body.id());

        PeerReview peerReview = peerReviewRepo.findByPeerId(body.id());
        if (peerReview != null) {
            peerReview.setAppliedForExternalPeerReviewByPss(appliedForExternalPeerReviewByPssId);
            peerReview.setPssExternalPeerRemarks(remarks);
            peerReview.setPssExternalPeerStatus(status);
            peerReview.setPssExternalPeerUpdatedDate(createdDate);
            peerReview.setPssPeerReviewStatus(status);

            if (status != null) {
                if ("Approve".equals(status)) {
                    peerReview.setPssStatus("Approved");

                    CreateFsp createFsp = fsprepo.findByFormId(body.fspFormId());

                    String file = body.adgDoc();
                    if (StringUtils.isNotBlank(file)) {
                        byte[] pdfBytes = Base64.getDecoder().decode(file.split(",")[1]);
                        FileValidator.validateFileSize(pdfBytes, 5);
                        FileValidator.validatePdf(pdfBytes);
                        // FileValidator.validateImage(pdfBytes);
                        var uuid = UUID.randomUUID().toString();
                        var filePath = fileServerPath + "ExternalPeerReview/" + uuid + ".pdf";
                        var file1 = new File(filePath);
                        try (OutputStream stream = FileUtils.openOutputStream(file1)) {
                            stream.write(pdfBytes);
                        }
                        peerReview.setFilePathForAdg(filePath);
                    }

                    Long lastSerialNo = userRepo.findMaxSerialNo();
                    long newSerialNo = lastSerialNo + 1;
                    String serialNo = String.format("%05d", newSerialNo);

                    String generateFspId = createFsp.getTypeCode() + "/" + createFsp.getCommercialCode() + "/"
                            + createFsp.getRegionName() + "/" + createFsp.getStateUnitName() + "/"
                            + createFsp.getYearOfInitiation()
                            + "/" + serialNo;

                    createFsp.setFspId(generateFspId);
                    fsprepo.save(createFsp);
                    peerReview.setFsp_id(generateFspId);
                    peerReview.setFspApprovedByPssId(user.getId());
                    fspApproveRepo.updateFspDirector();
                }
            }
            peerReviewRepo.save(peerReview);

        }

        FspApprove fspApprove = fspApproveRepo.findByFormId(fspFormId);

        Long fspCreatorId = fspApprove.getForwardedByFspCreater();

        if (status != null) {
            if ("Reject".equals(status)) {
                System.out.println("rejected");
                fspApproveService.rejectFsp(user.getId(), fspCreatorId, status, remarks, fspFormId, createdDate);
            }
        }

        if (status != null) {
            if ("Return".equals(status)) {
                System.out.println("return");
                fspApproveService.returnFsp(user.getId(), fspCreatorId, status, remarks, fspFormId, createdDate);
            }
        }

        return new EncryptedResponse("External Peer Review Initiated");
    }

    @PostMapping("/get-approved-fsp-after-peer-review")
    public EncryptedResponse getFspForPeerReview(@AuthenticationPrincipal User user, @RequestBody EncryptedRequest req)
            throws Exception {

        var body = req.bodyAs(Report.class);
        var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
        System.out.println("testtttt" + user.getId());
        Page<Map<String, Object>> result = fsprepo.getApprovedFspAfterPeerReview(user.getStateId(), user.getId(),
                pageable);
        return new EncryptedResponse(result);
    }

    @PostMapping("/assign-fsp-to-director")
    public <json> EncryptedResponse getParentMission(
            HttpServletResponse response) throws Exception {
        // var body = Json.deserialize(CreateFspRequest.class, req.data());
        // String username = body.username();
        List<Map<String, Object>> result = fsprepo.assignFspToDirector();
        return new EncryptedResponse(result);
    }

    @PostMapping("/assign-fsp-to-employees")
    public EncryptedResponse assignFspToEmployees(@AuthenticationPrincipal User user, @RequestBody EncryptedRequest req)
            throws Exception {

        var body = req.bodyAs(AssignEmployees.class);
        System.out.println("body:::" + body);
        ZonedDateTime createdDate = ZonedDateTime.now();

        for (Long employeeId : body.employees_list()) {
            List<Long> employeeIdList = new ArrayList<>();
            employeeIdList.add(employeeId);

            FspForwardAfterApproved fspForwardAfterApproved = new FspForwardAfterApproved();
            fspForwardAfterApproved.setFsp_id(body.fsp_id());
            fspForwardAfterApproved.setFspAllocatedPsByDirectorOfPuIds(employeeIdList);
            fspForwardAfterApproved.setAssignToPersonnelDate(createdDate);
            fspForwardAfterApproved.setFspForwardedToDirectorOfPuId(user.getId());
            fspForwardAfterApprovedRepo.save(fspForwardAfterApproved);
        }

        return new EncryptedResponse("Employees Assign Successfully");
    }

    @PostMapping("approve-reject-return-fsp-by-pss")
    public EncryptedResponse approveRejectReturnFspByPss(@Valid @RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        var body = req.bodyAs(ApplyPeerReviewRequest.class);
        System.out.println("body::" + body);
        Long fspFormId = body.fspFormId();
        String status = body.pssStatus();
        String remarks = body.pssPeerReviewRemarks();
        ZonedDateTime createdDate = ZonedDateTime.now();

        System.out.println("fspFormId:++++" + fspFormId);
        System.out.println("fspFormId:++++" + remarks);
        FspApprove fspApprove = fspApproveRepo.findByFormId(fspFormId);

        if (user.getDesignationId().equals("5")) {
            System.out.println("called rmh");
            PeerReview peerReview = peerReviewRepo.findByPssFormId(body.fspFormId());
            peerReview.setRmhRemarks(body.rmh_remarks());
            peerReview.setRmhStatus("Applied");
            peerReview.setRmhPeerReviewDate(createdDate);

            String file = body.rmhFile();
            if (StringUtils.isNotBlank(file)) {
                byte[] pdfBytes = Base64.getDecoder().decode(file.split(",")[1]);
                FileValidator.validateFileSize(pdfBytes, 5);
                FileValidator.validatePdf(pdfBytes);
                // FileValidator.validateImage(pdfBytes);
                var uuid = UUID.randomUUID().toString();
                var filePath = fileServerPath + "PeerReview/" + uuid + ".pdf";
                var file1 = new File(filePath);
                try (OutputStream stream = FileUtils.openOutputStream(file1)) {
                    stream.write(pdfBytes);
                }
                peerReview.setFilePathForRmh(filePath);
            }
            peerReviewRepo.save(peerReview);

        } else if (user.getDesignationId().equals("6")) {
            System.out.println("called nmh");
            PeerReview peerReview = peerReviewRepo.findByPssFormId(body.fspFormId());
            peerReview.setNmhRemarks(body.nmh_remarks());
            peerReview.setNmhStatus("Applied");
            peerReview.setNmhPeerReviewDate(createdDate);

            String file = body.nmhFile();
            if (StringUtils.isNotBlank(file)) {
                byte[] pdfBytes = Base64.getDecoder().decode(file.split(",")[1]);
                FileValidator.validateFileSize(pdfBytes, 5);
                FileValidator.validatePdf(pdfBytes);
                var uuid = UUID.randomUUID().toString();
                var filePath = fileServerPath + "PeerReview/" + uuid + ".pdf";
                var file1 = new File(filePath);
                try (OutputStream stream = FileUtils.openOutputStream(file1)) {
                    stream.write(pdfBytes);
                }
                peerReview.setFilePathForNmh(filePath);
            }
            peerReviewRepo.save(peerReview);

        } else {
            Long fspCreatorId = fspApprove.getForwardedByFspCreater();
            if (status != null) {
                if ("Approve".equals(status)) {
                    System.out.println("Approve");
                    PeerReview peerReview = peerReviewRepo.findByPssFormId(body.fspFormId());
                    peerReview.setPssPeerReviewStatus("Approved");
                    peerReview.setPssPeerReviewDate(createdDate);
                    peerReview.setFspApprovedByPssId(user.getId());
                    peerReview.setPssPeerReviewRemarks(remarks);

                    String file = body.adgDoc();
                    if (StringUtils.isNotBlank(file)) {
                        byte[] pdfBytes = Base64.getDecoder().decode(file.split(",")[1]);
                        FileValidator.validateFileSize(pdfBytes, 5);
                        FileValidator.validatePdf(pdfBytes);
                        // FileValidator.validateImage(pdfBytes);
                        var uuid = UUID.randomUUID().toString();
                        var filePath = fileServerPath + "ExternalPeerReview/" + uuid + ".pdf";
                        var file1 = new File(filePath);
                        try (OutputStream stream = FileUtils.openOutputStream(file1)) {
                            stream.write(pdfBytes);
                        }
                        peerReview.setFilePathForAdg(filePath);
                    }

                    CreateFsp createFsp = fsprepo.findByFormId(body.fspFormId());
                    Long lastSerialNo = userRepo.findMaxSerialNo();
                    long newSerialNo = lastSerialNo + 1;
                    String serialNo = String.format("%05d", newSerialNo);

                    String generateFspId = createFsp.getTypeCode() + "/" +
                            createFsp.getCommercialCode() + "/"
                            + createFsp.getRegionName() + "/" + createFsp.getStateUnitName() + "/"
                            + createFsp.getYearOfInitiation()
                            + "/" + serialNo;

                    createFsp.setFspId(generateFspId);
                    fsprepo.save(createFsp);
                    peerReview.setFsp_id(generateFspId);
                    peerReviewRepo.save(peerReview);
                    fspApproveRepo.updateFspDirector();

                } else if ("Reject".equals(status)) {
                    System.out.println("rejected");
                    PeerReview peerReview = peerReviewRepo.findByPssFormId(body.fspFormId());
                    peerReview.setPssPeerReviewStatus("Rejected");
                    peerReview.setPssPeerReviewDate(createdDate);
                    peerReview.setFspApprovedByPssId(user.getId());
                    peerReview.setPssPeerReviewRemarks(remarks);
                    String file = body.adgDoc();
                    if (StringUtils.isNotBlank(file)) {
                        byte[] pdfBytes = Base64.getDecoder().decode(file.split(",")[1]);
                        FileValidator.validateFileSize(pdfBytes, 5);
                        FileValidator.validatePdf(pdfBytes);
                        // FileValidator.validateImage(pdfBytes);
                        var uuid = UUID.randomUUID().toString();
                        var filePath = fileServerPath + "ExternalPeerReview/" + uuid + ".pdf";
                        var file1 = new File(filePath);
                        try (OutputStream stream = FileUtils.openOutputStream(file1)) {
                            stream.write(pdfBytes);
                        }
                        peerReview.setFilePathForAdg(filePath);
                    }
                    peerReviewRepo.save(peerReview);

                    fspApproveService.rejectFsp(user.getId(), fspCreatorId, status, remarks, fspFormId, createdDate);
                } else if ("Return".equals(status)) {
                    System.out.println("return");
                    PeerReview peerReview = peerReviewRepo.findByPssFormId(body.fspFormId());
                    peerReview.setPssPeerReviewStatus("Return");
                    peerReview.setPssPeerReviewDate(createdDate);
                    peerReview.setFspApprovedByPssId(user.getId());
                    peerReview.setPssPeerReviewRemarks(remarks);
                    String file = body.adgDoc();
                    if (StringUtils.isNotBlank(file)) {
                        byte[] pdfBytes = Base64.getDecoder().decode(file.split(",")[1]);
                        FileValidator.validateFileSize(pdfBytes, 5);
                        FileValidator.validatePdf(pdfBytes);
                        // FileValidator.validateImage(pdfBytes);
                        var uuid = UUID.randomUUID().toString();
                        var filePath = fileServerPath + "ExternalPeerReview/" + uuid + ".pdf";
                        var file1 = new File(filePath);
                        try (OutputStream stream = FileUtils.openOutputStream(file1)) {
                            stream.write(pdfBytes);
                        }
                        peerReview.setFilePathForAdg(filePath);
                    }
                    peerReviewRepo.save(peerReview);
                    fspApproveService.returnFsp(user.getId(), fspCreatorId, status, remarks, fspFormId, createdDate);
                } else {
                    return new EncryptedResponse("Status is null");
                }
            }
        }

        return new EncryptedResponse("Peer Review Initiated");
    }

    @PostMapping("/get-fsp-details-for-personnel")
    public EncryptedResponse getFspDetailsForPersonnel(@AuthenticationPrincipal User user,
            @RequestBody EncryptedRequest req)
            throws Exception {

        var body = req.bodyAs(Report.class);
        var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());

        Page<Map<String, Object>> result = fspForwardAfterApprovedRepo.getApprovedFspForPersonnelStream(
                user.getStateId(),
                pageable);
        return new EncryptedResponse(result);
    }

    @Transactional
    @PostMapping("/save-workplan")
    public <json> EncryptedResponse saveWorkPlan(@RequestBody EncryptedRequest req,
            @AuthenticationPrincipal User user) throws Exception {

        var body = req.bodyAs(AddWorkPlanRequest.class);
        ParticipatingUnits participatingUnits = participatingRepo.findByFspId(body.fspId(), user.getEmployeeId());
        // System.out.println("body.fspId():" + body.fspId());

        if (participatingUnits != null) {
            // Update basic fields
            participatingUnits.setLabStudies(body.labStudies());
            participatingUnits.setPostFieldActivity(body.postFieldActivity());
            participatingUnits.setPreFieldActivity(body.preFieldActivity());
            participatingUnits.setReportSubmission(body.reportSubmission());
            participatingUnits.setFspId(body.fspId());
            participatingUnits.setProposalId(body.proposalId());
            participatingUnits.setEmployeeName(user.getEmployeeName());

            // Update Field Activities
            List<FieldActivity> existingFieldActivities = participatingUnits.getFieldActivities();
            // Clear existing activities if you want to replace them
            existingFieldActivities.clear();

            for (FieldActivity fieldActivity : body.fieldActivity()) {
                fieldActivity.setParticipatingUnits(participatingUnits);
                existingFieldActivities.add(fieldActivity); // Add new or updated activities
            }

            // Update Cruise Activities
            List<CruiseActivity> existingCruiseActivities = participatingUnits.getCruiseActivities();
            // Clear existing activities if you want to replace them
            existingCruiseActivities.clear();

            for (CruiseActivity cruiseActivity : body.cruiseActivity()) {
                cruiseActivity.setParticipatingUnits(participatingUnits);
                existingCruiseActivities.add(cruiseActivity);
            }

            participatingRepo.save(participatingUnits);
            return new EncryptedResponse("Work Plan Added Successfully!");
        }

        return new EncryptedResponse("Participating Units not found!");
    }

    @PostMapping("/allotment-deallotment-and-replace-personnel")
    public EncryptedResponse allotmentDeallotmentAndReplacePersonnel(@AuthenticationPrincipal User user,
            @RequestBody EncryptedRequest req) throws Exception {
        var body = req.bodyAs(AllotDeallotPersonnel.class);

        System.out.println("body: " + body);
        String status = body.status();
        ZonedDateTime createdDate = ZonedDateTime.now();

        // Step 1: Update the existing employee's status
        ParticipatingUnits participatingUnits = participatingRepo.findByFspId(body.fspId(), body.employeeId());
        if (status.equals("Allocated")) {
            participatingUnits.setFspId(body.fspId());
            participatingUnits.setProposalId(body.proposalId());
            participatingUnits.setEmployeeId(body.employeeId());
            participatingUnits.setStatus(body.status());
            // participatingUnits.setEmployeeName(body.employeeName());
            participatingRepo.save(participatingUnits);
        } else if (status.equals("Deallocated")) {
            participatingUnits.setStatus(body.status());
            participatingUnits.setDeAllocateDate(body.deallocateDate());
            participatingUnits.setFlagForDeallocateEmp(true);
            participatingUnits.setDeallocateByDirectorId(user.getId());
            participatingUnits.setCreateDateForDeallocateEmp(createdDate);
            participatingRepo.save(participatingUnits);

        } else if (status.equals("Replaced")) {

            if (participatingUnits != null) {
                participatingUnits.setStatus(body.status());
                participatingRepo.save(participatingUnits);

            } else {
                return new EncryptedResponse("Error: Existing employee not found.");
            }

            // Step 2: Save the new employee with Allocated status
            ParticipatingUnits newEmployee = new ParticipatingUnits();
            newEmployee.setFspId(body.fspId());
            newEmployee.setProposalId(body.proposalId());
            newEmployee.setEmployeeId(body.newEmployeeId());
            newEmployee.setStatus("Allocated");
            newEmployee.setEmployeeName(body.employeeName());
            newEmployee.setEmployeeDesignation(body.employeeDesignation());
            newEmployee.setReplaceByDirectorId(user.getId());
            newEmployee.setCreateDateForReplaceEmp(createdDate);

            participatingRepo.save(newEmployee);

        } else {
            return new EncryptedResponse("Something went wrong");

        }
        // ParticipatingUnits participatingUnits = new ParticipatingUnits();

        return new EncryptedResponse("Success");
    }

    @PostMapping("/get-fsp-allotment-for-personnel")
    public EncryptedResponse getFspAllotmentForPersonnel(@AuthenticationPrincipal User user,
            @RequestBody EncryptedRequest req)
            throws Exception {

        var body = req.bodyAs(Report.class);
        var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());

        Page<Map<String, Object>> result = participatingRepo.getAllotmentFspToPersonnel(
                user.getEmployeeId(),
                pageable);
        return new EncryptedResponse(result);
    }

    @PostMapping("/get-approved-fsp-after-peer-review/export")
    public EncryptedResponse getFspForPeerReviewExport(@AuthenticationPrincipal User user,
            @RequestBody EncryptedRequest req)
            throws Exception {

        var body = req.bodyAs(Report.class);
        var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
        System.out.println("testtttt" + user.getId());
        List<Map<String, Object>> result = fspApproveRepo.getApprovedFspAfterPeerReviewExport(user.getStateId(),
                user.getId());
        return new EncryptedResponse(result);
    }

    @PostMapping("/get-fsp-for-peer-review-rmh-nmh/export")
    public EncryptedResponse getFspForPeerReviewRmhNmhExport(@AuthenticationPrincipal User user,
            @RequestBody EncryptedRequest req)
            throws Exception {

        var body = req.bodyAs(Report.class);
        var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
        System.out.println("testtttt" + user.getId());
        List<Map<String, Object>> result = fspApproveRepo.getFspForPeerReviewRmhNmhExport(user.getStateId());
        return new EncryptedResponse(result);
    }

    @PostMapping("/get-employees-for-allotment")
    public EncryptedResponse getEmployeesForAllotment(
            @AuthenticationPrincipal User user,
            @RequestBody EncryptedRequest req) throws Exception {

        var body = req.bodyAs(GetId.class);
        String fspId = body.fspId();
        System.out.println("fspid" + fspId);
        // Fetch employee details
        List<Map<String, Object>> employeeList = userRepo.getEmployeesForAllotment(fspId);
        return new EncryptedResponse(employeeList);
    }
}
