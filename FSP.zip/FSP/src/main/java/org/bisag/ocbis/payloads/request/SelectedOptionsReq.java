package org.bisag.ocbis.payloads.request;

public record SelectedOptionsReq(String selectedOption, String selectedDropdown) {

}
