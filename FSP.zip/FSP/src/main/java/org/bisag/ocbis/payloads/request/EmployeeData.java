
package org.bisag.ocbis.payloads.request;

import java.util.List;
import java.util.Map;

public record EmployeeData(List<String> employee_id) {
};