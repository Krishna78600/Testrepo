package org.bisag.ocbis.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "fsp_pu_field_activity")
public class FieldActivity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String fieldActivityMonth;
    private String fieldDuration;
    private String fieldTarget;
    private String fieldsActivity;

    @ManyToOne
    @JoinColumn(name = "fsp_pu_id")
    private ParticipatingUnits participatingUnits;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFieldActivityMonth() {
        return fieldActivityMonth;
    }

    public void setFieldActivityMonth(String fieldActivityMonth) {
        this.fieldActivityMonth = fieldActivityMonth;
    }

    public String getFieldDuration() {
        return fieldDuration;
    }

    public void setFieldDuration(String fieldDuration) {
        this.fieldDuration = fieldDuration;
    }

    public String getFieldTarget() {
        return fieldTarget;
    }

    public void setFieldTarget(String fieldTarget) {
        this.fieldTarget = fieldTarget;
    }

    public String getFieldsActivity() {
        return fieldsActivity;
    }

    public void setFieldsActivity(String fieldsActivity) {
        this.fieldsActivity = fieldsActivity;
    }

    public ParticipatingUnits getParticipatingUnits() {
        return participatingUnits;
    }

    public void setParticipatingUnits(ParticipatingUnits participatingUnits) {
        this.participatingUnits = participatingUnits;
    }

}
