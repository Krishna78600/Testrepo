package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.FspApprove;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import jakarta.transaction.Transactional;

import java.util.Map;
import java.util.List;

import java.time.ZonedDateTime;

public interface FspApproveRepo extends JpaRepository<FspApprove, Long> {

    @Query(nativeQuery = true, value = """
            SELECT * FROM fsp_approve_levels_details WHERE fsp_form_id = ?1
            """)
    FspApprove findByFormId(long id);

    @Query(nativeQuery = true, value = """
                    SELECT first_approving_authority_name,parent_mission_code,sub_mission_code,proposal_id,create_fsp_user_id FROM fsp_approve_levels_details WHERE fsp_form_id = ?1
            """)
    List<Map<String, Object>> getFspApproveFactors(Long id);

    @Modifying
    @Query(nativeQuery = true, value = """
            UPDATE fsp_approve_levels_details SET forwarded_by_fsp_creater = ?1,forwarded_to_suhead = ?2, fsp_creater_created_date = ?3,
            auto_push_status='Approve'
            WHERE fsp_form_id = ?4
            """)
    void forwardToSUhead(Long forwardedByFspCreaterId, Long forwardedToSuHeadId, ZonedDateTime createdDate,
            Long fspFormId, String stateId, String remakrs, String status);

    @Modifying
    @Query(nativeQuery = true, value = """
            UPDATE fsp_approve_levels_details SET forwarded_by_suhead = ?1,forwarded_to_rmh_of_pm = ?2, su_head_created_date = ?3,su_head_remarks = ?5,su_head_status = ?6 WHERE fsp_form_id = ?4
            """)
    void forwardToRmhOfPmBySuHead(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
            ZonedDateTime createdDate,
            Long fspFormId, String remakrs, String status, String stateId);

    @Modifying
    @Query(nativeQuery = true, value = """
            UPDATE fsp_approve_levels_details SET forwarded_by_rmh_of_pm = ?1,forwarded_to_hod = ?2, rmh_of_pm_created_date = ?3,rmh_of_pm_remarks = ?5,rmh_of_pm_status = ?6 WHERE fsp_form_id = ?4
            """)
    void forwardToHodByRmhOfPm(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
            ZonedDateTime createdDate,
            Long fspFormId, String remakrs, String status, String stateId);

    @Modifying
    @Query(nativeQuery = true, value = """
            UPDATE fsp_approve_levels_details SET forwarded_by_hod = ?1,forwarded_to_ddg_of_sm = ?2, hod_created_date = ?3,hod_remarks = ?5,hod_status = ?6 WHERE fsp_form_id = ?4
            """)
    void forwardToDdgofSmByHod(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
            ZonedDateTime createdDate,
            Long fspFormId, String remakrs, String status, String stateId);

    @Modifying
    @Query(nativeQuery = true, value = """
            UPDATE fsp_approve_levels_details SET forwarded_by_ddg_of_sm = ?1,forwarded_to_adg_of_pss = ?2, ddg_of_sm_created_date = ?3,ddg_of_sm_remarks = ?5,ddg_of_sm_status = ?6 WHERE fsp_form_id = ?4
            """)
    void forwardToAdgOfPssByDdgofSm(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
            ZonedDateTime createdDate,
            Long fspFormId, String remakrs, String status, String stateId);

    @Modifying
    @Query(nativeQuery = true, value = """
            UPDATE fsp_approve_levels_details SET forwarded_by_suhead = ?1,forwarded_to_hod = ?2, su_head_created_date = ?3,su_head_remarks = ?5,su_head_status = ?6 WHERE fsp_form_id = ?4
            """)
    void forwardToHodBySu(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
            ZonedDateTime createdDate,
            Long fspFormId, String remakrs, String status, String stateId);

    @Modifying
    @Query(nativeQuery = true, value = """
            UPDATE fsp_approve_levels_details SET forwarded_by_adg_of_pss = ?1, adg_of_pss_created_date = ?2,adg_of_pss_remarks = ?4,adg_of_pss_status = ?5 WHERE fsp_form_id = ?3
            """)
    void forwardedByAdgOfPss(Long forwardeByOfficerUserId,
            ZonedDateTime createdDate,
            Long fspFormId, String remakrs, String status, String stateId);

    @Modifying
    @Query(nativeQuery = true, value = """
            UPDATE fsp_approve_levels_details SET forwarded_by_fsp_creater = ?1,forwarded_to_rhod = ?2, fsp_creater_created_date = ?3,
            auto_push_status='Approve'
            WHERE fsp_form_id = ?4
            """)
    void forwardedToRhod(Long forwardedByFspCreaterId, Long forwardedToRhodId, ZonedDateTime createdDate,
            Long fspFormId, String stateId, String remakrs, String status);

    @Modifying
    @Query(nativeQuery = true, value = """
            UPDATE fsp_approve_levels_details SET forwarded_by_rhod = ?1,forwarded_to_training_institute_hqdh = ?2, rhod_created_date = ?3,rhod_remarks = ?5,rhod_status = ?6 WHERE fsp_form_id = ?4
            """)
    void forwardToHqdhByRhod(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
            ZonedDateTime createdDate,
            Long fspFormId, String remakrs, String status, String stateId);

    @Modifying
    @Query(nativeQuery = true, value = """
            UPDATE fsp_approve_levels_details SET forwarded_by_training_institute_hqdh = ?1,forwarded_to_training_institute_hod = ?2, training_institute_hqdh_created_date = ?3,training_institute_hqdh_remarks = ?5,training_institute_hqdh_status = ?6 WHERE fsp_form_id = ?4
            """)
    void forwardToTrainingInstitueHodByHqdh(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
            ZonedDateTime createdDate,
            Long fspFormId, String remakrs, String status, String stateId);

    @Modifying
    @Query(nativeQuery = true, value = """
            UPDATE fsp_approve_levels_details SET forwarded_by_training_institute_hod = ?1,forwarded_to_adg_of_pss = ?2, training_institute_hod_created_date = ?3,training_institute_hod_remarks = ?5,training_institute_hod_status = ?6 WHERE fsp_form_id = ?4
            """)
    void forwardToAdgOfPssByTIHod(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
            ZonedDateTime createdDate,
            Long fspFormId, String remakrs, String status, String stateId);

    @Modifying
    @Query(nativeQuery = true, value = """
            UPDATE fsp_approve_levels_details SET reject_forwarded_by_id = ?1, forwarded_to_fsp_creater_id = ?2,reject_fsp_status = ?3,
            reject_fsp_remarks  = ?4,reject_fsp_created_date = ?6
            WHERE fsp_form_id = ?5
                            """)
    void rejectFsp(Long forwardedById, Long forwardedToId, String status, String remarks,
            Long fspFormId, ZonedDateTime createdDate);

    @Modifying
    @Query(nativeQuery = true, value = """
            UPDATE fsp_approve_levels_details SET return_forwarded_by_id =
            ?1, forwarded_to_fsp_creater_id = ?2,return_fsp_status = ?3,
            return_fsp_remarks = ?4,return_fsp_created_date = ?6,
            auto_push_status = null,forwarded_by_suhead = null, forwarded_to_suhead =
            null, su_head_remarks = null, su_head_status = null, su_head_created_date =
            null,
            forwarded_by_rmh_of_pm = null, forwarded_to_rmh_of_pm = null,
            rmh_of_pm_remarks = null, rmh_of_pm_status = null, rmh_of_pm_created_date =
            null,
            forwarded_by_nmh_of_pm = null, forwarded_to_nmh_of_pm = null,
            nmh_of_pm_remarks = null, nmh_of_pm_status = null, nmh_of_pm_created_date =
            null,
            forwarded_by_hod = null, forwarded_to_hod = null, hod_remarks = null,
            hod_status = null, hod_created_date = null,
            forwarded_by_ddg_of_sm = null, forwarded_to_ddg_of_sm = null,
            ddg_of_sm_remarks = null, ddg_of_sm_status = null, ddg_of_sm_created_date =
            null,
            forwarded_by_ddg_of_stss_or_adss = null,forwarded_to_ddg_of_stss_or_adss =
            null, ddg_of_stss_or_adss_remarks = null, ddg_of_stss_or_adss_status = null,
            ddg_of_stss_or_adss_created_date = null,
            forwarded_by_adg_of_pss = null, forwarded_to_adg_of_pss = null,
            adg_of_pss_remarks = null, adg_of_pss_status = null, adg_of_pss_created_date
            = null,
            forwarded_by_adg_of_stss_or_adss = null, adg_or_stss_of_adss_remarks = null,
            adg_or_stss_of_adss_status = null, adg_or_stss_of_adssd_created_date =
            null,forwarded_to_adg_of_stss_or_adss = null
            WHERE fsp_form_id = ?5
            """)
    void returnFsp(Long forwardedById, Long forwardedToId, String status,
            String remarks,
            Long fspFormId, ZonedDateTime createdDate);

    @Modifying
    @Transactional
    @Query(nativeQuery = true, value = """
                                    WITH fsp_data AS (
                SELECT
                    pu_region,
                    pu_state_unit,
                    fsp_id
                FROM
                    save_created_fsp
                WHERE
                    fsp_id IS NOT NULL
            ),
            user_data AS (
                SELECT
                    ou.id AS user_id,
                    fd.pu_region,
                    fd.pu_state_unit
                FROM
                    fsp_data fd
                JOIN
                    public.ocbis_users ou
                ON
                    ou.regional_id = fd.pu_region
                    AND ou.state_id = fd.pu_state_unit
                WHERE
                    ou.designation_id = '1'
            )
            UPDATE
                fsp_peer_review fpr
            SET
                forwarded_to_director_of_pu_id = ud.user_id
            FROM
                fsp_data fd
            JOIN
                user_data ud ON fd.pu_region = ud.pu_region
                            AND fd.pu_state_unit = ud.pu_state_unit
            WHERE
                fpr.fsp_id = fd.fsp_id
                                    """)
    void updateFspDirector();

    @Query(nativeQuery = true, value = """
            SELECT fpr.*,fald.*,scf.*,ou.*
             FROM
                 save_created_fsp scf
              JOIN fsp_approve_levels_details fald ON fald.fsp_form_id = scf.id
              JOIN ocbis_users ou on ou.id = scf.user_id
              left join fsp_peer_review fpr on fpr.proposal_id = fald.proposal_id
              WHERE scf.steps_completed = 9 and fpr.pss_peer_review_status='Approved' and  fpr.forwarded_to_director_of_pu_id=?2 AND  ou.state_id = ?1 and scf.fsp_id is not null order by scf.create_fsp_date desc
                       """)
    List<Map<String, Object>> getApprovedFspAfterPeerReviewExport(String stateId, Long id);

    @Query(nativeQuery = true, value = """
             SELECT scf.id AS scf_id,fald.su_head_remarks,fald.rmh_of_pm_remarks,fald.hod_remarks,fald.ddg_of_sm_remarks,fpr.*,
                 fald.adg_of_pss_remarks,fpr.rmh_remarks,fpr.nmh_remarks,fpr.nmh_status,fpr.rmh_status, scf.*, fald.*,
                 fpr.applied_for_peer_review_to_nmh,fpr.applied_for_peer_review_to_rmh,fpr.status AS peer_status, fpr.remarks AS peer_remarks,fpr.pss_status,fpr.pss_external_peer_status,fpr.remarks AS pss_internal_review_start_remarks,
                 fpr.id AS peer_id
            FROM fsp_peer_review fpr
            left JOIN fsp_approve_levels_details fald ON fpr.proposal_id = fald.proposal_id
            join ocbis_users ou on ou.id = fpr.applied_for_peer_review_by_pss
            left join save_created_fsp scf on scf.proposal_id = fald.proposal_id
            WHERE ou.state_id = ?1 order by scf.create_fsp_date desc

              """)
    List<Map<String, Object>> getFspForPeerReviewRmhNmhExport(String stateId);
}
