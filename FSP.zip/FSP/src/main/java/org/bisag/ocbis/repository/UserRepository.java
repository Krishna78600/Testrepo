package org.bisag.ocbis.repository;

import java.util.List;
import java.util.Map;

import org.bisag.ocbis.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

        User findFirstByEmail(String username);

        @Query(nativeQuery = true, value = """
                                SELECT * FROM ocbis_users WHERE designation_id = '11' AND state_id = ?1 limit 1
                        """)
        User findSuHeadStateWise(String stateId);

        @Query(nativeQuery = true, value = """
                                SELECT * FROM ocbis_users WHERE designation_id = '13' AND state_id = ?1 limit 1
                        """)
        User findRhodStateWise(String stateId);

        @Query(nativeQuery = true, value = """
                                SELECT * FROM ocbis_users WHERE regional_id = ?1 AND designation_id = ?2
                        """)
        List<User> findUserByRegionalandDesignation(String regionalId, String designationId);

        @Query(nativeQuery = true, value = """
                        select ou.id,ou.username,od.designation from ocbis_users ou
                        left join ocbis_designation od on ou.designation_id::bigint = od.id
                        where designation_id = '5' And ou.state_id =?1
                                                """)
        List<Map<String, Object>> getRegionalMissionHeadList(String stateId);

        @Query(nativeQuery = true, value = """
                        select ou.id,ou.username,od.designation from ocbis_users ou
                        left join ocbis_designation od on ou.designation_id::bigint = od.id
                        where designation_id = '6' And ou.state_id =?1
                        """)
        List<Map<String, Object>> getNationalMissionHeadList(String stateId);

        @Query(nativeQuery = true, value = """
                        select ou.id,ou.username,od.designation from ocbis_users ou
                        left join ocbis_designation od on ou.designation_id::bigint = od.id
                        where designation_id = '7' And ou.state_id =?1
                        """)
        List<Map<String, Object>> getAdditionalDirectorGeneralList(String stateId);

        @Query(nativeQuery = true, value = """
                        select ou.id,ou.username,od.designation from ocbis_users ou
                        left join ocbis_designation od on ou.designation_id::bigint = od.id
                        where designation_id = '8' And ou.state_id =?1
                        """)
        List<Map<String, Object>> getDeputyDirectorGeneralList(String stateId);

        @Query(nativeQuery = true, value = """
                        select ou.id,ou.username,od.designation from ocbis_users ou
                        left join ocbis_designation od on ou.designation_id::bigint = od.id
                        where designation_id = '9' And ou.state_id =?1
                        """)
        List<Map<String, Object>> getHeadOfDepartmentList(String stateId);

        @Query(nativeQuery = true, value = """
                        select ou.id,ou.username,od.designation from ocbis_users ou
                        left join ocbis_designation od on ou.designation_id::bigint = od.id
                        where designation_id = '19' And ou.state_id =?1
                        """)
        List<Map<String, Object>> getTrainingInstitueHqdh(String stateId);

        @Query(nativeQuery = true, value = """
                        select ou.id,ou.username,od.designation from ocbis_users ou
                        left join ocbis_designation od on ou.designation_id::bigint = od.id
                        where designation_id = '20' And ou.state_id =?1
                        """)
        List<Map<String, Object>> getTrainingInstitueHod(String stateId);

        @Query(nativeQuery = true, value = """
                        select * from ocbis_users where designation_id = '6'
                        """)
        List<Map<String, Object>> getRegionalMissionHeads();

        @Query(nativeQuery = true, value = """
                        SELECT *
                        FROM employee_master
                        WHERE (?3 IS NULL OR employee_name || employee_id ILIKE COALESCE(?3, ''))
                        ORDER BY id
                        LIMIT ?1 OFFSET ?2
                         """)
        List<Map<String, Object>> getEmployeeListByPagination(Long Limit, Long Offset, String search);

        @Query(nativeQuery = true, value = """
                        SELECT csi_site_name, csi_site_id
                        FROM siteid
                        WHERE (?3 IS NULL OR csi_site_name ILIKE COALESCE(?3, ''))
                        ORDER BY csi_site_id
                        LIMIT ?1 OFFSET ?2
                         """)
        List<Map<String, Object>> getSiteNameListByPagination(Long Limit, Long Offset, String search);

        @Query(nativeQuery = true, value = """
                        select ou.id,ou.username,od.designation from ocbis_users
                        """)
        List<Map<String, Object>> getFspCount();

        @Query(nativeQuery = true, value = """
                        select ou.id,ou.username from ocbis_users ou
                        """)
        List<Map<String, Object>> getUserList();

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_mission_master ORDER BY parent_name ASC
                            """)
        List<Map<String, Object>> getParentMission();

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_mission_master ORDER BY parent_name ASC
                            """)
        List<Map<String, Object>> getFspApproveFactors(Long fspFormId);

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_submission_master  WHERE parent_code=?1 ORDER BY mission_name ASC
                            """)
        List<Map<String, Object>> getSubMissionByMissionId(String missionName);

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_theme_master ORDER BY theme_name ASC
                            """)
        List<Map<String, Object>> getThemeByMissionSubMission();

        @Query(nativeQuery = true, value = """
                        SELECT lab_id, lab_name FROM fsp_lab_name_master  ORDER BY lab_name ASC
                            """)
        List<Map<String, Object>> getLabNames();

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_code_master ORDER BY commercial_code_name ASC
                            """)
        List<Map<String, Object>> getCommercialCode();

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_region_master ORDER BY region_name ASC
                            """)
        List<Map<String, Object>> getAllRegion();

        @Query(nativeQuery = true, value = """
                        SELECT distinct field_season_year FROM save_created_fsp where  field_season_year is not null ORDER BY field_season_year;
                            """)
        List<Map<String, Object>> getFieldSeasonYear();

        @Query(nativeQuery = true, value = """
                        SELECT * FROM public.fsp_state_master where region_code=?1 IS NULL OR region_code=?1 ORDER BY  state_name ASC
                                                    """)
        List<Map<String, Object>> getStateUnit(String region_code);

        @Query(nativeQuery = true, value = """
                        SELECT * FROM state_unit_master ORDER BY id
                            """)
        List<Map<String, Object>> getStateByRegion();

        @Query(nativeQuery = true, value = """
                            SELECT COALESCE(MAX(serial_no), 0) FROM save_created_fsp
                        """)
        Long findMaxSerialNo();

        @Query(nativeQuery = true, value = """
                        SELECT commodity_id, commodity_name FROM fsp_commodity_master ORDER BY commodity_name
                        """)
        List<Map<String, Object>> getCommodityName();

        @Query(nativeQuery = true, value = """
                           INSERT INTO public.fsp_committee (committee_name) VALUES (?1) returning id
                        """)

        List<Map<String, Object>> addCommitiee(String committeeName);

        @Query(nativeQuery = true, value = """
                        SELECT distinct id, employee_name FROM employee_master ORDER BY employee_name
                        """)
        List<Map<String, Object>> getEmployeeList();

        @Query(nativeQuery = true, value = """
                        select * from fsp_cgpb_meetingtype ORDER BY description
                         """)
        List<Map<String, Object>> getCommitteeList();

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_item_type_master ORDER BY item_type
                        """)
        List<Map<String, Object>> getTypes();

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_area_type_master ORDER BY area_name
                        """)
        List<Map<String, Object>> getareaTypes();

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_spin_off_master ORDER BY spin_name
                        """)
        List<Map<String, Object>> getSpinCategory();

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_division_master ORDER BY division_name ASC
                        """)
        List<Map<String, Object>> getDivision();

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_personnel_stream_master
                        """)
        List<Map<String, Object>> getPersonneStream();

        @Query(nativeQuery = true, value = """
                        SELECT * FROM public.fsp_commodity_master where commodity_id=?1
                        """)
        List<Map<String, Object>> getCommodityDetailsById(Long id);

        @Query(nativeQuery = true, value = """
                        select distinct activity_type from fsp_activity_type_master order by activity_type ASC
                             """)
        List<Map<String, Object>> getActivityType();

        @Query(nativeQuery = true, value = """
                        select  activity_name from fsp_activity_type_master where activity_type=?1 ORDER BY activity_name ASC

                            """)
        List<Map<String, Object>> getActivityNameByActivityType(String activityType);

        @Query(nativeQuery = true, value = """
                        SELECT DISTINCT consumable_item_name FROM fsp_consumable_item_master ORDER BY consumable_item_name  ASC            """)
        List<Map<String, Object>> getConsumableItems();

        @Query(nativeQuery = true, value = """
                        SELECT DISTINCT non_consumable_item_name FROM fsp_non_consumable_item_master ORDER BY non_consumable_item_name ASC
                                            """)
        List<Map<String, Object>> getNonConsumableItems();

        @Query(nativeQuery = true, value = """
                        select * from fsp_terrain_condition_master order by name ASC
                         """)
        List<Map<String, Object>> getTerrainConditions();

        @Query(nativeQuery = true, value = """
                        select * from fsp_drilling_type_master order by drilling_type ASC
                         """)
        List<Map<String, Object>> getTypeOfDrilling();

        @Query(nativeQuery = true, value = """
                        select * from fsp_rock_characteristics_master ORDER BY rock_char_type ASC
                         """)
        List<Map<String, Object>> getRockCharacteristics();

        @Query(nativeQuery = true, value = """
                        select * from fsp_rock_type_master ORDER BY rock_type ASC
                         """)
        List<Map<String, Object>> getRockType();

        @Query(nativeQuery = true, value = """
                        select * from fsp_vehicle_type_master ORDER BY vehicle_type_name ASC
                         """)
        List<Map<String, Object>> getVehicleType();

        @Query(nativeQuery = true, value = """
                        select * from fsp_pattern_master ORDER BY  pattern_type ASC
                         """)
        List<Map<String, Object>> getPattern();

        @Query(nativeQuery = true, value = """
                        select DISTINCT foe.expense_head from fsp_operational_expense foe
                        """)
        List<Map<String, Object>> getOperationalExpense();

        @Query(nativeQuery = true, value = """
                        SELECT distinct id, designation FROM designation_master ORDER BY designation
                        """)
        List<Map<String, Object>> getDesignationList();

        @Query(nativeQuery = true, value = """
                        SELECT * FROM public.employee_master where designation=?1 IS NULL OR designation=?1 ORDER BY  designation ASC
                                                    """)
        List<Map<String, Object>> getEmpList(String designationCode);

        // dulera
        @Query(nativeQuery = true, value = """
                        SELECT DISTINCT(field_season_year) AS options FROM save_created_fsp WHERE fsp_id IS NOT NULL
                        """)
        List<Map<String, Object>> getFieldSeasonYears();

        // dulera
        @Query(nativeQuery = true, value = """
                        SELECT DISTINCT(fsp_id) AS options FROM save_created_fsp WHERE fsp_id IS NOT NULL
                        """)
        List<Map<String, Object>> getProposals();

        // dulera
        @Query(nativeQuery = true, value = """
                        SELECT scf.*,
                            MAX(fcom.commercial_code_name) as commercial_code_name,
                            MAX(fsm.state_name) as state_name,
                            MAX(fsm.state_code) as state_code,
                            MAX(fitm.item_type) as item_type,
                            MAX(fatm.area_name) as area_name,
                            MAX(fdm.division_name) as division_name,
                            MAX(fd.topo_sheet_number) as "topoSheetNumber",
                            string_agg(DISTINCT fcm.commodity_name, ', ') AS commodity_names,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fc.id,
                                'fsp_form_id', fc.fsp_form_id,
                                'fsp_commodity_name', fc.fsp_commodity_name,
                                'commodity_name', fcm.commodity_name,
                                'fsp_sub_commodity_name', fc.fsp_sub_commodity_name,
                                'fsp_mineral_type', fc.fsp_mineral_type
                            )) FILTER (WHERE fc.id IS NOT NULL), '[]'\\:\\:json) AS commodities,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fqtat.id,
                                'fsp_form_id', fqtat.fsp_form_id,
                                'analysis_type', fqtat.analysis_type
                            )) FILTER (WHERE fqtat.id IS NOT NULL), '[]'\\:\\:json) AS analysis_types,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fqtt.id,
                                'fsp_form_id', fqtt.fsp_form_id,
                                'task', fqtt.task
                            )) FILTER (WHERE fqtt.id IS NOT NULL), '[]'\\:\\:json) AS tasks,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fqts.id,
                                'fsp_form_id', fqts.fsp_form_id,
                                'lab_name', fqts.lab_name,
                                'sub_task', fqts.sub_task,
                                'target', fqts.target,
                                'timeline_from', fqts.timeline_from,
                                'timeline_to', fqts.timeline_to,
                                'workload', fqts.workload
                            )) FILTER (WHERE fqts.id IS NOT NULL), '[]'\\:\\:json) AS subtasks,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fsqs.id,
                                'fsp_form_id', fsqs.fsp_form_id,
                                'sample_quant_and_service_activity_name', fsqs.sample_quant_and_service_activity_name,
                                'sample_quant_and_service_activity_type', fsqs.sample_quant_and_service_activity_type,
                                'sample_quant_and_service_elements', fsqs.sample_quant_and_service_elements,
                                'sample_quant_and_service_sample_target', fsqs.sample_quant_and_service_sample_target,
                                'sample_quant_and_service_total_workload', fsqs.sample_quant_and_service_total_workload,
                                'sample_quant_and_service_work_completed', fsqs.sample_quant_and_service_work_completed
                            )) FILTER (WHERE fsqs.id IS NOT NULL), '[]'\\:\\:json) AS sample_quant,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', flz.id,
                                'fsp_form_id', flz.fsp_form_id,
                                'depth', flz.depth,
                                'other_rock_characteristics', flz.other_rock_characteristics,
                                'other_rock_types', flz.other_rock_types,
                                'rock_characteristics', flz.rock_characteristics,
                                'rock_types', flz.rock_types
                            )) FILTER (WHERE flz.id IS NOT NULL), '[]'\\:\\:json) AS lithology_zones,
                            COALESCE(json_agg(DISTINCT fvd.*) FILTER (WHERE fvd.id IS NOT NULL), '[]'\\:\\:json) AS vehicle_details,
                            COALESCE(json_agg(DISTINCT foe.*) FILTER (WHERE foe.id IS NOT NULL), '[]'\\:\\:json) AS operational_expenses,
                            COALESCE(json_agg(DISTINCT fci.*) FILTER (WHERE fci.id IS NOT NULL), '[]'\\:\\:json) AS consumable_items,
                            COALESCE(json_agg(DISTINCT fnci.*) FILTER (WHERE fnci.id IS NOT NULL), '[]'\\:\\:json) AS non_consumable_items
                        FROM save_created_fsp scf
                        LEFT JOIN fsp_commodity fc ON fc.fsp_form_id = scf.id
                        LEFT JOIN fsp_commodity_master fcm ON fcm.commodity_id = fc.fsp_commodity_name\\:\\:int
                        LEFT JOIN fsp_qualitative_targets_analysis_type fqtat ON fqtat.fsp_form_id = scf.id
                        LEFT JOIN fsp_qualitative_targets_task fqtt ON fqtt.fsp_form_id = scf.id
                        LEFT JOIN fsp_qualitative_targets_subtask fqts ON fqts.fsp_form_id = scf.id
                        LEFT JOIN fsp_sample_quant_service fsqs ON fsqs.fsp_form_id = scf.id
                        LEFT JOIN fsp_lithology_zone flz ON flz.fsp_form_id = scf.id
                        LEFT JOIN fsp_vehicle_details fvd ON fvd.fsp_form_id = scf.id
                        LEFT JOIN fsp_operational_expense foe ON foe.fsp_form_id = scf.id
                        LEFT JOIN fsp_consumable_item fci ON fci.fsp_form_id = scf.id
                        LEFT JOIN fsp_non_consumable_item fnci ON fnci.fsp_form_id = scf.id
                        LEFT JOIN fsp_state_master fsm ON CAST(scf.state_unit_name AS BIGINT) = fsm.id
                        LEFT JOIN fsp_item_type_master fitm ON CAST(scf.fsp_item_type AS BIGINT) = fitm.id
                        LEFT JOIN fsp_area_type_master fatm ON CAST(scf.fsp_area_type AS BIGINT) = fatm.id
                        LEFT JOIN fsp_division_master fdm ON CAST(scf.pu_division AS BIGINT) = fdm.division_code
                        LEFT JOIN fsp_code_master fcom ON CAST(scf.commercial_code AS BIGINT) = fcom.code_no
                        LEFT JOIN fsp_data fd ON fd.fsp_form_id = scf.id
                        WHERE (
                            (?1\\:\\:TEXT IS NULL OR scf.field_season_year = ?1\\:\\:TEXT) AND
                            (?2\\:\\:TEXT IS NULL OR scf.fsp_id = ?2) AND
                            scf.fsp_id IS NOT NULL
                        )
                        GROUP BY scf.id
                        """)
        List<Map<String, Object>> getData(String year, String fspId);

        // mayursolanki
        @Query(nativeQuery = true, value = """
                        SELECT emp.employee_name,dm.designation FROM employee_master emp join designation_master dm on emp.designation  = dm.id :\\:\\text where emp.employee_id = ?1
                            """)
        List<Map<String, Object>> getEmpById(Integer empid);

        @Query(nativeQuery = true, value = """
                        SELECT csi_site_id FROM siteid where csi_site_name=?1           """)
        List<Map<String, Object>> getSiteName(String sitename);

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_role_master ORDER BY role ASC
                            """)
        List<Map<String, Object>> getRoleList();

        @Query(nativeQuery = true, value = """
                        SELECT emp.employee_name,dm.designation FROM employee_master emp join designation_master dm on emp.designation  = dm.id :\\:\\text where emp.employee_id = :ids
                            """)
        List<Map<String, Object>> getEmpByIdsList(@Param("ids") Integer list);

        @Query(nativeQuery = true, value = """
                            SELECT
                                emp.*, fpu.*
                            FROM
                                public.employee_master emp
                            LEFT JOIN
                                fsp_participating_units fpu ON fpu.employee_id = emp.employee_id\\:\\:text
                            WHERE
                                fpu.fsp_id = ?1
                        """)
        List<Map<String, Object>> getEmployeesForAllotment(String fspId);

}
