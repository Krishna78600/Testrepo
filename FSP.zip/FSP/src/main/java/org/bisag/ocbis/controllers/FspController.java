package org.bisag.ocbis.controllers;

import org.apache.commons.lang3.StringUtils;
import org.bisag.ocbis.models.FspApprove;
import org.bisag.ocbis.models.User;
import org.bisag.ocbis.payloads.request.AddCommittee;
import org.bisag.ocbis.payloads.request.CommodityDetails;
import org.bisag.ocbis.payloads.request.CreateFspRequest;
import org.bisag.ocbis.payloads.request.EmployeeData;
import org.bisag.ocbis.payloads.request.EncryptedRequest;
import org.bisag.ocbis.payloads.request.GetId;
import org.bisag.ocbis.payloads.request.IdWithPaginate;
import org.bisag.ocbis.payloads.request.LongId;
import org.bisag.ocbis.payloads.request.Report;
import org.bisag.ocbis.payloads.request.SelectedOptionsReq;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.ConsumableItemRepo;
import org.bisag.ocbis.repository.FspRepo;
import org.bisag.ocbis.repository.NonConsumableItemRepo;
import org.bisag.ocbis.repository.OperationalExpenseRepo;
import org.bisag.ocbis.repository.UserRepository;
import org.bisag.ocbis.repository.VehicleRepo;
import org.bisag.ocbis.services.NavigationService;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@RestController
@CrossOrigin("*")
@RequestMapping("/fsp")
public class FspController {
  @Autowired
  FspRepo fsprepo;

  @Autowired
  VehicleRepo vehicleRepo;

  @Autowired
  OperationalExpenseRepo operationalExpenseRepo;

  @Autowired
  ConsumableItemRepo consumableItemRepo;

  @Autowired
  NonConsumableItemRepo nonConsumableItemRepo;

  @Autowired
  UserRepository userRepo;

  @Autowired
  private JdbcTemplate jdbcTemplate;
  @Autowired
  NavigationService navService;

  @PostMapping("/get-all-mission")
  public <json> EncryptedResponse getParentMission(
      HttpServletResponse response) throws Exception {
    // var body = Json.deserialize(CreateFspRequest.class, req.data());
    // String username = body.username();
    List<Map<String, Object>> result = userRepo.getParentMission();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-sub-mission-by-mission")
  public <json> EncryptedResponse getSubMission(
      @Valid @RequestBody EncryptedRequest req,
      HttpServletResponse response) throws Exception {
    var body = req.bodyAs(CreateFspRequest.class);
    String missionName = body.missionName();

    List<Map<String, Object>> result = userRepo.getSubMissionByMissionId(missionName);
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-theme-by-mission-sub-mission")
  public <json> EncryptedResponse getThemeByMissionSubMission(

      HttpServletResponse response) throws Exception {
    // var body = Json.deserialize(CreateFspRequest.class, req.data());
    // Long regionId = body.regionId();
    List<Map<String, Object>> result = userRepo.getThemeByMissionSubMission();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-lab-names")
  public <json> EncryptedResponse getLabNames(

      HttpServletResponse response) throws Exception {
    // var body = Json.deserialize(CreateFspRequest.class, req.data());
    // Long regionId = body.regionId();
    List<Map<String, Object>> result = userRepo.getLabNames();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-commercial-code")
  public <json> EncryptedResponse getCommercialCode(
      HttpServletResponse req) throws Exception {
    // var body = Json.deserialize(CreateFspRequest.class, req.data());
    // Long regionId = body.regionId();
    List<Map<String, Object>> result = userRepo.getCommercialCode();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-all-region")
  public <json> EncryptedResponse getAllRegion(

      HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getAllRegion();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-commodity")
  public <json> EncryptedResponse getCommodityName(
      HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getCommodityName();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-state-unit")
  public <json> EncryptedResponse getStateUnit(@Valid @RequestBody EncryptedRequest req,
      HttpServletResponse response) throws Exception {
    var body = req.bodyAs(GetId.class);
    String regionCode;
    if (body.code() == "") {
      regionCode = null;
    } else {
      regionCode = body.code();
    }
    List<Map<String, Object>> result = userRepo.getStateUnit(regionCode);
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-field-season-year")
  public <json> EncryptedResponse getFieldSeasonYear(

      HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getFieldSeasonYear();
    return new EncryptedResponse(result);
  }

  // @PostMapping("/get-state-by-region")
  // public <json> EncryptedResponse getStateByRegion(
  // @Valid @RequestBody EncryptedRequest req,
  // HttpServletResponse response) throws Exception {
  // // var body = Json.deserialize(CreateFspRequest.class, req.data());
  // // Long regionId = body.regionId();
  // List<Map<String, Object>> result = userRepo.getStateByRegion();
  // return new EncryptedResponse(result);
  // }

  @PostMapping("/generate-serial-no")
  public <json> EncryptedResponse generateSerialNoByUUID() throws Exception {

    Long lastSerialNo = userRepo.findMaxSerialNo();
    long newSerialNo = lastSerialNo + 1;
    String serialNo = String.format("%05d", newSerialNo);
    return new EncryptedResponse(serialNo);
  }

  @PostMapping("/add-committiee")
  public <json> EncryptedResponse addCommitiee(@Valid @RequestBody EncryptedRequest req) throws Exception {
    // fspNewCommittee
    var body = req.bodyAs(AddCommittee.class);
    String committeeName = body.fspNewCommittee();
    userRepo.addCommitiee(committeeName);
    return new EncryptedResponse("Added Successfully");
  }

  @PostMapping("/get-employee-list")
  public <json> EncryptedResponse getEmployee(
      HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getEmployeeList();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-committee-list")
  public <json> EncryptedResponse getCommitteeList() throws Exception {
    List<Map<String, Object>> result = userRepo.getCommitteeList();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-item-type")
  public <json> EncryptedResponse getItemType(
      HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getTypes();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-area-type")
  public <json> EncryptedResponse getAreaType(
      HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getareaTypes();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-spin-off-category")
  public <json> EncryptedResponse getSpinCategory(HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getSpinCategory();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-all-division")
  public <json> EncryptedResponse getDivision(HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getDivision();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-all-personnel-stream")
  public <json> EncryptedResponse getPersonneStream(HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getPersonneStream();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-commodity-details")
  public <json> EncryptedResponse getCommodityDetails(
      @Valid @RequestBody EncryptedRequest req,
      HttpServletResponse response) throws Exception {
    var body = req.bodyAs(CommodityDetails.class);
    Long id = body.id();
    List<Map<String, Object>> result = userRepo.getCommodityDetailsById(id);
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-terrain-conditions")
  public <json> EncryptedResponse getTerrainConditions(

      HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getTerrainConditions();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-type-of-drilling")
  public <json> EncryptedResponse getTypeOfDrilling(

      HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getTypeOfDrilling();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-rock-characteristics")
  public <json> EncryptedResponse getRockCharacteristics(

      HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getRockCharacteristics();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-rock-types")
  public <json> EncryptedResponse getRockType(

      HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getRockType();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-vehicle-type")
  public <json> EncryptedResponse getVehicleType(

      HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getVehicleType();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-all-activity-type")
  public <json> EncryptedResponse getActivityType(
      HttpServletResponse response) throws Exception {
    // var body = Json.deserialize(CreateFspRequest.class, req.data());
    // String username = body.username();
    List<Map<String, Object>> result = userRepo.getActivityType();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-activity-name-by-activity-type")
  public <json> EncryptedResponse getActivityName(
      @Valid @RequestBody EncryptedRequest req,
      HttpServletResponse response) throws Exception {
    var body = req.bodyAs(CreateFspRequest.class);
    String activityType = body.activityType();
    List<Map<String, Object>> result = userRepo.getActivityNameByActivityType(activityType);
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-all-consumable-items")
  public <json> EncryptedResponse getConsumableItems(
      HttpServletResponse response) throws Exception {
    // var body = Json.deserialize(CreateFspRequest.class, req.data());
    // String username = body.username();
    List<Map<String, Object>> result = userRepo.getConsumableItems();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-all-non-consumable-items")
  public <json> EncryptedResponse getNonConsumableItems(
      HttpServletResponse response) throws Exception {
    // var body = Json.deserialize(CreateFspRequest.class, req.data());
    // String username = body.username();
    List<Map<String, Object>> result = userRepo.getNonConsumableItems();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-pattern")
  public <json> EncryptedResponse getPattern(HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getPattern();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-employee-list-by-pagination")
  public EncryptedResponse getEmployeeListByPagination(@RequestBody EncryptedRequest req)
      throws Exception {
    var body = req.bodyAs(IdWithPaginate.class);
    var limit = body.paginate().limit();
    var offset = body.paginate().offset();
    var search = StringUtils.isBlank(body.paginate().search()) ? null
        : "%" + body.paginate().search() + "%";

    System.out.println("pagination" + limit + offset + search);
    System.out.println("pagination" + limit.getClass() + offset.getClass() +
        search);

    List<Map<String, Object>> employeeList = userRepo.getEmployeeListByPagination(limit, offset, search);
    return new EncryptedResponse(employeeList);
  }

  @PostMapping("/get-sitename-list-by-pagination")
  public EncryptedResponse getSiteNameListByPagination(@RequestBody EncryptedRequest req)
      throws Exception {
    var body = req.bodyAs(IdWithPaginate.class);
    var limit = body.paginate().limit();
    var offset = body.paginate().offset();
    var search = StringUtils.isBlank(body.paginate().search()) ? null
        : "%" + body.paginate().search() + "%";

    System.out.println("pagination" + limit + offset + search);
    System.out.println("pagination" + limit.getClass() + offset.getClass() +
        search);

    List<Map<String, Object>> employeeList = userRepo.getSiteNameListByPagination(limit, offset, search);
    return new EncryptedResponse(employeeList);
  }

  

  @PostMapping("/get-status-monitoring-fsp-details")
  public EncryptedResponse getMonitoringFsp(@AuthenticationPrincipal User user, @RequestBody EncryptedRequest req)
      throws Exception {

    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
    var search = StringUtils.isBlank(body.search()) ? null
        : "%" + body.search() + "%";
    String approvedFspStatus = null;
    String dropFspStatus = null;
    String missionVstatus = null;
    String rejectOrReturnstatus = null;

    if (body.custom() != null) {
      approvedFspStatus = (String) body.custom().get("approvedFspStatus");
      dropFspStatus = (String) body.custom().get("dropFspStatus");
      missionVstatus = (String) body.custom().get("missionVstatus");
      rejectOrReturnstatus = (String) body.custom().get("rejectOrReturnstatus");

      System.out.println("dropfspstatus" + dropFspStatus);
      System.out.println("approvedFspStatus" + approvedFspStatus);
      System.out.println("missionVstatus" + missionVstatus);
      System.out.println("rejectOrReturnstatus" + rejectOrReturnstatus);

    }

    Page<Map<String, Object>> result = fsprepo.getMonitoringFsp(user.getId(), approvedFspStatus, dropFspStatus,
        missionVstatus, rejectOrReturnstatus, search, pageable);
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-status-monitoring-fsp-details/export")
  public EncryptedResponse getMonitoringFspExport(@AuthenticationPrincipal User user, @RequestBody EncryptedRequest req)
      throws Exception {

    var body = req.bodyAs(Report.class);
    var search = StringUtils.isBlank(body.search()) ? null
        : "%" + body.search() + "%";
    String approvedFspStatus = null;
    String dropFspStatus = null;
    String missionVstatus = null;
    String rejectOrReturnstatus = null;

    if (body.custom() != null) {
      approvedFspStatus = (String) body.custom().get("approvedFspStatus");
      dropFspStatus = (String) body.custom().get("dropFspStatus");
      missionVstatus = (String) body.custom().get("missionVstatus");
      rejectOrReturnstatus = (String) body.custom().get("rejectOrReturnstatus");

      System.out.println("dropfspstatus" + dropFspStatus);
      System.out.println("approvedFspStatus" + approvedFspStatus);
      System.out.println("missionVstatus" + missionVstatus);
      System.out.println("rejectOrReturnstatus" + rejectOrReturnstatus);

    }

    List<Map<String, Object>> result = fsprepo.getMonitoringFspExport(user.getId(), approvedFspStatus, dropFspStatus,
        missionVstatus, rejectOrReturnstatus, search);

    return new EncryptedResponse(result);
  }

  @PostMapping("/tracking-fsp-details-return")
  public EncryptedResponse trackingFspForReturn(@AuthenticationPrincipal User user, @RequestBody EncryptedRequest req)
      throws Exception {

    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
    var search = StringUtils.isBlank(body.search()) ? null
        : "%" + body.search() + "%";
    String returnFspStatus = null;

    if (body.custom() != null) {
      returnFspStatus = (String) body.custom().get("returnFspStatus");
      System.out.println("returnFspStatus" + returnFspStatus);
    }

    System.out.println("returnFspStatus" + returnFspStatus);
    Page<Map<String, Object>> result = fsprepo.trackingFspForReturn(user.getId(), returnFspStatus, search, pageable);
    return new EncryptedResponse(result);
  }

  @PostMapping("/tracking-fsp-details-return/export")
  public EncryptedResponse trackingFspForReturnExport(@AuthenticationPrincipal User user,
      @RequestBody EncryptedRequest req)
      throws Exception {

    var body = req.bodyAs(Report.class);
    var search = StringUtils.isBlank(body.search()) ? null
        : "%" + body.search() + "%";
    String returnFspStatus = null;

    if (body.custom() != null) {
      returnFspStatus = (String) body.custom().get("returnFspStatus");
      System.out.println("returnFspStatus" + returnFspStatus);
    }

    System.out.println("returnFspStatus" + returnFspStatus);
    List<Map<String, Object>> result = fsprepo.trackingFspForReturnExport(user.getId(), returnFspStatus, search);
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-fsp-for-peer-review")
  public EncryptedResponse getFspForPeerReview(@AuthenticationPrincipal User user, @RequestBody EncryptedRequest req)
      throws Exception {

    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
    System.out.println("testtttt" + user.getId());
    Page<Map<String, Object>> result = fsprepo.getFspForPeerReview(user.getStateId(), pageable);
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-fsp-for-peer-review-rmh-nmh")
  public EncryptedResponse getFspForPeerReviewRmhNmh(@AuthenticationPrincipal User user,
      @RequestBody EncryptedRequest req)
      throws Exception {

    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
    System.out.println("testtttt" + user.getId());
    Page<Map<String, Object>> result = fsprepo.getFspForPeerReviewRmhNmh(user.getStateId(), pageable);
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-draft-fsp-details")
  public EncryptedResponse getDraftFsp(@AuthenticationPrincipal User user, @RequestBody EncryptedRequest req)
      throws Exception {

    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
    System.out.println("testtttt" + user.getId());
    Page<Map<String, Object>> result = fsprepo.getDraftFsp(user.getId(), pageable);
    return new EncryptedResponse(result);
  }

  // get all the user designations wise and state wise start

  @PostMapping("/get-state-heads")
  public EncryptedResponse getStateHeads() throws Exception {
    return new EncryptedResponse("list");
  }

  @PostMapping("/get-regional-mission-heads")
  public EncryptedResponse getRegionalMissionHeadList(@AuthenticationPrincipal User user) throws Exception {
    List<Map<String, Object>> result = userRepo.getRegionalMissionHeadList(user.getStateId());
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-national-mission-heads")
  public EncryptedResponse getNationalMissionHeadList(@AuthenticationPrincipal User user) throws Exception {
    List<Map<String, Object>> result = userRepo.getNationalMissionHeadList(user.getStateId());
    return new EncryptedResponse(result);
  }
  // @PostMapping("/get-national-mission-heads")
  // public EncryptedResponse getNationalMissionHeadList() throws Exception {
  // return new EncryptedResponse("list");
  // }

  @PostMapping("/get-heads-of-department")
  public EncryptedResponse getHeadsOfDepartment() throws Exception {
    return new EncryptedResponse("list");
  }

  @PostMapping("/get-deputy-directors-general-of-sub-mission")
  public EncryptedResponse getDeputyDirectorsGeneralOfSubMission() throws Exception {
    return new EncryptedResponse("list");
  }

  @PostMapping("/get-deputy-directors-general-of-stss-or-adss")
  public EncryptedResponse getDeputyDirectorsGeneralOfSTSSorADSS() throws Exception {
    return new EncryptedResponse("list");
  }

  @PostMapping("/get-assistant-directors-general-of-pss")
  public EncryptedResponse getAssistantDirectorsGeneralOfPSS() throws Exception {
    return new EncryptedResponse("list");
  }

  @PostMapping("/get-assistant-directors-general-of-stss-or-adss")
  public EncryptedResponse getAssistantDirectorsGeneralOfSTSSorADSS() throws Exception {
    return new EncryptedResponse("list");
  }

  @PostMapping("/get-fsp-counts")
  public EncryptedResponse getFspCount() throws Exception {
    // List<Map<String, Object>> count = fsprepo.getFspCount();
    return new EncryptedResponse("count");
  }

  @PostMapping("/get-all-users")
  public EncryptedResponse getUserList() throws Exception {

    List<Map<String, Object>> users = userRepo.getUserList();
    return new EncryptedResponse(users);
  }

  @PostMapping("/get-all-operational-expense")
  public EncryptedResponse getOperationalExpense() throws Exception {
    List<Map<String, Object>> operationalExpense = userRepo.getOperationalExpense();
    return new EncryptedResponse(operationalExpense);
  }

  @PostMapping("/get-fsp-details")
  public EncryptedResponse getFspDetails(@RequestBody EncryptedRequest req, @AuthenticationPrincipal User user)
      throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
    String regionName = null;
    String fieldSeasonYear = null;
    String proposalId = null;
    Long id = null;
    String status = null;

    if (body.custom() != null) {
      regionName = (String) body.custom().get("regionName");
      fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
      proposalId = (String) body.custom().get("proposalId");
      id = (Long) body.custom().get("id");
      status = (String) body.custom().get("status");
    }
    Page<Map<String, Object>> fspDetail = fsprepo.getFspDetails(regionName, fieldSeasonYear, proposalId, id,
        user.getId(), user.getStateId(), status, pageable);

    return new EncryptedResponse(fspDetail);

  }

  @PostMapping("/get-fsp-details-form-view")
  public EncryptedResponse getFspDetailsForView(@RequestBody EncryptedRequest req)
      throws Exception {
    var body = req.bodyAs(GetId.class);
    Long id = Long.parseLong(body.id());

    List<Map<String, Object>> fspDetail = fsprepo.getFspDetailsForView(id);

    return new EncryptedResponse(fspDetail);

  }

  @PostMapping("/get-fsp-details-form-wise")
  public EncryptedResponse getAlreadyFilledDetailsFormWise(@RequestBody EncryptedRequest req)
      throws Exception {
    var body = req.bodyAs(GetId.class);
    Long id = Long.parseLong(body.id());
    List<Map<String, Object>> fspDetail = fsprepo.getAlreadyFilledDetailsFormWise(id);
    return new EncryptedResponse(fspDetail);
  }

  @Transactional
  @PostMapping("/drop-fsp-details")
  public EncryptedResponse dropFspDetails(@RequestBody EncryptedRequest req, @AuthenticationPrincipal User user)
      throws Exception {
    var body = req.bodyAs(FspApprove.class);

    Long fspFormId = body.getFspFormId();
    String dropFspRemarks = body.getDropFspRemarks();
    ZonedDateTime currentDateTime = ZonedDateTime.now();
    Long userId = user.getId();

    System.out.println("dataaaaaaaa" + fspFormId + dropFspRemarks + userId);
    fsprepo.dropFspDetails(fspFormId, dropFspRemarks, currentDateTime, userId);

    return new EncryptedResponse("drop");
  }

  @Transactional
  @PostMapping("/delete-fsp-details")
  public EncryptedResponse deleteFspDetails(@RequestBody EncryptedRequest req)
      throws Exception {
    var body = req.bodyAs(LongId.class);
    fsprepo.deleteFspDetails(body.id());
    return new EncryptedResponse("deleted");
  }

  @PostMapping("/get-designation-list")
  public <json> EncryptedResponse getDesignation(
      HttpServletResponse response) throws Exception {
    List<Map<String, Object>> result = userRepo.getDesignationList();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-employees-list")
  public <json> EncryptedResponse getEmployeesList(@Valid @RequestBody EncryptedRequest req,
      HttpServletResponse response) throws Exception {
    var body = req.bodyAs(GetId.class);
    String designationCode;

    if (body.code() == "") {
      designationCode = null;
    } else {
      designationCode = body.code();
    }
    List<Map<String, Object>> result = userRepo.getEmpList(designationCode);
    return new EncryptedResponse(result);
  }

  @SuppressWarnings("deprecation")
  @PostMapping("/get-fsp-Report")
  public EncryptedResponse getfdaReport(@RequestBody EncryptedRequest req, HttpServletRequest request)
      throws Exception {
    var reportReq = req.bodyAs(Report.class);

    var pagination = reportReq.pagination();
    var searchQuery = reportReq.search();
    searchQuery = StringUtils.isBlank(searchQuery) ? null : searchQuery;

    // var custom = reportReq.custom();
    // String state = StringUtils.isNotBlank((String) custom.get("state")) ?
    // (String) custom.get("state") : null;
    // String district = StringUtils.isNotBlank((String) custom.get("district")) ?
    // (String) custom.get("district") : null;
    // String taluka = StringUtils.isNotBlank((String) custom.get("taluka")) ?
    // (String) custom.get("taluka") : null;
    // String village = StringUtils.isNotBlank((String) custom.get("village")) ?
    // (String) custom.get("village") : null;
    // String Employee = StringUtils.isNotBlank((String) custom.get("Employee")) ?
    // (String) custom.get("Employee") : null;
    // String Status = StringUtils.isNotBlank((String) custom.get("Status")) ?
    // (String) custom.get("Status") : null;

    // String filters = custom != null ? (String) custom.get("filters") : null;

    // Updated common query with correct join condition for district boundary
    String commonQuery = """
        FROM fsp_data fsp
        """;

    // Add filter conditions if present
    // if (!StringUtils.isBlank(filters)) {
    // commonQuery += " AND " + filters;
    // }

    // if (!StringUtils.isBlank(state)) {
    // commonQuery += "AND fds.stateid = '" + state + "'";
    // }

    // if (!StringUtils.isBlank(district)) {
    // commonQuery += "AND fds.districtid = '" + district + "'";
    // }
    // if (!StringUtils.isBlank(taluka)) {
    // commonQuery += "AND fds.talukaid = '" + taluka + "'";
    // }
    // if (!StringUtils.isBlank(village)) {
    // commonQuery += "AND fds.villageid = '" + village + "'";
    // }
    // if (!StringUtils.isBlank(Employee)) {
    // commonQuery += "AND fds.employee_id = '" + Employee + "'";
    // }
    // if (!StringUtils.isBlank(Status)) {
    // commonQuery += "AND fds.status = '" + Status + "'";
    // }
    // // Add search condition if present
    // if (!StringUtils.isBlank(searchQuery)) {
    // commonQuery += """
    // AND (
    // LOWER(fem.employee_name) LIKE LOWER(CONCAT('%%', ?, '%%')) OR
    // LOWER(fhm.headquarter) LIKE LOWER(CONCAT('%%', ?, '%%')) OR
    // LOWER(st.stname) LIKE LOWER(CONCAT('%%', ?, '%%')) OR
    // LOWER(dt.name11) LIKE LOWER(CONCAT('%%', ?, '%%'))
    // )
    // """;
    // }

    String contentQuery = """
        SELECT
            id,fsp_form_id,proposal_id,topo_sheet_number
        """ + commonQuery +
        " LIMIT " + pagination.size() +
        " OFFSET " + (pagination.page() * pagination.size());

    String countQuery = "SELECT count(fsp.id) " + commonQuery;

    List<Map<String, Object>> content;
    Long totalElements;

    try {
      if (!StringUtils.isBlank(searchQuery)) {
        // Execute queries with search parameters
        Object[] params = new Object[] { searchQuery, searchQuery, searchQuery, searchQuery };
        content = jdbcTemplate.queryForList(contentQuery, params);
        totalElements = jdbcTemplate.queryForObject(countQuery, params, Long.class);
      } else {
        // Execute queries without search parameters
        content = jdbcTemplate.queryForList(contentQuery);
        totalElements = jdbcTemplate.queryForObject(countQuery, Long.class);
      }

      totalElements = totalElements == null ? 0 : totalElements;
      Long totalPages = (long) Math.ceil(totalElements * 1.0 / pagination.size());

      Map<String, Object> resultHashMap = new HashMap<>();
      resultHashMap.put("content", content);
      resultHashMap.put("totalPages", totalPages);
      resultHashMap.put("totalElements", totalElements);

      return new EncryptedResponse(resultHashMap);

    } catch (DataAccessException e) {
      // Log the error
      // System.err.println("Database error: " + e.getMessage());
      throw new Exception("Error fetching FDA report data", e);
    }
  }

  // dulera
  @PostMapping("/get-options")
  public EncryptedResponse getOptions(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(SelectedOptionsReq.class);
    if ("proposal-id".equals(body.selectedOption())) {
      return new EncryptedResponse(userRepo.getProposals());
    } else {
      return new EncryptedResponse(userRepo.getFieldSeasonYears());
    }
  }

  // dulera
  @PostMapping("/get-data")
  public EncryptedResponse getData(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(SelectedOptionsReq.class);
    if ("proposal-id".equals(body.selectedOption())) {
      return new EncryptedResponse(userRepo.getData(null, body.selectedDropdown()));
    } else {
      return new EncryptedResponse(userRepo.getData(body.selectedDropdown(), null));
    }
  }

  // mayursolanki
  @PostMapping("/get-emp-by-id")
  public EncryptedResponse getEmployeeByIds(@RequestBody EncryptedRequest req)
      throws Exception {
        System.out.println("calledaaaaaaaaaaaaaaaaaaaa");
    var body = req.bodyAs(IdWithPaginate.class);
    Integer id = Integer.valueOf(body.id());
    System.out.println(id);
    List<Map<String, Object>> result = userRepo.getEmpById(id);
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-site-name")
  public EncryptedResponse getSiteName(@RequestBody EncryptedRequest req)
      throws Exception {
        System.out.println("calledaaaaaaaaaaaaaaaaaaaa");
    var body = req.bodyAs(IdWithPaginate.class);
    String sitename = String.valueOf(body.sitename());
    System.out.println(sitename);
    List<Map<String, Object>> result = userRepo.getSiteName(sitename);
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-role-list")
  public <json> EncryptedResponse getRoleList(
      HttpServletResponse req) throws Exception {
    List<Map<String, Object>> result = userRepo.getRoleList();
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-draft-fsp-details/export")
  public EncryptedResponse getDraftFspExport(@AuthenticationPrincipal User user, @RequestBody EncryptedRequest req)
      throws Exception {

    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
    System.out.println("testtttt" + user.getId());
    List<Map<String, Object>> result = fsprepo.getDraftFspExport(user.getId());
    return new EncryptedResponse(result);
  }

  @PostMapping("/get-fsp-details/export")
  public EncryptedResponse getFspDetailsExport(@RequestBody EncryptedRequest req, @AuthenticationPrincipal User user)
      throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
    String regionName = null;
    String fieldSeasonYear = null;
    String proposalId = null;
    Long id = null;
    String status = null;

    if (body.custom() != null) {
      regionName = (String) body.custom().get("regionName");
      fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
      proposalId = (String) body.custom().get("proposalId");
      id = (Long) body.custom().get("id");
      status = (String) body.custom().get("status");
    }
    List<Map<String, Object>> fspDetail = fsprepo.getFspDetailsExport(regionName, fieldSeasonYear, proposalId, id,
        user.getId(), user.getStateId(), status);

    return new EncryptedResponse(fspDetail);

  }

  @PostMapping("/get-employees-name-designation")
  public <json> EncryptedResponse getEmployeesNamedesignation(@Valid @RequestBody EncryptedRequest req,
      HttpServletResponse response) throws Exception {

    EmployeeData body = req.bodyAs(EmployeeData.class);
    System.out.println("TestData Data:::::" + body.employee_id().stream().map(Integer::valueOf).toString());

    // List<Map<String, Object>> result = userRepo.getEmpByIdsList(
    // body.employee_id().stream().map(Integer::valueOf).toList()
    // );

    List<Integer> employeeIds = body.employee_id().stream()
        .map(Integer::valueOf)
        .toList();
    System.out.println("Employee" + employeeIds.get(0));

    if (employeeIds.isEmpty()) {
      throw new IllegalArgumentException("Employee IDs list is empty");
    }
    List<Map<String, Object>> result = new ArrayList<>();
    // Fetch data in a single query
    for (Integer id : employeeIds) {
      result = userRepo.getEmpByIdsList(id);
    }

    // Return encrypted response
    return new EncryptedResponse(result);
    // Return the encrypted response

  }
}
