package org.bisag.ocbis.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "fsp_pu_cruise_activity")
public class CruiseActivity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String cruiseActivities;
    private String cruiseLeg;
    private String cruiseTarget;

    @ManyToOne
    @JoinColumn(name = "fsp_pu_id")
    private ParticipatingUnits participatingUnits;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCruiseLeg() {
        return cruiseLeg;
    }

    public void setCruiseLeg(String cruiseLeg) {
        this.cruiseLeg = cruiseLeg;
    }

    public String getCruiseTarget() {
        return cruiseTarget;
    }

    public void setCruiseTarget(String cruiseTarget) {
        this.cruiseTarget = cruiseTarget;
    }

    public ParticipatingUnits getParticipatingUnits() {
        return participatingUnits;
    }

    public void setParticipatingUnits(ParticipatingUnits participatingUnits) {
        this.participatingUnits = participatingUnits;
    }

    public String getCruiseActivities() {
        return cruiseActivities;
    }

    public void setCruiseActivities(String cruiseActivities) {
        this.cruiseActivities = cruiseActivities;
    }

}
