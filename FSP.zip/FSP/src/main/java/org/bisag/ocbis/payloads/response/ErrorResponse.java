package org.bisag.ocbis.payloads.response;

public record ErrorResponse(String error) {}
