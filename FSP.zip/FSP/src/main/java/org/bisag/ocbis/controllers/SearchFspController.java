package org.bisag.ocbis.controllers;
import java.util.List;
import java.util.Map;

import org.bisag.ocbis.payloads.request.EncryptedRequest;
import org.bisag.ocbis.payloads.request.Report;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.FspRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/searchfsp")
public class SearchFspController {

  @Autowired
  FspRepo fsprepo;

  @PostMapping("/search-fsp")
  public <json> EncryptedResponse SearchFsp(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
    // Extracting fields from the custom map
    String fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
    String mission = (String) body.custom().get("mission");
    String subMission = (String) body.custom().get("subMission");
    String fspIdString = (String) body.custom().get("fspId");
    Long fspId = null;

    if (fspIdString != null && !fspIdString.isEmpty()) {
      try {
        fspId = Long.parseLong(fspIdString);
      } catch (NumberFormatException e) {
        System.err.println("Invalid fspId format: " + fspIdString);
      }
    }
    String region = (String) body.custom().get("region");
    String stateUnit = (String) body.custom().get("stateUnit");
    String fspStageOfInvestigation = (String) body.custom().get("fspStageOfInvestigation");
    String title = (String) body.custom().get("title");
    String fspItemType = (String) body.custom().get("fspItemType");
    String fspOwner = (String) body.custom().get("fspOwner");
    String activity = (String) body.custom().get("activity");

    // Call to repository with the necessary parameters
    Page<Map<String, Object>> result = fsprepo.getSearchFsp(fieldSeasonYear, mission, subMission, fspId, region,
        stateUnit, fspStageOfInvestigation, title, fspItemType, fspOwner, activity, pageable);

    return new EncryptedResponse(result);
  }

  @PostMapping("/search-fsp-with-state")
  public <json> EncryptedResponse SearchFspWithState(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
    String fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
    String mission = (String) body.custom().get("mission");
    String subMission = (String) body.custom().get("subMission");
    String fspIdString = (String) body.custom().get("fspId");
    Long fspId = null;

    // Parse fspId from string to Long
    if (fspIdString != null && !fspIdString.isEmpty()) {
      try {
        fspId = Long.parseLong(fspIdString);
      } catch (NumberFormatException e) {
        System.err.println("Invalid fspId format: " + fspIdString);
      }
    }

    String region = (String) body.custom().get("region");
    String stateUnit = (String) body.custom().get("stateUnit");
    String fspStageOfInvestigation = (String) body.custom().get("fspStageOfInvestigation");
    String commodityName = (String) body.custom().get("commodityName");
    String commoditySubGroup = (String) body.custom().get("commoditySubGroup");
    String mineralType = (String) body.custom().get("mineralType");
    String stateName = (String) body.custom().get("stateName");
    String title = (String) body.custom().get("title");
    String fspItemType = (String) body.custom().get("fspItemType");
    String fspOwner = (String) body.custom().get("fspOwner");
    String activity = (String) body.custom().get("activity");

    // Call to repository with the necessary parameters
    Page<Map<String, Object>> result = fsprepo.getSearchFspWithState(
        fieldSeasonYear,
        mission,
        subMission,
        fspId,
        region,
        stateUnit,
        fspStageOfInvestigation,
        commodityName,
        commoditySubGroup,
        mineralType,
        stateName,
        title,
        fspItemType,
        fspOwner,
        activity,
        pageable);

    return new EncryptedResponse(result);
  }

  @PostMapping("/search-fsp-qualitative")
  public EncryptedResponse searchFspQualitative(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());

    String fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
    String mission = (String) body.custom().get("mission");
    String subMission = (String) body.custom().get("subMission");
    String fspIdString = (String) body.custom().get("fspId");
    Long fspId = null;

    if (fspIdString != null && !fspIdString.isEmpty()) {
      try {
        fspId = Long.parseLong(fspIdString);
      } catch (NumberFormatException e) {
        System.err.println("Invalid fspId format: " + fspIdString);
      }
    }

    String region = (String) body.custom().get("region");
    String stateUnit = (String) body.custom().get("stateUnit");
    String fspOwner = (String) body.custom().get("fspOwner");
    String fspItemType = (String) body.custom().get("fspItemType");
    String title = (String) body.custom().get("title");
    String task = (String) body.custom().get("task");

    Page<Map<String, Object>> result = fsprepo.getQualitativeSearchFsp(
        fieldSeasonYear,
        mission,
        subMission,
        fspId,
        region,
        stateUnit,
        fspOwner,
        fspItemType,
        title,
        task,
        pageable);

    return new EncryptedResponse(result);
  }

  @PostMapping("/search-fsp-expense-and-vehicle-track")
  public EncryptedResponse searchFspExpenseAndVehicleTrack(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());

    String fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
    String mission = (String) body.custom().get("mission");
    String subMission = (String) body.custom().get("subMission");
    String region = (String) body.custom().get("region");
    String stateUnit = (String) body.custom().get("stateUnit");
    String fspOwner = (String) body.custom().get("fspOwner");
    String title = (String) body.custom().get("title");
    String expenseHead = (String) body.custom().get("expenseHead");

    Page<Map<String, Object>> result = fsprepo.getExpenseAndVehicleTrackSearchFsp(
        fieldSeasonYear,
        mission,
        subMission,
        region,
        stateUnit,
        fspOwner,
        title,
        expenseHead,
        pageable);

    return new EncryptedResponse(result);
  }

  @PostMapping("/search-fsp-proposal-search")
  public EncryptedResponse searchFspProposalSearch(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());

    String fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
    String mission = (String) body.custom().get("mission");
    String subMission = (String) body.custom().get("subMission");
    String region = (String) body.custom().get("region");
    String stateUnit = (String) body.custom().get("stateUnit");
    String fspOwner = (String) body.custom().get("fspOwner");
    String title = (String) body.custom().get("title");
    String proposalId = (String) body.custom().get("proposalId");
    String itemType = (String) body.custom().get("itemType");
    String approver = (String) body.custom().get("approver");
    Page<Map<String, Object>> result = fsprepo.getProposalSearchFsp(
        fieldSeasonYear,
        mission,
        subMission,
        proposalId,
        region,
        stateUnit,
        title,
        itemType,
        fspOwner,
        approver,
        pageable);

    return new EncryptedResponse(result);
  }

  @PostMapping("/search-fsp-formulation-search")
  public EncryptedResponse searchFspFormulationSearch(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());

    String fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
    String mission = (String) body.custom().get("mission");
    String subMission = (String) body.custom().get("subMission");
    String region = (String) body.custom().get("region");
    String stateUnit = (String) body.custom().get("stateUnit");
    String fspOwner = (String) body.custom().get("fspOwner");
    String title = (String) body.custom().get("title");
    String proposalId = (String) body.custom().get("proposalId");
    String itemType = (String) body.custom().get("itemType");
    String fspStageOfInvestigation = (String) body.custom().get("fspStageOfInvestigation");
    String commodityName = (String) body.custom().get("commodityName");
    String commoditySubGroup = (String) body.custom().get("commoditySubGroup");
    String mineralType = (String) body.custom().get("mineralType");
    String activity = (String) body.custom().get("activity");

    Page<Map<String, Object>> result = fsprepo.getFormulationSearchFsp(
        fieldSeasonYear,
        proposalId,
        mission,
        subMission,
        region,
        fspStageOfInvestigation,
        commodityName,
        commoditySubGroup,
        mineralType,
        activity,
        stateUnit,
        itemType,
        title,
        fspOwner,
        pageable);

    return new EncryptedResponse(result);
  }

  // @PostMapping("/save-search-fsp")
  // public <json> EncryptedResponse saveFspDetail(
  // @Valid @RequestBody EncryptedRequest req, @AuthenticationPrincipal User user)
  // throws Exception {
  // var body = req.bodyAs(CreateFsp.class);

  // try {
  // body.setStepsCompleted(body.getStepsCompleted());
  // body.setCreateFspDate(ZonedDateTime.now());

  // } catch (Exception e) {
  // return new EncryptedResponse("false");
  // }
  // return new EncryptedResponse("saved successfully");
  // }

  @PostMapping("/search-fsp/export")
  public <json> EncryptedResponse SearchFspExport(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
    // Extracting fields from the custom map
    String fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
    String mission = (String) body.custom().get("mission");
    String subMission = (String) body.custom().get("subMission");
    String fspIdString = (String) body.custom().get("fspId");
    Long fspId = null;

    if (fspIdString != null && !fspIdString.isEmpty()) {
      try {
        fspId = Long.parseLong(fspIdString);
      } catch (NumberFormatException e) {
        System.err.println("Invalid fspId format: " + fspIdString);
      }
    }
    String region = (String) body.custom().get("region");
    String stateUnit = (String) body.custom().get("stateUnit");
    String fspStageOfInvestigation = (String) body.custom().get("fspStageOfInvestigation");
    String title = (String) body.custom().get("title");
    String fspItemType = (String) body.custom().get("fspItemType");
    String fspOwner = (String) body.custom().get("fspOwner");
    String activity = (String) body.custom().get("activity");

    // Call to repository with the necessary parameters
    List<Map<String, Object>> result = fsprepo.getSearchFspExport(fieldSeasonYear, mission, subMission, fspId, region,
        stateUnit, fspStageOfInvestigation, title, fspItemType, fspOwner, activity);

    return new EncryptedResponse(result);
  }

  @PostMapping("/search-fsp-with-state/export")
  public <json> EncryptedResponse SearchFspWithStateExport(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
    String fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
    String mission = (String) body.custom().get("mission");
    String subMission = (String) body.custom().get("subMission");
    String fspIdString = (String) body.custom().get("fspId");
    Long fspId = null;

    // Parse fspId from string to Long
    if (fspIdString != null && !fspIdString.isEmpty()) {
      try {
        fspId = Long.parseLong(fspIdString);
      } catch (NumberFormatException e) {
        System.err.println("Invalid fspId format: " + fspIdString);
      }
    }

    String region = (String) body.custom().get("region");
    String stateUnit = (String) body.custom().get("stateUnit");
    String fspStageOfInvestigation = (String) body.custom().get("fspStageOfInvestigation");
    String commodityName = (String) body.custom().get("commodityName");
    String commoditySubGroup = (String) body.custom().get("commoditySubGroup");
    String mineralType = (String) body.custom().get("mineralType");
    String stateName = (String) body.custom().get("stateName");
    String title = (String) body.custom().get("title");
    String fspItemType = (String) body.custom().get("fspItemType");
    String fspOwner = (String) body.custom().get("fspOwner");
    String activity = (String) body.custom().get("activity");

    // Call to repository with the necessary parameters
    List<Map<String, Object>> result = fsprepo.getSearchFspWithStateExport(
        fieldSeasonYear,
        mission,
        subMission,
        fspId,
        region,
        stateUnit,
        fspStageOfInvestigation,
        commodityName,
        commoditySubGroup,
        mineralType,
        stateName,
        title,
        fspItemType,
        fspOwner,
        activity);

    return new EncryptedResponse(result);
  }

  @PostMapping("/search-fsp-qualitative/export")
  public EncryptedResponse searchFspQualitativeExport(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());

    String fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
    String mission = (String) body.custom().get("mission");
    String subMission = (String) body.custom().get("subMission");
    String fspIdString = (String) body.custom().get("fspId");
    Long fspId = null;

    if (fspIdString != null && !fspIdString.isEmpty()) {
      try {
        fspId = Long.parseLong(fspIdString);
      } catch (NumberFormatException e) {
        System.err.println("Invalid fspId format: " + fspIdString);
      }
    }

    String region = (String) body.custom().get("region");
    String stateUnit = (String) body.custom().get("stateUnit");
    String fspOwner = (String) body.custom().get("fspOwner");
    String fspItemType = (String) body.custom().get("fspItemType");
    String title = (String) body.custom().get("title");
    String task = (String) body.custom().get("task");

    List<Map<String, Object>> result = fsprepo.getQualitativeSearchFspExport(
        fieldSeasonYear,
        mission,
        subMission,
        fspId,
        region,
        stateUnit,
        fspOwner,
        fspItemType,
        title,
        task);

    return new EncryptedResponse(result);
  }


  @PostMapping("/search-fsp-expense-and-vehicle-track/export")
  public EncryptedResponse searchFspExpenseAndVehicleTrackExport(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());

    String fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
    String mission = (String) body.custom().get("mission");
    String subMission = (String) body.custom().get("subMission");
    String region = (String) body.custom().get("region");
    String stateUnit = (String) body.custom().get("stateUnit");
    String fspOwner = (String) body.custom().get("fspOwner");
    String title = (String) body.custom().get("title");
    String expenseHead = (String) body.custom().get("expenseHead");

    List<Map<String, Object>> result = fsprepo.getExpenseAndVehicleTrackSearchFspExport(
        fieldSeasonYear,
        mission,
        subMission,
        region,
        stateUnit,
        fspOwner,
        title,
        expenseHead);

    return new EncryptedResponse(result);
  }

  @PostMapping("/search-fsp-proposal-search/export")
  public EncryptedResponse searchFspProposalSearchExport(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());

    String fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
    String mission = (String) body.custom().get("mission");
    String subMission = (String) body.custom().get("subMission");
    String region = (String) body.custom().get("region");
    String stateUnit = (String) body.custom().get("stateUnit");
    String fspOwner = (String) body.custom().get("fspOwner");
    String title = (String) body.custom().get("title");
    String proposalId = (String) body.custom().get("proposalId");
    String itemType = (String) body.custom().get("itemType");
    String approver = (String) body.custom().get("approver");
    List<Map<String, Object>> result = fsprepo.getProposalSearchFspExport(
        fieldSeasonYear,
        mission,
        subMission,
        proposalId,
        region,
        stateUnit,
        title,
        itemType,
        fspOwner,
        approver);

    return new EncryptedResponse(result);
  }

  @PostMapping("/search-fsp-formulation-search/export")
  public EncryptedResponse searchFspFormulationSearchExport(@RequestBody EncryptedRequest req) throws Exception {
    var body = req.bodyAs(Report.class);
    var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());

    String fieldSeasonYear = (String) body.custom().get("fieldSeasonYear");
    String mission = (String) body.custom().get("mission");
    String subMission = (String) body.custom().get("subMission");
    String region = (String) body.custom().get("region");
    String stateUnit = (String) body.custom().get("stateUnit");
    String fspOwner = (String) body.custom().get("fspOwner");
    String title = (String) body.custom().get("title");
    String proposalId = (String) body.custom().get("proposalId");
    String itemType = (String) body.custom().get("itemType");
    String fspStageOfInvestigation = (String) body.custom().get("fspStageOfInvestigation");
    String commodityName = (String) body.custom().get("commodityName");
    String commoditySubGroup = (String) body.custom().get("commoditySubGroup");
    String mineralType = (String) body.custom().get("mineralType");
    String activity = (String) body.custom().get("activity");

    List<Map<String, Object>> result = fsprepo.getFormulationSearchFspExport(
        fieldSeasonYear,
        proposalId,
        mission,
        subMission,
        region,
        fspStageOfInvestigation,
        commodityName,
        commoditySubGroup,
        mineralType,
        activity,
        stateUnit,
        itemType,
        title,
        fspOwner);

    return new EncryptedResponse(result);
  }

}
