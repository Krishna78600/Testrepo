package org.bisag.ocbis.payloads.request;

import java.time.ZonedDateTime;

public record FspApproveRequest(
   Long id,
   
   Long forwardedBySuhead,
   String suHeadRemarks,
   String suHeadStatus,
   ZonedDateTime suHeadCreatedDate,
   Long forwardedToSuhead,
    
   Long forwardedByRmhOfPm,
   String RmhOfPmRemarks,
   String RmhOfPmStatus,
   ZonedDateTime RmhOfPmCreatedDate,
   Long forwardedToRmhOfPm,

   Long forwardedByHod,
   String hodRemarks,
   String hodStatus,
   ZonedDateTime hodCreatedDate,
   Long forwardedTohod,

   Long forwardedByDdgOfSm,
   String DdgOfSmRemarks,
   String DdgOfSmStatus,
   ZonedDateTime DdgOfSmCreatedDate,
   Long forwardedToDdgOfSm,

   Long forwardedByAdgPss,
   String AdgPssRemarks,
   String AdgPssStatus,
   ZonedDateTime AdgPssCreatedDate,
   Long forwardedToAdgPss,

   Long forwardedByNmhOfPm,
   String NmhOfPmRemarks,
   String NmhOfPmStatus,
   ZonedDateTime NmhOfPmCreatedDate,
   Long forwardedToNmhOfPm,

   Long forwardedByDdgOfStssOrAdss,
   String DdgOfStssOrAdssRemarks,
   String DdgOfStssOrAdssStatus,
   ZonedDateTime DdgOfStssOrAdssCreatedDate,
   Long forwardedToDdgOfStssOrAdss,

   Long forwardedByAdgOrStssOrAdss,
   String AdgOrStssOrAdssRemarks,
   String AdgOrStssOrAdssStatus,
   ZonedDateTime AdgOrStssOrAdssdCreatedDate,
   Long forwardedToAdgOrStssOrAdss,
  

   Long createFspUserId,
   String proposalId,
   Long fspFormId
) {
    
}
