package org.bisag.ocbis.payloads.request;

public record AddCommittee(String fspNewCommittee) {

}
