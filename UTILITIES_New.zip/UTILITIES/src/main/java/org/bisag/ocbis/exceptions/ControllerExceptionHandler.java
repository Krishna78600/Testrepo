package org.bisag.ocbis.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.fasterxml.jackson.databind.ObjectMapper;

@ControllerAdvice
public class ControllerExceptionHandler {
  public static final ObjectMapper mapper = new ObjectMapper();
  static {
    mapper.findAndRegisterModules();
  }

  @ExceptionHandler(HttpMessageNotReadableException.class)
  public ResponseEntity<ErrorMessage> messageNotReadableException(
      HttpMessageNotReadableException ex, WebRequest request) {
    ex.printStackTrace();
    ErrorMessage message = new ErrorMessage(HttpStatus.BAD_REQUEST.value(), new Date(),
        "Could not read request body", request.getDescription(false));
    return new ResponseEntity<ErrorMessage>(message, HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(MethodArgumentNotValidException.class)
  public ResponseEntity<ErrorMessage> methodArgInvalid(MethodArgumentNotValidException ex,
      WebRequest request) {
    ErrorMessage message = new ErrorMessage(HttpStatus.BAD_REQUEST.value(), new Date(),
        ex.getFieldErrors().get(0).getDefaultMessage(), request.getDescription(false));
    return new ResponseEntity<ErrorMessage>(message, HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(BadRequestException.class)
  public ResponseEntity<?> badRequestException(BadRequestException ex, WebRequest request) {
    ErrorMessage message = new ErrorMessage(HttpStatus.BAD_REQUEST.value(), new Date(),
        ex.getMessage(), request.getDescription(false));
    return new ResponseEntity<ErrorMessage>(message, HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(UnauthorizedException.class)
  public ResponseEntity<?> unauthorizedException(UnauthorizedException ex, WebRequest request) {
    ErrorMessage message = new ErrorMessage(HttpStatus.UNAUTHORIZED.value(), new Date(),
        ex.getMessage(), request.getDescription(false));
    return new ResponseEntity<ErrorMessage>(message, HttpStatus.UNAUTHORIZED);
  }

  @ExceptionHandler(ForbiddenException.class)
  public ResponseEntity<?> forbiddenException(ForbiddenException ex, WebRequest request) {
    ErrorMessage message = new ErrorMessage(HttpStatus.FORBIDDEN.value(), new Date(),
        ex.getMessage(), request.getDescription(false));
    return new ResponseEntity<ErrorMessage>(message, HttpStatus.FORBIDDEN);
  }

  @ExceptionHandler(NotFoundException.class)
  public ResponseEntity<?> notFoundException(NotFoundException ex, WebRequest request) {
    ErrorMessage message = new ErrorMessage(HttpStatus.NOT_FOUND.value(), new Date(),
        ex.getMessage(), request.getDescription(false));
    return new ResponseEntity<ErrorMessage>(message, HttpStatus.NOT_FOUND);
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<?> globalExceptionHandler(Exception ex, WebRequest request)
      throws BadRequestException {
    System.err.println("--- Caught error in global exception handler ---");
    ex.printStackTrace();
    System.err.println("--- x ---");
    ErrorMessage message = new ErrorMessage(HttpStatus.INTERNAL_SERVER_ERROR.value(), new Date(),
        "Internal Server Error", request.getDescription(false));
    return new ResponseEntity<ErrorMessage>(message, HttpStatus.INTERNAL_SERVER_ERROR);
  }
}
