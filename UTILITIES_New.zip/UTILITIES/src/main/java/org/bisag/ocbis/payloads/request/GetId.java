package org.bisag.ocbis.payloads.request;

public record GetId(String id, String code,Long fspFormId) {
}
