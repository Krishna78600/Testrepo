package org.bisag.ocbis.payloads.request;

public record QueryBuilderReport(String query) {}
