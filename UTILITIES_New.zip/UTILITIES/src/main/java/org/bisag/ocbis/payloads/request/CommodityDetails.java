package org.bisag.ocbis.payloads.request;

public record CommodityDetails(Long id) {

}
