package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.NonConsumableItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NonConsumableItemRepo extends JpaRepository<NonConsumableItem, Long> {
    
}
