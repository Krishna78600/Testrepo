package org.bisag.ocbis.models;

import java.time.ZonedDateTime;
import java.util.Map;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "fsp_approve_levels_details")
public class FspApprove {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long createFspUserId;
    private String proposalId;
    private Long fspFormId;

    private String firstApprovingAuthorityName;
    private String ParentMissionCode;
    private String subMissionCode;

    private Long forwardedByFspCreater;
    private ZonedDateTime fspCreaterCreatedDate;

    private Long forwardedBySuhead;
    private Long forwardedToSuhead;
    private String suHeadRemarks;
    private String suHeadStatus;
    private ZonedDateTime suHeadCreatedDate;

    private Long forwardedByRmhOfPm;
    private Long forwardedToRmhOfPm;
    private String RmhOfPmRemarks;
    private String RmhOfPmStatus;
    private ZonedDateTime RmhOfPmCreatedDate;

    private Long forwardedByNmhOfPm;
    private Long forwardedToNmhOfPm;
    private String NmhOfPmRemarks;
    private String NmhOfPmStatus;
    private ZonedDateTime NmhOfPmCreatedDate;

    private Long forwardedByHod;
    private Long forwardedToHod;
    private String hodRemarks;
    private String hodStatus;
    private ZonedDateTime hodCreatedDate;

    private Long forwardedByDdgOfSm;
    private Long forwardedToDdgOfSm;
    private String DdgOfSmRemarks;
    private String DdgOfSmStatus;
    private ZonedDateTime DdgOfSmCreatedDate;

    private Long forwardedByDdgOfStssOrAdss;
    private String DdgOfStssOrAdssRemarks;
    private String DdgOfStssOrAdssStatus;
    private ZonedDateTime DdgOfStssOrAdssCreatedDate;
    private Long forwardedToDdgOfStssOrAdss;

    private Long forwardedByAdgOfPss;
    private Long forwardedToAdgOfPss;
    private String AdgOfPssRemarks;
    private String AdgOfPssStatus;
    private ZonedDateTime AdgOfPssCreatedDate;

    private Long forwardedByAdgOfStssOrAdss;
    private String AdgOrStssOfAdssRemarks;
    private String AdgOrStssOfAdssStatus;
    private ZonedDateTime AdgOrStssOfAdssdCreatedDate;
    private Long forwardedToAdgOfStssOrAdss;

    private Long forwardedByTrainingInstituteHqdh;
    private String trainingInstituteHqdhRemarks;
    private String trainingInstituteHqdhStatus; 
    private ZonedDateTime trainingInstituteHqdhCreatedDate; 
    private Long forwardedToTrainingInstituteHqdh;

    private Long forwardedByTrainingInstituteHod;
    private String trainingInstituteHodRemarks; 
    private String trainingInstituteHodStatus; 
    private ZonedDateTime trainingInstituteHodCreatedDate; 
    private Long forwardedToTrainingInstituteHod;

    private Integer totalLevalsOfApproval;
    private String AutoPushStatus;

    private Long forwardedToFspCreaterId;
    private String rejectOrReturnFspStatus;
    private String rejectOrReturnFspRemarks;
    private ZonedDateTime rejectOrReturnFspCreatedDate;
    private Long rejectOrReturnFspForwardedbyId;

    private String dropFspStatus;
    private String dropFspRemarks;
    private ZonedDateTime dropFspCreatedDate;
    private Long dropFspForwardedById;

    // Access rights for approval to officers designation wise
    @JdbcTypeCode(SqlTypes.JSON)
    Map<String, Object> access;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCreateFspUserId() {
        return createFspUserId;
    }

    public void setCreateFspUserId(Long createFspUserId) {
        this.createFspUserId = createFspUserId;
    }

    public String getProposalId() {
        return proposalId;
    }

    public void setProposalId(String proposalId) {
        this.proposalId = proposalId;
    }

    public Long getFspFormId() {
        return fspFormId;
    }

    public void setFspFormId(Long fspFormId) {
        this.fspFormId = fspFormId;
    }

    public String getFirstApprovingAuthorityName() {
        return firstApprovingAuthorityName;
    }

    public void setFirstApprovingAuthorityName(String firstApprovingAuthorityName) {
        this.firstApprovingAuthorityName = firstApprovingAuthorityName;
    }

    public String getParentMissionCode() {
        return ParentMissionCode;
    }

    public void setParentMissionCode(String parentMissionCode) {
        ParentMissionCode = parentMissionCode;
    }

    public String getSubMissionCode() {
        return subMissionCode;
    }

    public void setSubMissionCode(String subMissionCode) {
        this.subMissionCode = subMissionCode;
    }

    public Long getForwardedByFspCreater() {
        return forwardedByFspCreater;
    }

    public void setForwardedByFspCreater(Long forwardedByFspCreater) {
        this.forwardedByFspCreater = forwardedByFspCreater;
    }

    public ZonedDateTime getFspCreaterCreatedDate() {
        return fspCreaterCreatedDate;
    }

    public void setFspCreaterCreatedDate(ZonedDateTime fspCreaterCreatedDate) {
        this.fspCreaterCreatedDate = fspCreaterCreatedDate;
    }

    public Long getForwardedBySuhead() {
        return forwardedBySuhead;
    }

    public void setForwardedBySuhead(Long forwardedBySuhead) {
        this.forwardedBySuhead = forwardedBySuhead;
    }

    public Long getForwardedToSuhead() {
        return forwardedToSuhead;
    }

    public void setForwardedToSuhead(Long forwardedToSuhead) {
        this.forwardedToSuhead = forwardedToSuhead;
    }

    public String getSuHeadRemarks() {
        return suHeadRemarks;
    }

    public void setSuHeadRemarks(String suHeadRemarks) {
        this.suHeadRemarks = suHeadRemarks;
    }

    public String getSuHeadStatus() {
        return suHeadStatus;
    }

    public void setSuHeadStatus(String suHeadStatus) {
        this.suHeadStatus = suHeadStatus;
    }

    public ZonedDateTime getSuHeadCreatedDate() {
        return suHeadCreatedDate;
    }

    public void setSuHeadCreatedDate(ZonedDateTime suHeadCreatedDate) {
        this.suHeadCreatedDate = suHeadCreatedDate;
    }

    public Long getForwardedByRmhOfPm() {
        return forwardedByRmhOfPm;
    }

    public void setForwardedByRmhOfPm(Long forwardedByRmhOfPm) {
        this.forwardedByRmhOfPm = forwardedByRmhOfPm;
    }

    public Long getForwardedToRmhOfPm() {
        return forwardedToRmhOfPm;
    }

    public void setForwardedToRmhOfPm(Long forwardedToRmhOfPm) {
        this.forwardedToRmhOfPm = forwardedToRmhOfPm;
    }

    public String getRmhOfPmRemarks() {
        return RmhOfPmRemarks;
    }

    public void setRmhOfPmRemarks(String rmhOfPmRemarks) {
        RmhOfPmRemarks = rmhOfPmRemarks;
    }

    public String getRmhOfPmStatus() {
        return RmhOfPmStatus;
    }

    public void setRmhOfPmStatus(String rmhOfPmStatus) {
        RmhOfPmStatus = rmhOfPmStatus;
    }

    public ZonedDateTime getRmhOfPmCreatedDate() {
        return RmhOfPmCreatedDate;
    }

    public void setRmhOfPmCreatedDate(ZonedDateTime rmhOfPmCreatedDate) {
        RmhOfPmCreatedDate = rmhOfPmCreatedDate;
    }

    public Long getForwardedByNmhOfPm() {
        return forwardedByNmhOfPm;
    }

    public void setForwardedByNmhOfPm(Long forwardedByNmhOfPm) {
        this.forwardedByNmhOfPm = forwardedByNmhOfPm;
    }

    public Long getForwardedToNmhOfPm() {
        return forwardedToNmhOfPm;
    }

    public void setForwardedToNmhOfPm(Long forwardedToNmhOfPm) {
        this.forwardedToNmhOfPm = forwardedToNmhOfPm;
    }

    public String getNmhOfPmRemarks() {
        return NmhOfPmRemarks;
    }

    public void setNmhOfPmRemarks(String nmhOfPmRemarks) {
        NmhOfPmRemarks = nmhOfPmRemarks;
    }

    public String getNmhOfPmStatus() {
        return NmhOfPmStatus;
    }

    public void setNmhOfPmStatus(String nmhOfPmStatus) {
        NmhOfPmStatus = nmhOfPmStatus;
    }

    public ZonedDateTime getNmhOfPmCreatedDate() {
        return NmhOfPmCreatedDate;
    }

    public void setNmhOfPmCreatedDate(ZonedDateTime nmhOfPmCreatedDate) {
        NmhOfPmCreatedDate = nmhOfPmCreatedDate;
    }

    public Long getForwardedByHod() {
        return forwardedByHod;
    }

    public void setForwardedByHod(Long forwardedByHod) {
        this.forwardedByHod = forwardedByHod;
    }

    public Long getForwardedToHod() {
        return forwardedToHod;
    }

    public void setForwardedToHod(Long forwardedToHod) {
        this.forwardedToHod = forwardedToHod;
    }

    public String getHodRemarks() {
        return hodRemarks;
    }

    public void setHodRemarks(String hodRemarks) {
        this.hodRemarks = hodRemarks;
    }

    public String getHodStatus() {
        return hodStatus;
    }

    public void setHodStatus(String hodStatus) {
        this.hodStatus = hodStatus;
    }

    public ZonedDateTime getHodCreatedDate() {
        return hodCreatedDate;
    }

    public void setHodCreatedDate(ZonedDateTime hodCreatedDate) {
        this.hodCreatedDate = hodCreatedDate;
    }

    public Long getForwardedByDdgOfSm() {
        return forwardedByDdgOfSm;
    }

    public void setForwardedByDdgOfSm(Long forwardedByDdgOfSm) {
        this.forwardedByDdgOfSm = forwardedByDdgOfSm;
    }

    public Long getForwardedToDdgOfSm() {
        return forwardedToDdgOfSm;
    }

    public void setForwardedToDdgOfSm(Long forwardedToDdgOfSm) {
        this.forwardedToDdgOfSm = forwardedToDdgOfSm;
    }

    public String getDdgOfSmRemarks() {
        return DdgOfSmRemarks;
    }

    public void setDdgOfSmRemarks(String ddgOfSmRemarks) {
        DdgOfSmRemarks = ddgOfSmRemarks;
    }

    public String getDdgOfSmStatus() {
        return DdgOfSmStatus;
    }

    public void setDdgOfSmStatus(String ddgOfSmStatus) {
        DdgOfSmStatus = ddgOfSmStatus;
    }

    public ZonedDateTime getDdgOfSmCreatedDate() {
        return DdgOfSmCreatedDate;
    }

    public void setDdgOfSmCreatedDate(ZonedDateTime ddgOfSmCreatedDate) {
        DdgOfSmCreatedDate = ddgOfSmCreatedDate;
    }

    public Long getForwardedByDdgOfStssOrAdss() {
        return forwardedByDdgOfStssOrAdss;
    }

    public void setForwardedByDdgOfStssOrAdss(Long forwardedByDdgOfStssOrAdss) {
        this.forwardedByDdgOfStssOrAdss = forwardedByDdgOfStssOrAdss;
    }

    public String getDdgOfStssOrAdssRemarks() {
        return DdgOfStssOrAdssRemarks;
    }

    public void setDdgOfStssOrAdssRemarks(String ddgOfStssOrAdssRemarks) {
        DdgOfStssOrAdssRemarks = ddgOfStssOrAdssRemarks;
    }

    public String getDdgOfStssOrAdssStatus() {
        return DdgOfStssOrAdssStatus;
    }

    public void setDdgOfStssOrAdssStatus(String ddgOfStssOrAdssStatus) {
        DdgOfStssOrAdssStatus = ddgOfStssOrAdssStatus;
    }

    public ZonedDateTime getDdgOfStssOrAdssCreatedDate() {
        return DdgOfStssOrAdssCreatedDate;
    }

    public void setDdgOfStssOrAdssCreatedDate(ZonedDateTime ddgOfStssOrAdssCreatedDate) {
        DdgOfStssOrAdssCreatedDate = ddgOfStssOrAdssCreatedDate;
    }

    public Long getForwardedToDdgOfStssOrAdss() {
        return forwardedToDdgOfStssOrAdss;
    }

    public void setForwardedToDdgOfStssOrAdss(Long forwardedToDdgOfStssOrAdss) {
        this.forwardedToDdgOfStssOrAdss = forwardedToDdgOfStssOrAdss;
    }

    public Long getForwardedByAdgOfPss() {
        return forwardedByAdgOfPss;
    }

    public void setForwardedByAdgOfPss(Long forwardedByAdgOfPss) {
        this.forwardedByAdgOfPss = forwardedByAdgOfPss;
    }

    public Long getForwardedToAdgOfPss() {
        return forwardedToAdgOfPss;
    }

    public void setForwardedToAdgOfPss(Long forwardedToAdgOfPss) {
        this.forwardedToAdgOfPss = forwardedToAdgOfPss;
    }

    public String getAdgOfPssRemarks() {
        return AdgOfPssRemarks;
    }

    public void setAdgOfPssRemarks(String adgOfPssRemarks) {
        AdgOfPssRemarks = adgOfPssRemarks;
    }

    public String getAdgOfPssStatus() {
        return AdgOfPssStatus;
    }

    public void setAdgOfPssStatus(String adgOfPssStatus) {
        AdgOfPssStatus = adgOfPssStatus;
    }

    public ZonedDateTime getAdgOfPssCreatedDate() {
        return AdgOfPssCreatedDate;
    }

    public void setAdgOfPssCreatedDate(ZonedDateTime adgOfPssCreatedDate) {
        AdgOfPssCreatedDate = adgOfPssCreatedDate;
    }

    public Long getForwardedByAdgOfStssOrAdss() {
        return forwardedByAdgOfStssOrAdss;
    }

    public void setForwardedByAdgOfStssOrAdss(Long forwardedByAdgOfStssOrAdss) {
        this.forwardedByAdgOfStssOrAdss = forwardedByAdgOfStssOrAdss;
    }

    public String getAdgOrStssOfAdssRemarks() {
        return AdgOrStssOfAdssRemarks;
    }

    public void setAdgOrStssOfAdssRemarks(String adgOrStssOfAdssRemarks) {
        AdgOrStssOfAdssRemarks = adgOrStssOfAdssRemarks;
    }

    public String getAdgOrStssOfAdssStatus() {
        return AdgOrStssOfAdssStatus;
    }

    public void setAdgOrStssOfAdssStatus(String adgOrStssOfAdssStatus) {
        AdgOrStssOfAdssStatus = adgOrStssOfAdssStatus;
    }

    public ZonedDateTime getAdgOrStssOfAdssdCreatedDate() {
        return AdgOrStssOfAdssdCreatedDate;
    }

    public void setAdgOrStssOfAdssdCreatedDate(ZonedDateTime adgOrStssOfAdssdCreatedDate) {
        AdgOrStssOfAdssdCreatedDate = adgOrStssOfAdssdCreatedDate;
    }

    public Long getForwardedToAdgOfStssOrAdss() {
        return forwardedToAdgOfStssOrAdss;
    }

    public void setForwardedToAdgOfStssOrAdss(Long forwardedToAdgOfStssOrAdss) {
        this.forwardedToAdgOfStssOrAdss = forwardedToAdgOfStssOrAdss;
    }

    public Long getForwardedByTrainingInstituteHqdh() {
        return forwardedByTrainingInstituteHqdh;
    }

    public void setForwardedByTrainingInstituteHqdh(Long forwardedByTrainingInstituteHqdh) {
        this.forwardedByTrainingInstituteHqdh = forwardedByTrainingInstituteHqdh;
    }

    public String getTrainingInstituteHqdhRemarks() {
        return trainingInstituteHqdhRemarks;
    }

    public void setTrainingInstituteHqdhRemarks(String trainingInstituteHqdhRemarks) {
        this.trainingInstituteHqdhRemarks = trainingInstituteHqdhRemarks;
    }

    public String getTrainingInstituteHqdhStatus() {
        return trainingInstituteHqdhStatus;
    }

    public void setTrainingInstituteHqdhStatus(String trainingInstituteHqdhStatus) {
        this.trainingInstituteHqdhStatus = trainingInstituteHqdhStatus;
    }

    public ZonedDateTime getTrainingInstituteHqdhCreatedDate() {
        return trainingInstituteHqdhCreatedDate;
    }

    public void setTrainingInstituteHqdhCreatedDate(ZonedDateTime trainingInstituteHqdhCreatedDate) {
        this.trainingInstituteHqdhCreatedDate = trainingInstituteHqdhCreatedDate;
    }

    public Long getForwardedToTrainingInstituteHqdh() {
        return forwardedToTrainingInstituteHqdh;
    }

    public void setForwardedToTrainingInstituteHqdh(Long forwardedToTrainingInstituteHqdh) {
        this.forwardedToTrainingInstituteHqdh = forwardedToTrainingInstituteHqdh;
    }

    public Long getForwardedByTrainingInstituteHod() {
        return forwardedByTrainingInstituteHod;
    }

    public void setForwardedByTrainingInstituteHod(Long forwardedByTrainingInstituteHod) {
        this.forwardedByTrainingInstituteHod = forwardedByTrainingInstituteHod;
    }

    public String getTrainingInstituteHodRemarks() {
        return trainingInstituteHodRemarks;
    }

    public void setTrainingInstituteHodRemarks(String trainingInstituteHodRemarks) {
        this.trainingInstituteHodRemarks = trainingInstituteHodRemarks;
    }

    public String getTrainingInstituteHodStatus() {
        return trainingInstituteHodStatus;
    }

    public void setTrainingInstituteHodStatus(String trainingInstituteHodStatus) {
        this.trainingInstituteHodStatus = trainingInstituteHodStatus;
    }

    public ZonedDateTime getTrainingInstituteHodCreatedDate() {
        return trainingInstituteHodCreatedDate;
    }

    public void setTrainingInstituteHodCreatedDate(ZonedDateTime trainingInstituteHodCreatedDate) {
        this.trainingInstituteHodCreatedDate = trainingInstituteHodCreatedDate;
    }

    public Long getForwardedToTrainingInstituteHod() {
        return forwardedToTrainingInstituteHod;
    }

    public void setForwardedToTrainingInstituteHod(Long forwardedToTrainingInstituteHod) {
        this.forwardedToTrainingInstituteHod = forwardedToTrainingInstituteHod;
    }

    public Integer getTotalLevalsOfApproval() {
        return totalLevalsOfApproval;
    }

    public void setTotalLevalsOfApproval(Integer totalLevalsOfApproval) {
        this.totalLevalsOfApproval = totalLevalsOfApproval;
    }

    public String getAutoPushStatus() {
        return AutoPushStatus;
    }

    public void setAutoPushStatus(String autoPushStatus) {
        AutoPushStatus = autoPushStatus;
    }

    public Long getForwardedToFspCreaterId() {
        return forwardedToFspCreaterId;
    }

    public void setForwardedToFspCreaterId(Long forwardedToFspCreaterId) {
        this.forwardedToFspCreaterId = forwardedToFspCreaterId;
    }

    public String getRejectOrReturnFspStatus() {
        return rejectOrReturnFspStatus;
    }

    public void setRejectOrReturnFspStatus(String rejectOrReturnFspStatus) {
        this.rejectOrReturnFspStatus = rejectOrReturnFspStatus;
    }

    public String getRejectOrReturnFspRemarks() {
        return rejectOrReturnFspRemarks;
    }

    public void setRejectOrReturnFspRemarks(String rejectOrReturnFspRemarks) {
        this.rejectOrReturnFspRemarks = rejectOrReturnFspRemarks;
    }

    public ZonedDateTime getRejectOrReturnFspCreatedDate() {
        return rejectOrReturnFspCreatedDate;
    }

    public void setRejectOrReturnFspCreatedDate(ZonedDateTime rejectOrReturnFspCreatedDate) {
        this.rejectOrReturnFspCreatedDate = rejectOrReturnFspCreatedDate;
    }

    public Long getRejectOrReturnFspForwardedbyId() {
        return rejectOrReturnFspForwardedbyId;
    }

    public void setRejectOrReturnFspForwardedbyId(Long rejectOrReturnFspForwardedbyId) {
        this.rejectOrReturnFspForwardedbyId = rejectOrReturnFspForwardedbyId;
    }

    public String getDropFspStatus() {
        return dropFspStatus;
    }

    public void setDropFspStatus(String dropFspStatus) {
        this.dropFspStatus = dropFspStatus;
    }

    public String getDropFspRemarks() {
        return dropFspRemarks;
    }

    public void setDropFspRemarks(String dropFspRemarks) {
        this.dropFspRemarks = dropFspRemarks;
    }

    public ZonedDateTime getDropFspCreatedDate() {
        return dropFspCreatedDate;
    }

    public void setDropFspCreatedDate(ZonedDateTime dropFspCreatedDate) {
        this.dropFspCreatedDate = dropFspCreatedDate;
    }

    public Long getDropFspForwardedById() {
        return dropFspForwardedById;
    }

    public void setDropFspForwardedById(Long dropFspForwardedById) {
        this.dropFspForwardedById = dropFspForwardedById;
    }

    public Map<String, Object> getAccess() {
        return access;
    }

    public void setAccess(Map<String, Object> access) {
        this.access = access;
    }

    
}
