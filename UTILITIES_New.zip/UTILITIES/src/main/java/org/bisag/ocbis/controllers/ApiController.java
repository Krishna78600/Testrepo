package org.bisag.ocbis.controllers;

import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import jakarta.servlet.http.HttpServletRequest;

@RestController
public class ApiController {

  @PostMapping("/verify-ocbis")
  public <body> EncryptedResponse verifyData(HttpServletRequest req) throws Exception {
    return new EncryptedResponse("verified");
  }

}
