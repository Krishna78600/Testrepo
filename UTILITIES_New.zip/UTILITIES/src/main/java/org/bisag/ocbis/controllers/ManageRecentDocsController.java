// package org.bisag.ocbis.controllers;

// import org.bisag.ocbis.models.ManageRecentDocs;
// import org.bisag.ocbis.services.ManageRecentDocsService;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.stereotype.Controller;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RequestParam;
// import org.springframework.web.multipart.MultipartFile;

// @Controller
// @RequestMapping("/file")
// public class ManageRecentDocsController {

//     @Autowired
//     private ManageRecentDocsService managerecentdocservice;

//     @PostMapping("/uploadRecentDocument")
//     public ResponseEntity<ManageRecentDocs> UploadRecentDocument(@RequestParam("file") MultipartFile file , @RequestParam ManageRecentDocs manageDocs) 

//     {
//         String message ;
//         try {
//             ManageRecentDocs response = managerecentdocservice.UploadDoc(manageDocs, file);

//             message = "Uploaded the file successfully: " + file.getOriginalFilename();
//             System.out.println(message);
//             return ResponseEntity.ok(response);
//         } catch (Exception e) {
//             ManageRecentDocs response = managerecentdocservice.UploadDoc(manageDocs, file);
//             message = "Could not upload the file: " + file.getOriginalFilename() + ". Error: " + e.getMessage();
//             System.out.println(message);
//             return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(response);

//         }
//     }
// }

//------------------------------------------------------------------------------------    

// Anil sir code ---------------------------------------------------------------------

//   @Value("${fileServerPath}")
//   String fileServerPath;

//   @GetMapping("/docs/{file}")
//   public void verifyPdf(@PathVariable(value = "file") String file,
//       HttpServletResponse response)
//       throws Exception {
//     try {
//       response.setStatus(200);
//       response.setContentType("application/pdf");
//       IOUtils.copy(FileUtils.openInputStream(
//           new File(fileServerPath + "PeerReview/" + file)),
//           response.getOutputStream());
//     } catch (Exception ex) {
//       System.out.println("ex: " + ex.getMessage());
//       throw new NotFoundException("Pdf not found.");
//     }
//   }

//   @GetMapping("/documents/{file}")
//   public void verifyPdfFile(@PathVariable(value = "file") String file,
//       HttpServletResponse response)
//       throws Exception {
//     try {
//       response.setStatus(200);
//       response.setContentType("application/pdf");
//       IOUtils.copy(FileUtils.openInputStream(
//           new File(fileServerPath + "ExternalPeerReview/" + file)),
//           response.getOutputStream());
//     } catch (Exception ex) { 
//       System.out.println("ex: " + ex.getMessage());
//       throw new NotFoundException("Pdf not found.");
//     }
//   }
//-----------------------------------------------------------------------------

package org.bisag.ocbis.controllers;

import java.io.IOException;
import java.net.http.HttpHeaders;

import org.bisag.obcbis.dto.FormDataDTO;
import org.bisag.ocbis.models.ManageRecentDocs;
import org.bisag.ocbis.services.ManageRecentDocsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController	
@RequestMapping("/file")
public class ManageRecentDocsController {

	@Autowired
	private ManageRecentDocsService managerecentdocservice;

	@PostMapping("/uploadRecentDocument")
	public ResponseEntity<String> uploadRecentDocument(@RequestParam("file") MultipartFile file,
			@ModelAttribute FormDataDTO dto) {

		String message = "";
		ManageRecentDocs manageDocs = new ManageRecentDocs();

		manageDocs.setTitle(dto.getTitle());
		manageDocs.setRegion(dto.getRegion());
		manageDocs.setSecurityGroup(dto.getSecurityGroup());
		manageDocs.setType(dto.getType());
		manageDocs.setDocumentType(dto.getDocumentType());
		manageDocs.setDescription(dto.getDescription());
		manageDocs.setStatus(dto.getStatus());
		manageDocs.setReceivedDate(dto.getReceivedDate());
		
		try {
			manageDocs.setUploadDocument(file.getBytes());
			
			//if file is not null, then only provide service call.
			managerecentdocservice.UploadDoc(manageDocs, file);
			message = "File uploaded successfully: " + file.getOriginalFilename();
			return ResponseEntity.ok(message);
			
		} catch (IOException e) {
			message = "Could not upload the file: " + file.getOriginalFilename() + ". Error: " + e.getMessage();
			System.out.println(message);
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
		}
	}

	
	@GetMapping("test")
	public String test() {
		return "Test is successful. API endpoint is working";
	}

	@GetMapping("download/{id}")
	public ResponseEntity<byte[]> downloadFile(@PathVariable("id") Long id) {

		ManageRecentDocs response = managerecentdocservice.downloadFile(id);

		byte[] documentBody = response.getUploadDocument();

		if (response != null)
			return ResponseEntity.status(HttpStatus.FOUND).body(documentBody);

		return null;

	}
}
