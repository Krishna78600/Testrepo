package org.bisag.ocbis.services;

import java.util.Optional;

import org.bisag.ocbis.models.ManageRecentDocs;
import org.bisag.ocbis.repository.ManageRecentDocsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class ManageRecentDocsService {
    
    @Autowired
    private ManageRecentDocsRepository managerecentdocsrepo ;

    public ManageRecentDocs UploadDoc(ManageRecentDocs manageDocs, MultipartFile file) throws IOException 
    {
        
        ManageRecentDocs manageRecent = new ManageRecentDocs();
        manageRecent.setUploadDocument(file.getBytes());   
        return managerecentdocsrepo.save(manageRecent);
    }

	public ManageRecentDocs downloadFile(Long id) {
		
		Optional<ManageRecentDocs> obj = managerecentdocsrepo.findById(id);
		
		if(obj.isPresent())
			return obj.get();
		else
			return null;
		
	}

}
