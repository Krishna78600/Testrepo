package org.bisag.ocbis.payloads.response;

import org.bisag.ocbis.utils.Json;

public class EncryptedResponse {
  public String message;

  EncryptedResponse() {
    System.out.println("Encrypted Response is called...");
  }

  public EncryptedResponse(Object obj) throws Exception {
    this.message = Json.serialize(obj);
  }

  public String getMessage() {
    return message;
  }

}
