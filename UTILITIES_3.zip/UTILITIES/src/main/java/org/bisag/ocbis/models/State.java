package org.bisag.ocbis.models;


import static jakarta.persistence.GenerationType.IDENTITY;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "state_boundary_21_03_2023",
		uniqueConstraints = {@UniqueConstraint(columnNames = "gid")})
public class State {

	private String minx;
	private String miny;
	private String maxx;
	private String maxy;

	@Id
	@GeneratedValue(strategy = IDENTITY)
	private int gid;

	@Column(name = "stname", nullable = false)
	private String statename;

	@Column(name = "stcode11", unique = true, nullable = false)
	private String statecode;

	public int getGid() {
		return gid;
	}

	public void setGid(int gid) {
		this.gid = gid;
	}

	public String getStatename() {
		return statename;
	}

	public void setStatename(String statename) {
		this.statename = statename;
	}

	public String getStatecode() {
		return statecode;
	}

	public void setStatecode(String statecode) {
		this.statecode = statecode;
	}

	public String getMinx() {
		return minx;
	}

	public void setMinx(String minx) {
		this.minx = minx;
	}

	public String getMiny() {
		return miny;
	}

	public void setMiny(String miny) {
		this.miny = miny;
	}

	public String getMaxx() {
		return maxx;
	}

	public void setMaxx(String maxx) {
		this.maxx = maxx;
	}

	public String getMaxy() {
		return maxy;
	}

	public void setMaxy(String maxy) {
		this.maxy = maxy;
	}


}
