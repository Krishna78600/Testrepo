package org.bisag.ocbis.security.jwt;

public record Jwt(String subject, String fp, long timestamp) {
}
