package org.bisag.ocbis.controllers;

import java.util.List;
import java.util.Map;

import org.bisag.ocbis.models.FspGeoData;
import org.bisag.ocbis.payloads.request.BufferWkt;
import org.bisag.ocbis.payloads.request.BoundaryRequest;
import org.bisag.ocbis.payloads.request.EncryptedRequest;
import org.bisag.ocbis.payloads.request.GeomRequest;
import org.bisag.ocbis.payloads.request.GetId;
import org.bisag.ocbis.payloads.request.SearchGeneral;
import org.bisag.ocbis.payloads.request.Toposheet;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.FSPGeoDataRepository;
import org.locationtech.jts.io.WKTReader;
import org.bisag.ocbis.services.NavigationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@RestController
@CrossOrigin("*")
@RequestMapping("/ocbisgis")
public class GisController {

  @Autowired
  FSPGeoDataRepository geometryRepository;

  @Autowired
  JdbcTemplate jdbcTemplate;

  @Autowired
  NavigationService navService;

  @PostMapping("/save-geom")
  public EncryptedResponse saveGeom(@Valid @RequestBody EncryptedRequest req,
      HttpServletRequest request) throws Exception {
    try {
      GeomRequest body = req.bodyAs(GeomRequest.class);
      String wkt = body.geom();
      Long fspFormId = body.formId();
      String proposalId = body.proposalId();
      String topoSheetNumber = body.topoSheetNumber();

      System.out.println("proposalid" + proposalId);

      // Validate supported geometry types
      if (!(wkt.startsWith("POLYGON((") ||
          wkt.startsWith("LINESTRING(") ||
          wkt.startsWith("POINT("))) {
        throw new IllegalArgumentException("Unsupported geometry type. Must be POLYGON, LINESTRING, or POINT");
      }

      // Validate closing parentheses
      if (wkt.startsWith("POLYGON") && !wkt.endsWith("))")) {
        throw new IllegalArgumentException("Invalid POLYGON format");
      } else if ((wkt.startsWith("LINESTRING") || wkt.startsWith("POINT")) && !wkt.endsWith(")")) {
        throw new IllegalArgumentException("Invalid geometry format");
      }
      FspGeoData fspGeo = new FspGeoData();
      fspGeo.setFsp_form_id(fspFormId);
      fspGeo.setProposal_id(proposalId);
      fspGeo.setTopo_sheet_number(topoSheetNumber);
      fspGeo.setWkt(wkt);
      WKTReader wktReader = new WKTReader();
      org.locationtech.jts.geom.Geometry geom = wktReader.read(wkt);
      fspGeo.setGeom(geom);
      geometryRepository.save(fspGeo);
      return new EncryptedResponse("Saved");
    } catch (Exception e) {
      e.printStackTrace();
      throw new RuntimeException("Failed to save geometry: " + e.getMessage());
    }
  }

  @PostMapping("/get-toposheet-data")
  public <json> EncryptedResponse getToposheetData(@RequestBody EncryptedRequest req)
      throws Exception {
    Toposheet toposheet = req.bodyAs(Toposheet.class);
    String toposheet_num = toposheet.toposheet_num();
    String query = """
          SELECT ST_Xmin(geom) as xmin,ST_Ymin(geom) as ymin,ST_Xmax(geom) xmax,ST_Ymax(geom) ymax,osm_sheet_ as osm,toposheet_num FROM oldsystem_50k_index_gcs where toposheet_num like ?
        """;
    List<Map<String, Object>> topoData = jdbcTemplate.queryForList(query, "%" + toposheet_num + "%");
    return new EncryptedResponse(topoData);
  }

  @PostMapping("/get-buffer-wkt")
  public <json> EncryptedResponse getBufferWkt(@RequestBody EncryptedRequest req)
      throws Exception {
    var bufferwkt = req.bodyAs(BufferWkt.class);
    String wkt = bufferwkt.wkt();
    double range = bufferwkt.range();
    // System.out.println("WKT: " + wkt);
    // System.out.println("Range: " + range);
    String query = """
          SELECT ST_AsText(ST_Buffer(ST_GeomFromText(?)::geography, ?)) as wkt
        """;
    List<Map<String, Object>> buffer = jdbcTemplate.queryForList(query, wkt, range);
    return new EncryptedResponse(buffer);
  }

  @PostMapping("/get-states")
  public <json> EncryptedResponse getAllStates() throws Exception {
    return new EncryptedResponse(navService.getAllStates());
  }

  @PostMapping("/get-districts-by-state-id")
  public <json> EncryptedResponse getDistrictsByStateId(
      @RequestBody EncryptedRequest req)
      throws Exception {
    GetId getid = req.bodyAs(GetId.class);
    String id = getid.id();
    return new EncryptedResponse(navService.getDistrictsByStateId(id));
  }

  @PostMapping("/get-talukas-by-district-id")
  public <json> EncryptedResponse getTalukasByDistrictId(
      @RequestBody EncryptedRequest req)
      throws Exception {
    GetId getid = req.bodyAs(GetId.class);
    String id = getid.id();
    return new EncryptedResponse(navService.getTalukasByDistrictId(id));
  }

  @PostMapping("/get-villages-by-taluka-id")
  public <json> EncryptedResponse getVillagesByTalukaId(
      @RequestBody EncryptedRequest req)
      throws Exception {
    GetId getid = req.bodyAs(GetId.class);
    String id = getid.id();
    return new EncryptedResponse(navService.getVillagesByTalukaId(id));
  }

  @PostMapping("/get-boundary")
  public <json> EncryptedResponse getBoundary(@RequestBody EncryptedRequest req)
      throws Exception {
    BoundaryRequest boundary = req.bodyAs(BoundaryRequest.class);
    return new EncryptedResponse(navService.getBoundary(boundary));
  }

  @PostMapping("/search")
  public <json> EncryptedResponse search(@RequestBody EncryptedRequest req)
      throws Exception {
    SearchGeneral searchgeneral = req.bodyAs(SearchGeneral.class);
    String query = searchgeneral.searchstring();
    return new EncryptedResponse(navService.searchAll(query));
  }

}
