package org.bisag.ocbis.models;

import java.time.ZonedDateTime;
import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="save_recent_docs")
public class ManageRecentDocs {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String title ;
    private String region ;
    private String securityGroup ;
    private String type ;
    private String documentType ;
    private String description ;
    private String status ;
    private ZonedDateTime receivedDate ;
    private String uploadDocument ;
    

    public ManageRecentDocs() {
    }

    public ManageRecentDocs(Long id, String title, String region, String securityGroup, String type, String documentType, String description, String status, ZonedDateTime receivedDate, String uploadDocument) {
        this.id = id;
        this.title = title;
        this.region = region;
        this.securityGroup = securityGroup;
        this.type = type;
        this.documentType = documentType;
        this.description = description;
        this.status = status;
        this.receivedDate = receivedDate;
        this.uploadDocument = uploadDocument;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getRegion() {
        return this.region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getSecurityGroup() {
        return this.securityGroup;
    }

    public void setSecurityGroup(String securityGroup) {
        this.securityGroup = securityGroup;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDocumentType() {
        return this.documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ZonedDateTime getReceivedDate() {
        return this.receivedDate;
    }

    public void setReceivedDate(ZonedDateTime receivedDate) {
        this.receivedDate = receivedDate;
    }

    public String getUploadDocument() {
        return this.uploadDocument;
    }

    public void setUploadDocument(String uploadDocument) {
        this.uploadDocument = uploadDocument;
    }


    //-------------------------------------------------
    
    public ManageRecentDocs id(Long id) {
        setId(id);
        return this;
    }

    public ManageRecentDocs title(String title) {
        setTitle(title);
        return this;
    }

    public ManageRecentDocs region(String region) {
        setRegion(region);
        return this;
    }

    public ManageRecentDocs securityGroup(String securityGroup) {
        setSecurityGroup(securityGroup);
        return this;
    }

    public ManageRecentDocs type(String type) {
        setType(type);
        return this;
    }

    public ManageRecentDocs documentType(String documentType) {
        setDocumentType(documentType);
        return this;
    }

    public ManageRecentDocs description(String description) {
        setDescription(description);
        return this;
    }

    public ManageRecentDocs status(String status) {
        setStatus(status);
        return this;
    }

    public ManageRecentDocs receivedDate(ZonedDateTime receivedDate) {
        setReceivedDate(receivedDate);
        return this;
    }

    public ManageRecentDocs uploadDocument(String uploadDocument) {
        setUploadDocument(uploadDocument);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof ManageRecentDocs)) {
            return false;
        }
        ManageRecentDocs manageRecentDocs = (ManageRecentDocs) o;
        return Objects.equals(id, manageRecentDocs.id) && Objects.equals(title, manageRecentDocs.title) && Objects.equals(region, manageRecentDocs.region) && Objects.equals(securityGroup, manageRecentDocs.securityGroup) && Objects.equals(type, manageRecentDocs.type) && Objects.equals(documentType, manageRecentDocs.documentType) && Objects.equals(description, manageRecentDocs.description) && Objects.equals(status, manageRecentDocs.status) && Objects.equals(receivedDate, manageRecentDocs.receivedDate) && Objects.equals(uploadDocument, manageRecentDocs.uploadDocument);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, title, region, securityGroup, type, documentType, description, status, receivedDate, uploadDocument);
    }

    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", title='" + getTitle() + "'" +
            ", region='" + getRegion() + "'" +
            ", securityGroup='" + getSecurityGroup() + "'" +
            ", type='" + getType() + "'" +
            ", documentType='" + getDocumentType() + "'" +
            ", description='" + getDescription() + "'" +
            ", status='" + getStatus() + "'" +
            ", receivedDate='" + getReceivedDate() + "'" +
            ", uploadDocument='" + getUploadDocument() + "'" +
            "}";
    }
    
    
    
}


