package org.bisag.ocbis.repository;

import java.time.ZonedDateTime;

import org.bisag.ocbis.models.ManageRecentDocs;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ManageRecentDocsRepository extends JpaRepository<ManageRecentDocs, Long> {

    // Optional<ManageRecentDocs> findById(Long id);

    // getting my uploads docs
    @Query( nativeQuery = true , 
            value = """
                    SELECT * FROM save_recent_docs s
                    WHERE (?1  IS NULL OR s.title LIKE CONCAT('%', ?1, '%')) 
                    AND (?2 IS NULL OR s.document_type = ?2) 
                    AND (?3 IS NULL OR s.type = ?3) 
                    AND (?4 IS NULL OR s.received_date >= ?4) 
                    AND (?5 IS NULL OR s.received_date <= ?5)
                    
                   """)
        
     Page<ManageRecentDocs> DocumentsUploadByMe(
            String search ,
            String title,
            String documentType,
            String type,
            ZonedDateTime startDate,
            ZonedDateTime endDate , 
            Pageable pageabel);
        }







    

    
    

