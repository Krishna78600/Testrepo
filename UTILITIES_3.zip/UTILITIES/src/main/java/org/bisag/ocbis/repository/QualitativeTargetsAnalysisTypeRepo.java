package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.QualitativeTargetsAnalysisType;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QualitativeTargetsAnalysisTypeRepo extends JpaRepository<QualitativeTargetsAnalysisType, Long> {
    void deleteByFspFormId(Long fspFormId);
    List<QualitativeTargetsAnalysisType> findByFspFormId(Long fspFormId);

}
