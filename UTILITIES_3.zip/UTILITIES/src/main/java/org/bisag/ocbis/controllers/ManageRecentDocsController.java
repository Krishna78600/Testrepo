package org.bisag.ocbis.controllers;

import java.time.ZonedDateTime;
import java.util.List;

import org.bisag.ocbis.models.ManageRecentDocs;
import org.bisag.ocbis.models.User;
import org.bisag.ocbis.payloads.request.EncryptedRequest;
import org.bisag.ocbis.payloads.request.Report;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.services.ManageRecentDocsService;
import org.bisag.ocbis.utils.Json;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import io.micrometer.common.util.StringUtils;
import jakarta.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/fileupload")
public class ManageRecentDocsController{
    
    @Autowired
    private ManageRecentDocsService managerecentdocservice;

    @PostMapping("/save-recent-docs")
    public ResponseEntity<EncryptedResponse> SaveRecentDocs(@RequestBody EncryptedRequest req , HttpServletRequest request , @AuthenticationPrincipal User user ) throws Exception 
    {

        try {
            EncryptedResponse body = managerecentdocservice.SaveRecentDocs(req.bodyAs(ManageRecentDocs.class));
            
            return ResponseEntity.ok(body);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(new EncryptedResponse("error occured"));
        } 
    }
    
    
    
    // Getting Doc uploaded by me 
    
    @PostMapping("/get-doc-upload-by-me")
        public EncryptedResponse GetDocUploadByMe(@RequestBody EncryptedRequest req)
                        throws Exception {
                var reportReq = Json.deserialize(Report.class, req.getData());
                // var pagination = reportReq.pagination();
                var pageable = PageRequest.of(reportReq.pagination().page(), reportReq.pagination().size());

                var searchQuery = StringUtils.isBlank(reportReq.search()) ? null : "%" + reportReq.search() + "%";

                var custom = reportReq.custom();

                System.out.println("custom: " + custom);

                String title = StringUtils.isNotBlank((String) custom.get("title"))
                                ? (String) custom.get("title")
                                : null;
                String documentType = StringUtils.isNotBlank((String) custom.get("documentType"))
                                ? (String) custom.get("documentType")
                                : null;
                String type = StringUtils.isNotBlank((String) custom.get("type"))
                                ? (String) custom.get("type")
                                : null;
                
                ZonedDateTime receivedDateFrom = StringUtils.isNotBlank((ZonedDateTime) custom.get("receivedDateFrom"))
                ? (ZonedDateTime) custom.get("receivedDateFrom")
                : null;
               
                
                var result = managerecentdocservice.findByFilters(searchQuery,title, documentType , type,receivedDateFrom ,pageable);
                return new EncryptedResponse(result);
        }
   
   
    
    
    
    
    
}


    
  








