package org.bisag.ocbis.models;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Borehole_Information")
public class BoreholeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "prospectname", length = 50)
    private String prospectName;
    private Date dateStarting;
    private String blockName;
    private Date dateClosing;
    private String inputCenterCode;
    private String boreholeName;
    private String commodity;
    private String region;
    private String state;
    private String district;
    private int departure;
    private int departureLatitude;
    private int rlCollar;
    private int clInclination;
    private int bearing;
    private int length;
    private int rlBottom;
    private int seriesNumber;
    private int latitudedd;
    private int longitudedd;
    private int latitudedms;
    private int longitudedms;
    private String sourceOfData;
    private String stageOfInvestigation;
    private int waterLevel;
    private Date dateOfWaterLevel;
    private String geologistName;
    private int depth;
    private int azimuth;
    private int inclination;
    private int fromDepth;
    private int toDepth;
    private int receivedLength;
    private int receivedPercentage;
    private String coreSize;
    private String rockName;
    private String otherRockName;
    private String description;
    private String remarks;
    private String sampleId;
    private int measuredLength;
    // private int fromDepth;
    // private int toDepth;
    private String hostRockType;
    private String sampleType;
    private int weight;
    private int samples;
    private int trueWidth;
    private String orezoneName;
    private String comments;
    private String elementCode;
    private int meanValue;
    private int meanValueUnit;
    private int strikeInfluence;
    private int dipInfluence;
    // private int trueWidth;
    // private String elementCode;
    private int meanGradeUnit;
    private int tonnageFactor;
    private String tonnageUnit;
    private int resource;
    private String resourceUnit;
    private String estimationMethod;
    private String typeOfSource;

    public String getBoreholeName() {
        return boreholeName;
    }

    public void setBoreholeName(String boreholeName) {
        this.boreholeName = boreholeName;
    }

    public String getTypeOfSource() {
        return typeOfSource;
    }

    public void setTypeOfSource(String typeOfSource) {
        this.typeOfSource = typeOfSource;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProspectName() {
        return prospectName;
    }

    public void setProspectName(String prospectName) {
        this.prospectName = prospectName;
    }

    public Date getDateStarting() {
        return dateStarting;
    }

    public void setDateStarting(Date dateStarting) {
        this.dateStarting = dateStarting;
    }

    public String getBlockName() {
        return blockName;
    }

    public void setBlockName(String blockName) {
        this.blockName = blockName;
    }

    public Date getDateClosing() {
        return dateClosing;
    }

    public void setDateClosing(Date dateClosing) {
        this.dateClosing = dateClosing;
    }

    public String getInputCenterCode() {
        return inputCenterCode;
    }

    public void setInputCenterCode(String inputCenterCode) {
        this.inputCenterCode = inputCenterCode;
    }

    public String getCommodity() {
        return commodity;
    }

    public void setCommodity(String commodity) {
        this.commodity = commodity;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public int getDeparture() {
        return departure;
    }

    public void setDeparture(int departure) {
        this.departure = departure;
    }

    public int getDepartureLatitude() {
        return departureLatitude;
    }

    public void setDepartureLatitude(int departureLatitude) {
        this.departureLatitude = departureLatitude;
    }

    public int getRlCollar() {
        return rlCollar;
    }

    public void setRlCollar(int rlCollar) {
        this.rlCollar = rlCollar;
    }

    public int getClInclination() {
        return clInclination;
    }

    public void setClInclination(int clInclination) {
        this.clInclination = clInclination;
    }

    public int getBearing() {
        return bearing;
    }

    public void setBearing(int bearing) {
        this.bearing = bearing;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public int getRlBottom() {
        return rlBottom;
    }

    public void setRlBottom(int rlBottom) {
        this.rlBottom = rlBottom;
    }

    public int getSeriesNumber() {
        return seriesNumber;
    }

    public void setSeriesNumber(int seriesNumber) {
        this.seriesNumber = seriesNumber;
    }

    public int getLatitudedd() {
        return latitudedd;
    }

    public void setLatitudedd(int latitudedd) {
        this.latitudedd = latitudedd;
    }

    public int getLongitudedd() {
        return longitudedd;
    }

    public void setLongitudedd(int longitudedd) {
        this.longitudedd = longitudedd;
    }

    public int getLatitudedms() {
        return latitudedms;
    }

    public void setLatitudedms(int latitudedms) {
        this.latitudedms = latitudedms;
    }

    public String getSourceOfData() {
        return sourceOfData;
    }

    public void setSourceOfData(String sourceOfData) {
        this.sourceOfData = sourceOfData;
    }

    public String getStageOfInvestigation() {
        return stageOfInvestigation;
    }

    public void setStageOfInvestigation(String stageOfInvestigation) {
        this.stageOfInvestigation = stageOfInvestigation;
    }

    public int getWaterLevel() {
        return waterLevel;
    }

    public void setWaterLevel(int waterLevel) {
        this.waterLevel = waterLevel;
    }

    public Date getDateOfWaterLevel() {
        return dateOfWaterLevel;
    }

    public void setDateOfWaterLevel(Date dateOfWaterLevel) {
        this.dateOfWaterLevel = dateOfWaterLevel;
    }

    public String getGeologistName() {
        return geologistName;
    }

    public void setGeologistName(String geologistName) {
        this.geologistName = geologistName;
    }

    public int getDepth() {
        return depth;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }

    public int getAzimuth() {
        return azimuth;
    }

    public void setAzimuth(int azimuth) {
        this.azimuth = azimuth;
    }

    public int getInclination() {
        return inclination;
    }

    public void setInclination(int inclination) {
        this.inclination = inclination;
    }

    public int getFromDepth() {
        return fromDepth;
    }

    public void setFromDepth(int fromDepth) {
        this.fromDepth = fromDepth;
    }

    public int getToDepth() {
        return toDepth;
    }

    public void setToDepth(int toDepth) {
        this.toDepth = toDepth;
    }

    public int getReceivedLength() {
        return receivedLength;
    }

    public void setReceivedLength(int receivedLength) {
        this.receivedLength = receivedLength;
    }

    public int getReceivedPercentage() {
        return receivedPercentage;
    }

    public void setReceivedPercentage(int receivedPercentage) {
        this.receivedPercentage = receivedPercentage;
    }

    public String getCoreSize() {
        return coreSize;
    }

    public void setCoreSize(String coreSize) {
        this.coreSize = coreSize;
    }

    public String getRockName() {
        return rockName;
    }

    public void setRockName(String rockName) {
        this.rockName = rockName;
    }

    public String getOtherRockName() {
        return otherRockName;
    }

    public void setOtherRockName(String otherRockName) {
        this.otherRockName = otherRockName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getSampleId() {
        return sampleId;
    }

    public void setSampleId(String sampleId) {
        this.sampleId = sampleId;
    }

    public int getMeasuredLength() {
        return measuredLength;
    }

    public void setMeasuredLength(int measuredLength) {
        this.measuredLength = measuredLength;
    }

    public String getHostRockType() {
        return hostRockType;
    }

    public void setHostRockType(String hostRockType) {
        this.hostRockType = hostRockType;
    }

    public String getSampleType() {
        return sampleType;
    }

    public void setSampleType(String sampleType) {
        this.sampleType = sampleType;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getSamples() {
        return samples;
    }

    public void setSamples(int samples) {
        this.samples = samples;
    }

    public int getTrueWidth() {
        return trueWidth;
    }

    public void setTrueWidth(int trueWidth) {
        this.trueWidth = trueWidth;
    }

    public String getOrezoneName() {
        return orezoneName;
    }

    public void setOrezoneName(String orezoneName) {
        this.orezoneName = orezoneName;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getElementCode() {
        return elementCode;
    }

    public void setElementCode(String elementCode) {
        this.elementCode = elementCode;
    }

    public int getMeanValue() {
        return meanValue;
    }

    public void setMeanValue(int meanValue) {
        this.meanValue = meanValue;
    }

    public int getMeanValueUnit() {
        return meanValueUnit;
    }

    public void setMeanValueUnit(int meanValueUnit) {
        this.meanValueUnit = meanValueUnit;
    }

    public int getStrikeInfluence() {
        return strikeInfluence;
    }

    public void setStrikeInfluence(int strikeInfluence) {
        this.strikeInfluence = strikeInfluence;
    }

    public int getDipInfluence() {
        return dipInfluence;
    }

    public void setDipInfluence(int dipInfluence) {
        this.dipInfluence = dipInfluence;
    }

    public int getMeanGradeUnit() {
        return meanGradeUnit;
    }

    public void setMeanGradeUnit(int meanGradeUnit) {
        this.meanGradeUnit = meanGradeUnit;
    }

    public int getTonnageFactor() {
        return tonnageFactor;
    }

    public void setTonnageFactor(int tonnageFactor) {
        this.tonnageFactor = tonnageFactor;
    }

    public String getTonnageUnit() {
        return tonnageUnit;
    }

    public void setTonnageUnit(String tonnageUnit) {
        this.tonnageUnit = tonnageUnit;
    }

    public int getResource() {
        return resource;
    }

    public void setResource(int resource) {
        this.resource = resource;
    }

    public String getResourceUnit() {
        return resourceUnit;
    }

    public void setResourceUnit(String resourceUnit) {
        this.resourceUnit = resourceUnit;
    }

    public String getEstimationMethod() {
        return estimationMethod;
    }

    public void setEstimationMethod(String estimationMethod) {
        this.estimationMethod = estimationMethod;
    }

    public int getLongitudedms() {
        return longitudedms;
    }

    public void setLongitudedms(int longitudedms) {
        this.longitudedms = longitudedms;
    }

}
