package org.bisag.ocbis.repository;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;

import org.bisag.ocbis.models.CreateFsp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface FspRepo extends JpaRepository<CreateFsp, Long> {

        @Query(nativeQuery = true, value = """
                        SELECT * FROM save_created_fsp WHERE id = ?1
                        """)
        CreateFsp findByFormId(long id);

        @Query(nativeQuery = true, value = """
                          SELECT  scf.*,fald.*
                             FROM
                                 save_created_fsp scf
                              LEFT JOIN fsp_approve_levels_details fald ON fald.fsp_form_id = scf.id
                              LEFT JOIN ocbis_users ou on ou.id = scf.user_id
                              WHERE scf.steps_completed = 9
                               AND (?1 IS NULL OR (fald.forwarded_to_suhead = ?1
                                OR fald.forwarded_to_rmh_of_pm = ?1
                                OR fald.forwarded_to_hod = ?1
                                OR fald.forwarded_to_ddg_of_sm = ?1
                                OR fald.forwarded_to_adg_of_pss = ?1
                                OR fald.forwarded_to_rhod = ?1
                                OR fald.forwarded_to_training_institute_hod = ?1
                                OR fald.forwarded_to_training_institute_hqdh = ?1
                                OR fald.forwarded_by_fsp_creater = ?1))
                            AND (?2 IS NULL OR fald.adg_of_pss_status = ?2)
                            AND (?3 IS NULL OR fald.drop_fsp_status = ?3)
                            AND (?4 IS NULL OR scf.mission_name = ?4)
                            AND (?5 IS NULL OR fald.su_head_status = ?5
                                    OR fald.rmh_of_pm_status = ?5
                                    OR fald.hod_status = ?5
                                    OR fald.ddg_of_sm_status = ?5
                                    OR fald.adg_of_pss_status = ?5
                                    OR fald.auto_push_status = ?5
                                    OR fald.reject_fsp_status = ?5
                                    OR fald.return_fsp_status = ?5
                                )
                        """)
        Page<Map<String, Object>> getMonitoringFsp(Long id, String approvedFspStatus, String dropFspStatus,
                        String missionVstatus, String rejectOrReturnstatus, Pageable pageable);

        @Query(nativeQuery = true, value = """
                          SELECT  scf.*,fald.*
                             FROM
                                 save_created_fsp scf
                              LEFT JOIN fsp_approve_levels_details_log fald ON fald.fsp_form_id = scf.id
                              LEFT JOIN ocbis_users ou on ou.id = scf.user_id
                              WHERE scf.steps_completed = 9
                               AND (?1 IS NULL OR (fald.forwarded_to_suhead = ?1
                                    OR fald.forwarded_to_rmh_of_pm = ?1
                                    OR fald.forwarded_to_hod = ?1
                                    OR fald.forwarded_to_ddg_of_sm = ?1
                                    OR fald.forwarded_to_adg_of_pss = ?1
                                    OR fald.forwarded_to_rhod = ?1
                                    OR fald.forwarded_to_training_institute_hod = ?1
                                    OR fald.forwarded_to_training_institute_hqdh = ?1
                                    OR fald.forwarded_to_fsp_creater_id = ?1))
                                AND (?2 IS NULL OR fald.su_head_status = ?2
                                    OR fald.rmh_of_pm_status = ?2
                                    OR fald.hod_status = ?2
                                    OR fald.ddg_of_sm_status = ?2
                                    OR fald.adg_of_pss_status = ?2
                                    OR fald.auto_push_status = ?2
                                    OR fald.rhod_status = ?2
                                    OR fald.training_institute_hqdh_status = ?2
                                    OR fald.training_institute_hod_status = ?2
                                    OR fald.return_fsp_status = ?2)
                        order by fald.fsp_form_id
                        """)
        Page<Map<String, Object>> trackingFspForReturn(Long id, String approvedFspStatus, Pageable pageable);

        @Query(nativeQuery = true, value = """
                        SELECT
                               scf.*,fald.*,

                                   CASE
                                   WHEN ?7 IS NULL THEN NULL
                                   WHEN fald.reject_forwarded_by_id = ?5 THEN reject_fsp_status
                                   WHEN fald.forwarded_by_suhead = ?5 THEN su_head_status
                                   WHEN fald.forwarded_by_rmh_of_pm = ?5 THEN rmh_of_pm_status
                                   WHEN fald.forwarded_by_hod = ?5 THEN hod_status
                                   WHEN fald.forwarded_by_ddg_of_sm = ?5 THEN ddg_of_sm_status
                                   WHEN fald.forwarded_by_adg_of_pss = ?5 THEN adg_of_pss_status
                                   WHEN fald.forwarded_by_rhod = ?5 THEN rhod_status
                                   WHEN fald.forwarded_by_training_institute_hqdh = ?5 THEN training_institute_hqdh_status
                                   WHEN fald.forwarded_by_training_institute_hod = ?5 THEN training_institute_hod_status
                                   ELSE NULL
                                   END AS satisfied_status,
                                  
    // @GetMapping("/docs-upload-by-me")
    // public List<ManageRecentDocs> DocsUploadByMe(@RequestParam ) { CASE
                                   WHEN fald.forwarded_to_suhead = ?5 THEN fald.su_head_remarks
                                   WHEN fald.forwarded_to_rmh_of_pm = ?5 THEN fald.rmh_of_pm_remarks
                                   WHEN fald.forwarded_to_hod = ?5 THEN fald.hod_remarks
                                   WHEN fald.forwarded_to_ddg_of_sm = ?5 THEN fald.ddg_of_sm_remarks
                                   WHEN fald.forwarded_to_adg_of_pss = ?5 THEN fald.adg_of_pss_remarks
                                   WHEN fald.forwarded_to_rhod = ?5 THEN rhod_remarks
                                   WHEN fald.forwarded_to_training_institute_hqdh = ?5 THEN training_institute_hqdh_remarks
                                   WHEN fald.forwarded_to_training_institute_hod = ?5 THEN training_institute_hod_remarks

                                   ELSE NULL
                                   END AS satisfied_remarks,
                                   CASE
                                   WHEN fald.forwarded_to_suhead = ?5 THEN fald.su_head_created_date
                                   WHEN fald.forwarded_to_rmh_of_pm = ?5 THEN fald.rmh_of_pm_created_date
                                   WHEN fald.forwarded_to_hod = ?5 THEN fald.hod_created_date
                                   WHEN fald.forwarded_to_ddg_of_sm = ?5 THEN fald.ddg_of_sm_created_date
                                   WHEN fald.forwarded_to_adg_of_pss = ?5 THEN fald.adg_of_pss_created_date
                                   WHEN fald.forwarded_to_rhod = ?5 THEN rhod_created_date
                                   WHEN fald.forwarded_to_training_institute_hqdh = ?5 THEN training_institute_hqdh_created_date
                                   WHEN fald.forwarded_to_training_institute_hod = ?5 THEN training_institute_hod_created_date

                                   ELSE NULL
                                   END AS satisfied_created_date,
                                   CASE
                                   WHEN fald.forwarded_to_suhead = ?5 THEN fald.forwarded_by_suhead
                                   WHEN fald.forwarded_to_rmh_of_pm = ?5 THEN fald.forwarded_by_rmh_of_pm
                                   WHEN fald.forwarded_to_hod = ?5 THEN fald.forwarded_by_hod
                                   WHEN fald.forwarded_to_ddg_of_sm = ?5 THEN fald.forwarded_by_ddg_of_sm
                                   WHEN fald.forwarded_to_adg_of_pss = ?5 THEN fald.forwarded_by_adg_of_pss
                                   WHEN fald.forwarded_to_rhod = ?5 THEN forwarded_by_rhod
                                   WHEN fald.forwarded_to_training_institute_hqdh = ?5 THEN forwarded_by_training_institute_hqdh
                                   WHEN fald.forwarded_to_training_institute_hod = ?5 THEN forwarded_by_training_institute_hod

                                   ELSE NULL
                                   END AS satisfied_forwardedby_username

                           FROM save_created_fsp scf
                           LEFT JOIN ocbis_users ou ON ou.id = scf.user_id
                           LEFT JOIN fsp_approve_levels_details fald ON fald.fsp_form_id = scf.id
                           WHERE (?1 IS NULL OR scf.region_name=?1)
                           AND (?2 IS NULL OR scf.field_season_year=?2)
                           AND (?3 IS NULL OR scf.proposal_id=?3)
                           AND (?4 IS NULL OR scf.id=?4)
                           AND (?5 IS NULL OR (fald.forwarded_to_suhead = ?5
                                OR fald.forwarded_to_rmh_of_pm = ?5
                                OR fald.forwarded_to_hod = ?5
                                OR fald.forwarded_to_ddg_of_sm = ?5
                                OR fald.forwarded_to_adg_of_pss = ?5
                                OR fald.forwarded_to_rhod = ?5
                                OR fald.forwarded_to_training_institute_hqdh = ?5
                                OR fald.forwarded_to_training_institute_hod = ?5
                                OR fald.forwarded_by_fsp_creater = ?5)
                            )
                           AND (?6 IS NULL OR ou.state_id = ?6)
                           AND (?7 IS NULL OR fald.su_head_status = ?7
                                OR fald.rmh_of_pm_status = ?7
                                OR fald.hod_status = ?7
                                OR fald.ddg_of_sm_status = ?7
                                OR fald.adg_of_pss_status = ?7
                                OR fald.auto_push_status = ?7
                                OR fald.rhod_status = ?7
                                OR fald.training_institute_hqdh_status = ?7
                                OR fald.training_institute_hod_status = ?7
                                )
                           AND  scf.steps_completed = '9'

                           GROUP BY scf.id,fald.id
                           """)
        Page<Map<String, Object>> getFspDetails(String regionName,
                        String fieldSeasonYear,
                        String proposalId,
                        Long id, Long userId, String stateId, String status, Pageable pagaeable);

        @Query(nativeQuery = true, value = """
                          SELECT
                                 scf.*,ou.username
                             FROM
                                 save_created_fsp scf
                             LEFT JOIN fsp_commodity fc ON fc.fsp_form_id = scf.id
                             LEFT JOIN fsp_qualitative_targets_analysis_type fqtat ON fqtat.fsp_form_id = scf.id
                             LEFT JOIN fsp_qualitative_targets_task fqtt ON fqtt.fsp_form_id = scf.id
                             LEFT JOIN fsp_qualitative_targets_subtask fqts ON fqts.fsp_form_id = scf.id
                             LEFT JOIN fsp_sample_quant_service fsqs ON fsqs.fsp_form_id = scf.id
                             LEFT JOIN fsp_lithology_zone flz ON flz.fsp_form_id = scf.id
                             LEFT JOIN fsp_vehicle_details fvd ON fvd.fsp_form_id = scf.id
                             LEFT JOIN fsp_operational_expense foe ON foe.fsp_form_id = scf.id
                             LEFT JOIN fsp_consumable_item fci ON fci.fsp_form_id = scf.id
                             LEFT JOIN fsp_non_consumable_item fnci ON fnci.fsp_form_id = scf.id
                             join ocbis_users ou on ou.id = scf.user_id
                             where scf.steps_completed < 9 and scf.user_id = ?1
                        """)
        Page<Map<String, Object>> getDraftFsp(Long id, Pageable pageable);

        @Query(nativeQuery = true, value = """
                                    SELECT
                            scf.*,
                            string_agg(DISTINCT fcm.commodity_name, ', ') AS commodity_names,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fc.id,
                                'fsp_form_id', fc.fsp_form_id,
                                'fsp_commodity_name', fc.fsp_commodity_name,
                                'commodity_name', fcm.commodity_name,
                                'fsp_sub_commodity_name', fc.fsp_sub_commodity_name,
                                'fsp_mineral_type', fc.fsp_mineral_type
                            )) FILTER (WHERE fc.id IS NOT NULL), '[]'\\:\\:json) AS commodities,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fqtat.id,
                                'fsp_form_id', fqtat.fsp_form_id,
                                'analysis_type', fqtat.analysis_type
                            )) FILTER (WHERE fqtat.id IS NOT NULL), '[]'\\:\\:json) AS analysis_types,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fqtt.id,
                                'fsp_form_id', fqtt.fsp_form_id,
                                'task', fqtt.task
                            )) FILTER (WHERE fqtt.id IS NOT NULL), '[]'\\:\\:json) AS tasks,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fqts.id,
                                'fsp_form_id', fqts.fsp_form_id,
                                'lab_name', fqts.lab_name,
                                'sub_task', fqts.sub_task,
                                'target', fqts.target,
                                'timeline_from', fqts.timeline_from,
                                'timeline_to', fqts.timeline_to,
                                'workload', fqts.workload
                            )) FILTER (WHERE fqts.id IS NOT NULL), '[]'\\:\\:json) AS subtasks,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fsqs.id,
                                'fsp_form_id', fsqs.fsp_form_id,
                                'sample_quant_and_service_activity_name', fsqs.sample_quant_and_service_activity_name,
                                'sample_quant_and_service_activity_type', fsqs.sample_quant_and_service_activity_type,
                                'sample_quant_and_service_elements', fsqs.sample_quant_and_service_elements,
                                'sample_quant_and_service_sample_target', fsqs.sample_quant_and_service_sample_target,
                                'sample_quant_and_service_total_workload', fsqs.sample_quant_and_service_total_workload,
                                'sample_quant_and_service_work_completed', fsqs.sample_quant_and_service_work_completed
                            )) FILTER (WHERE fsqs.id IS NOT NULL), '[]'\\:\\:json) AS sample_quant,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', flz.id,
                                'fsp_form_id', flz.fsp_form_id,
                                'depth', flz.depth,
                                'other_rock_characteristics', flz.other_rock_characteristics,
                                'other_rock_types', flz.other_rock_types,
                                'rock_characteristics', flz.rock_characteristics,
                                'rock_types', flz.rock_types
                            )) FILTER (WHERE flz.id IS NOT NULL), '[]'\\:\\:json) AS lithology_zones,
                            COALESCE(json_agg(DISTINCT fvd.*) FILTER (WHERE fvd.id IS NOT NULL), '[]'\\:\\:json) AS vehicle_details,
                            COALESCE(json_agg(DISTINCT foe.*) FILTER (WHERE foe.id IS NOT NULL), '[]'\\:\\:json) AS operational_expenses,
                            COALESCE(json_agg(DISTINCT fci.*) FILTER (WHERE fci.id IS NOT NULL), '[]'\\:\\:json) AS consumable_items,
                            COALESCE(json_agg(DISTINCT fnci.*) FILTER (WHERE fnci.id IS NOT NULL), '[]'\\:\\:json) AS non_consumable_items
                        FROM
                            save_created_fsp scf
                            LEFT JOIN fsp_commodity fc ON fc.fsp_form_id = scf.id
                            LEFT JOIN fsp_commodity_master fcm ON fcm.commodity_id = fc.fsp_commodity_name\\:\\:int
                            LEFT JOIN fsp_qualitative_targets_analysis_type fqtat ON fqtat.fsp_form_id = scf.id
                            LEFT JOIN fsp_qualitative_targets_task fqtt ON fqtt.fsp_form_id = scf.id
                            LEFT JOIN fsp_qualitative_targets_subtask fqts ON fqts.fsp_form_id = scf.id
                            LEFT JOIN fsp_sample_quant_service fsqs ON fsqs.fsp_form_id = scf.id
                            LEFT JOIN fsp_lithology_zone flz ON flz.fsp_form_id = scf.id
                            LEFT JOIN fsp_vehicle_details fvd ON fvd.fsp_form_id = scf.id
                            LEFT JOIN fsp_operational_expense foe ON foe.fsp_form_id = scf.id
                            LEFT JOIN fsp_consumable_item fci ON fci.fsp_form_id = scf.id
                            LEFT JOIN fsp_non_consumable_item fnci ON fnci.fsp_form_id = scf.id
                                       WHERE (?1 IS NULL OR scf.id=?1) AND scf.steps_completed = '9'
                                       GROUP BY scf.id
                                       """)
        List<Map<String, Object>> getFspDetailsForView(Long id);

        @Query(nativeQuery = true, value = """
                                SELECT
                            scf.*,
                            string_agg(DISTINCT fcm.commodity_name, ', ') AS commodity_names,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fc.id,
                                'fsp_form_id', fc.fsp_form_id,
                                'fsp_commodity_name', fc.fsp_commodity_name,
                                'commodity_name', fcm.commodity_name,
                                'fsp_sub_commodity_name', fc.fsp_sub_commodity_name,
                                'fsp_mineral_type', fc.fsp_mineral_type
                            )) FILTER (WHERE fc.id IS NOT NULL), '[]'\\:\\:json) AS commodities,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fqtat.id,
                                'fsp_form_id', fqtat.fsp_form_id,
                                'analysis_type', fqtat.analysis_type
                            )) FILTER (WHERE fqtat.id IS NOT NULL), '[]'\\:\\:json) AS analysis_types,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fqtt.id,
                                'task_id', fqts.task_id,
                                'fsp_form_id', fqtt.fsp_form_id,
                                'task', fqtt.task
                            )) FILTER (WHERE fqtt.id IS NOT NULL), '[]'\\:\\:json) AS tasks,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fqts.id,
                                'task_id', fqts.task_id,
                                'fsp_form_id', fqts.fsp_form_id,
                                'lab_name', fqts.lab_name,
                                'sub_task', fqts.sub_task,
                                'target', fqts.target,
                                'timeline_from', fqts.timeline_from,
                                'timeline_to', fqts.timeline_to,
                                'workload', fqts.workload
                            )) FILTER (WHERE fqts.id IS NOT NULL), '[]'\\:\\:json) AS subtasks,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', fsqs.id,
                                'fsp_form_id', fsqs.fsp_form_id,
                                'sample_quant_and_service_activity_name', fsqs.sample_quant_and_service_activity_name,
                                'sample_quant_and_service_activity_type', fsqs.sample_quant_and_service_activity_type,
                                'sample_quant_and_service_elements', fsqs.sample_quant_and_service_elements,
                                'sample_quant_and_service_sample_target', fsqs.sample_quant_and_service_sample_target,
                                'sample_quant_and_service_total_workload', fsqs.sample_quant_and_service_total_workload,
                                'sample_quant_and_service_work_completed', fsqs.sample_quant_and_service_work_completed
                            )) FILTER (WHERE fsqs.id IS NOT NULL), '[]'\\:\\:json) AS sample_quant,
                            COALESCE(json_agg(DISTINCT jsonb_build_object(
                                'id', flz.id,
                                'fsp_form_id', flz.fsp_form_id,
                                'depth', flz.depth,
                                'other_rock_characteristics', flz.other_rock_characteristics,
                                'other_rock_types', flz.other_rock_types,
                                'rock_characteristics', flz.rock_characteristics,
                                'rock_types', flz.rock_types
                            )) FILTER (WHERE flz.id IS NOT NULL), '[]'\\:\\:json) AS lithology_zones,
                            COALESCE(json_agg(DISTINCT fvd.*) FILTER (WHERE fvd.id IS NOT NULL), '[]'\\:\\:json) AS vehicle_details,
                            COALESCE(json_agg(DISTINCT foe.*) FILTER (WHERE foe.id IS NOT NULL), '[]'\\:\\:json) AS operational_expenses,
                            COALESCE(json_agg(DISTINCT fci.*) FILTER (WHERE fci.id IS NOT NULL), '[]'\\:\\:json) AS consumable_items,
                            COALESCE(json_agg(DISTINCT fnci.*) FILTER (WHERE fnci.id IS NOT NULL), '[]'\\:\\:json) AS non_consumable_items
                        FROM
                            save_created_fsp scf
                            LEFT JOIN fsp_commodity fc ON fc.fsp_form_id = scf.id
                            LEFT JOIN fsp_commodity_master fcm ON fcm.commodity_id = fc.fsp_commodity_name\\:\\:int
                            LEFT JOIN fsp_qualitative_targets_analysis_type fqtat ON fqtat.fsp_form_id = scf.id
                            LEFT JOIN fsp_qualitative_targets_task fqtt ON fqtt.fsp_form_id = scf.id
                            LEFT JOIN fsp_qualitative_targets_subtask fqts ON fqts.fsp_form_id = scf.id
                            LEFT JOIN fsp_sample_quant_service fsqs ON fsqs.fsp_form_id = scf.id
                            LEFT JOIN fsp_lithology_zone flz ON flz.fsp_form_id = scf.id
                            LEFT JOIN fsp_vehicle_details fvd ON fvd.fsp_form_id = scf.id
                            LEFT JOIN fsp_operational_expense foe ON foe.fsp_form_id = scf.id
                            LEFT JOIN fsp_consumable_item fci ON fci.fsp_form_id = scf.id
                            LEFT JOIN fsp_non_consumable_item fnci ON fnci.fsp_form_id = scf.id
                                   WHERE scf.id = ?1
                                   GROUP BY scf.id
                                   """)
        List<Map<String, Object>> getAlreadyFilledDetailsFormWise(Long id);

        @Query(nativeQuery = true, value = """
                         SELECT fald.su_head_remarks,fald.rmh_of_pm_remarks,fald.hod_remarks,fald.ddg_of_sm_remarks,
                         fald.adg_of_pss_remarks,fpr.rmh_remarks,fpr.nmh_remarks,fpr.nmh_status,fpr.rmh_status, scf.*, fald.*,
                         fpr.applied_for_peer_review_to_nmh,fpr.applied_for_peer_review_to_rmh,fpr.status AS peer_status, fpr.remarks AS peer_remarks,fpr.pss_status,fpr.pss_external_peer_status,fpr.pss_external_peer_status,fpr.id As pss_id_for_external_peer_review
                                FROM fsp_peer_review fpr
                                left JOIN fsp_approve_levels_details fald ON fpr.proposal_id = fald.proposal_id
                                join ocbis_users ou on ou.id = fpr.applied_for_peer_review_by_pss
                                left join save_created_fsp scf on scf.proposal_id = fald.proposal_id
                                WHERE ou.state_id = ?1

                        """)
        Page<Map<String, Object>> getFspForPeerReview(String stateId, Pageable pageable);

        @Query(nativeQuery = true, value = """
                               SELECT * FROM public.fsp_peer_review
                        ORDER BY id ASC

                               """)
        Page<Map<String, Object>> getFspForPeerReviewRmhNmh(Pageable pageable);

        @Query(nativeQuery = true, value = """
                         SELECT scf.id AS scf_id,fald.su_head_remarks,fald.rmh_of_pm_remarks,fald.hod_remarks,fald.ddg_of_sm_remarks,fpr.*,
                             fald.adg_of_pss_remarks,fpr.rmh_remarks,fpr.nmh_remarks,fpr.nmh_status,fpr.rmh_status, scf.*, fald.*,
                             fpr.applied_for_peer_review_to_nmh,fpr.applied_for_peer_review_to_rmh,fpr.status AS peer_status, fpr.remarks AS peer_remarks,fpr.pss_status,fpr.pss_external_peer_status,fpr.remarks AS pss_internal_review_start_remarks,
                             fpr.id AS peer_id
                        FROM fsp_peer_review fpr
                        left JOIN fsp_approve_levels_details fald ON fpr.proposal_id = fald.proposal_id
                        join ocbis_users ou on ou.id = fpr.applied_for_peer_review_by_pss
                        left join save_created_fsp scf on scf.proposal_id = fald.proposal_id
                        WHERE ou.state_id = ?1

                          """)
        Page<Map<String, Object>> getFspForPeerReviewRmhNmh(String stateId, Pageable pageable);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details SET drop_fsp_status = 'Drop', drop_fsp_remarks = ?2, drop_fsp_created_date = ?3,drop_fsp_forwarded_by_id=?4 WHERE id=?1
                        """)
        void dropFspDetails(Long id, String remarks, ZonedDateTime createddate, Long userid);

        @Modifying
        @Query(nativeQuery = true, value = """
                        DELETE FROM save_created_fsp WHERE id=?1
                        """)
        void deleteFspDetails(Long id);

        @Query(value = """
                        SELECT scf.field_season_year,
                                fmm.parent_name,
                                scf.sub_mission_name,
                                scf.fsp_item_type,
                                scf.id AS scf_id,
                                ou.username AS fsp_owner,
                                scf.fsp_title,
                                fsm.state_name,
                                scf.region_name,
                                scf.fsp_stage_of_investigation,
                                fvd.*,ftm.theme_name
                        FROM save_created_fsp scf
                                LEFT JOIN fsp_commodity fc ON CAST(scf.id AS BIGINT) = fc.fsp_form_id
                                LEFT JOIN fsp_commodity_master fcm ON fcm.commodity_id = CAST(fc.fsp_commodity_name as BIGINT)
                                LEFT JOIN ocbis_users ou ON CAST(scf.user_id AS BIGINT) = ou.id
                                LEFT JOIN fsp_state_master fsm ON CAST(ou.state_id AS BIGINT) = fsm.id
                                LEFT JOIN fsp_vehicle_details fvd ON CAST(scf.id AS BIGINT) = fvd.fsp_form_id
                                LEFT JOIN fsp_mission_master fmm ON scf.mission_name = fmm.parent_code
                                LEFT JOIN fsp_submission_master fsmm ON scf.mission_name = fsmm.mission_code
                                LEFT JOIN fsp_item_type_master fitm on CAST(scf.fsp_item_type AS BIGINT) = fitm.id
                                LEFT JOIN fsp_theme_master ftm ON scf.theme_name = ftm.type_code
                                        WHERE (?1 IS NULL OR scf.field_season_year = ?1)
                                        AND (?2 IS NULL OR fmm.parent_name = ?2)
                                        AND (?3 IS NULL OR fsmm.mission_name = ?3)
                                        AND (?4 IS NULL OR scf.id = ?4)
                                        AND (?5 IS NULL OR scf.region_name = ?5)
                                        AND (?6 IS NULL OR fsm.state_name = ?6)
                                        AND (?7 IS NULL OR scf.fsp_stage_of_investigation = ?7)
                                        AND (?8 IS NULL OR scf.fsp_title ILIKE '%' || ?8 || '%')
                                        AND (?9 IS NULL OR fitm.item_type = ?9)
                                        AND (?10 IS NULL OR ou.username ILIKE '%' || ?10 || '%')
                                        AND (?11 IS NULL OR ftm.type_code = ?11)

                        ORDER BY scf.id
                        """, nativeQuery = true)
        Page<Map<String, Object>> getSearchFsp(
                        String fieldSeasonYear,
                        String mission,
                        String subMission,
                        Long fspId,
                        String region,
                        String stateUnit,
                        String fspStageOfInvestigation,
                        String title,
                        String fspItemType,
                        String fspOwner,
                        String activity,
                        Pageable pageable);

        @Query(value = """
                        SELECT scf.field_season_year,
                                scf.id AS scf_id,
                                fcm.commodity_name,
                                fcm.commodity_sub_group,
                                fcm.mineral_type,
                                fsm.state_name,
                                fvd.*

                        FROM save_created_fsp scf
                                LEFT JOIN fsp_commodity fc ON CAST(scf.id AS BIGINT) = fc.fsp_form_id
                                LEFT JOIN fsp_commodity_master fcm ON fcm.commodity_id = CAST(fc.fsp_commodity_name as BIGINT)
                                LEFT JOIN ocbis_users ou ON CAST(scf.user_id AS BIGINT) = ou.id
                                LEFT JOIN fsp_state_master fsm ON CAST(ou.state_id AS BIGINT) = fsm.id
                                LEFT JOIN fsp_vehicle_details fvd ON CAST(scf.id AS BIGINT) = fvd.fsp_form_id
                                LEFT JOIN fsp_mission_master fmm ON scf.mission_name = fmm.parent_code
                                LEFT JOIN fsp_submission_master fsmm ON scf.mission_name = fsmm.mission_code
                                LEFT JOIN fsp_item_type_master fitm on CAST(scf.fsp_item_type AS BIGINT) = fitm.id
                                LEFT JOIN fsp_theme_master ftm ON scf.theme_name = ftm.type_code
                                        WHERE (?1 IS NULL OR scf.field_season_year = ?1)
                                                AND (?2 IS NULL OR fmm.parent_name = ?2)
                                                AND (?3 IS NULL OR fsmm.mission_name = ?3)
                                                AND (?4 IS NULL OR scf.id = ?4)
                                                AND (?5 IS NULL OR scf.region_name = ?5)
                                                AND (?6 IS NULL OR fsm.state_name = ?6)
                                                AND (?7 IS NULL OR scf.fsp_stage_of_investigation = ?7)
                                                AND (?8 IS NULL OR fcm.commodity_name = ?8)
                                                AND (?9 IS NULL OR fcm.commodity_sub_group = ?9)
                                                AND (?10 IS NULL OR fcm.mineral_type = ?10)
                                                AND (?11 IS NULL OR fsm.state_name = ?11)
                                                AND (?12 IS NULL OR scf.fsp_title ILIKE '%' || ?12 || '%')
                                                AND (?13 IS NULL OR fitm.item_type= ?13)
                                                AND (?14 IS NULL OR ou.username ILIKE '%' || ?14 || '%')
                                                AND (?15 IS NULL OR ftm.type_code= ?15)
                                ORDER BY scf.id
                        """, nativeQuery = true)
        Page<Map<String, Object>> getSearchFspWithState(
                        String fieldSeasonYear,
                        String mission,
                        String subMission,
                        Long fspId,
                        String region,
                        String stateUnit,
                        String fspStageOfInvestigation,
                        String commodityName,
                        String commoditySubGroup,
                        String mineralType,
                        String stateName,
                        String title,
                        String fspItemType,
                        String fspOwner,
                        String activity,
                        Pageable pageable);

        @Query(value = """
                        SELECT  scf.field_season_year,
                                fmm.parent_name,
                                fitm.item_type,
                                fsmm.mission_name,
                                scf.id AS scf_id,
                                fsm.state_name,
                                scf.region_name,
                                scf.fsp_title,
                                ou.username,
                                fqtt.task,
                                fqtst.sub_task
                        FROM save_created_fsp scf
                                LEFT JOIN ocbis_users ou ON CAST(scf.user_id AS BIGINT) = ou.id
                                LEFT JOIN fsp_state_master fsm ON CAST(ou.state_id AS BIGINT) = fsm.id
                                LEFT JOIN fsp_mission_master fmm ON scf.mission_name = fmm.parent_code
                                LEFT JOIN fsp_item_type_master fitm on CAST(scf.fsp_item_type AS BIGINT) = fitm.id
                                LEFT JOIN fsp_submission_master fsmm ON scf.mission_name = fsmm.mission_code
                                LEFT JOIN fsp_qualitative_targets_task fqtt ON CAST(scf.id AS BIGINT) = fqtt.fsp_form_id
                                LEFT JOIN fsp_qualitative_targets_subtask fqtst ON  fqtt.id = fqtst.task_id
                                        WHERE (?1 IS NULL OR scf.field_season_year = ?1)
                                        AND (?2 IS NULL OR fmm.parent_name = ?2)
                                        AND (?3 IS NULL OR fsmm.mission_name = ?3)
                                        AND (?4 IS NULL OR scf.id = ?4)
                                        AND (?5 IS NULL OR scf.region_name = ?5)
                                        AND (?6 IS NULL OR fsm.state_name = ?6)
                                        AND (?7 IS NULL OR ou.username ILIKE '%' || ?7 || '%')
                                        AND (?8 IS NULL OR fitm.item_type = ?8)
                                        AND (?9 IS NULL OR scf.fsp_title ILIKE '%' || ?9 || '%')
                                        AND (?10 IS NULL OR fqtt.task ILIKE '%' || ?10 || '%')
                        ORDER BY scf.id
                        """, nativeQuery = true)
        Page<Map<String, Object>> getQualitativeSearchFsp(
                        String fieldSeasonYear,
                        String mission,
                        String subMission,
                        Long fspId,
                        String region,
                        String stateUnit,
                        String fspOwner,
                        String fspItemType,
                        String title,
                        String Task,
                        Pageable pageable);

        @Query(value = """
                        SELECT  scf.field_season_year,
                                fmm.parent_name,
                                fsmm.mission_name,
                                scf.id AS scf_id,
                                fsm.state_name,
                                scf.region_name,
                                scf.fsp_title,
                                foe.expense_head,
                                fitm.item_type,
                                ou.username,
                                foe.budget,
                                fvd.*
                        FROM save_created_fsp scf
                                LEFT JOIN ocbis_users ou ON CAST(scf.user_id AS BIGINT) = ou.id
                                LEFT JOIN fsp_state_master fsm ON CAST(ou.state_id AS BIGINT) = fsm.id
                                LEFT JOIN fsp_mission_master fmm ON scf.mission_name = fmm.parent_code
                                LEFT JOIN fsp_item_type_master fitm on CAST(scf.fsp_item_type AS BIGINT) = fitm.id
                                LEFT JOIN fsp_submission_master fsmm ON scf.mission_name = fsmm.mission_code
                                LEFT JOIN fsp_operational_expense foe ON  CAST(scf.id AS BIGINT) = foe.fsp_form_id
                                LEFT JOIN fsp_vehicle_details fvd ON CAST(scf.id AS BIGINT) = fvd.fsp_form_id
                                        WHERE (?1 IS NULL OR scf.field_season_year = ?1)
                                        AND (?2 IS NULL OR fmm.parent_name = ?2)
                                        AND (?3 IS NULL OR fsmm.mission_name = ?3)
                                        AND (?4 IS NULL OR scf.region_name = ?4)
                                        AND (?5 IS NULL OR fsm.state_name = ?5)
                                        AND (?6 IS NULL OR ou.username ILIKE '%' || ?6 || '%')
                                        AND (?7 IS NULL OR scf.fsp_title ILIKE '%' || ?7 || '%')
                                        AND (?8 IS NULL OR foe.expense_head = ?8)
                        ORDER BY scf.id
                        """, nativeQuery = true)
        Page<Map<String, Object>> getExpenseAndVehicleTrackSearchFsp(
                        String fieldSeasonYear,
                        String mission,
                        String subMission,
                        String region,
                        String stateUnit,
                        String fspOwner,
                        String title,
                        String expenseHead,
                        Pageable pageable);

        @Query(value = """
                        SELECT  scf.field_season_year,
                                fmm.parent_name,
                                fsmm.mission_name,
                                scf.proposal_id,
                                scf.region_name,
                                fsm.state_name,
                                scf.fsp_title,
                                fitm.item_type,
                                ou.username,
                                fald.*
                        FROM save_created_fsp scf
                                LEFT JOIN ocbis_users ou ON CAST(scf.user_id AS BIGINT) = ou.id
                                LEFT JOIN fsp_state_master fsm ON CAST(ou.state_id AS BIGINT) = fsm.id
                                LEFT JOIN fsp_mission_master fmm ON scf.mission_name = fmm.parent_code
                                LEFT JOIN fsp_item_type_master fitm on CAST(scf.fsp_item_type AS BIGINT) = fitm.id
                                LEFT JOIN fsp_submission_master fsmm ON scf.mission_name = fsmm.mission_code
                                LEFT JOIN fsp_approve_levels_details fald ON CAST(scf.id AS BIGINT) = fald.fsp_form_id
                                        WHERE (?1 IS NULL OR scf.field_season_year = ?1)
                                        AND (?2 IS NULL OR fmm.parent_name = ?2)
                                        AND (?3 IS NULL OR fsmm.mission_name = ?3)
                                        AND (?4 IS NULL OR scf.proposal_id ILIKE '%' || ?4 || '%')
                                        AND (?5 IS NULL OR scf.region_name = ?5)
                                        AND (?6 IS NULL OR fsm.state_name =  ?6 )
                                        AND (?7 IS NULL OR scf.fsp_title ILIKE '%' || ?7 || '%')
                                        AND (?8 IS NULL OR fitm.item_type = ?8)
                                        AND (?9 IS NULL OR ou.username ILIKE '%' || ?9 || '%')
                                        AND (?10 IS NULL OR fald.hod_status ILIKE '%' || ?10 || '%')
                        ORDER BY scf.id
                        """, nativeQuery = true)
        Page<Map<String, Object>> getProposalSearchFsp(
                        String fieldSeasonYear,
                        String mission,
                        String subMission,
                        String proposalId,
                        String region,
                        String stateUnit,
                        String title,
                        String itemType,
                        String fspOwner,
                        String approver,
                        Pageable pageable);

        @Query(value = """
                        SELECT  scf.field_season_year,
                                ou.username,
                                scf.proposal_id,
                                scf.fsp_title,
                                fmm.parent_name,
                                fsmm.mission_name,
                                fcm.mineral_type,
                                fitm.item_type,
                                fsm.state_name,
                                scf.fsp_stage_of_investigation,
                                fcm.commodity_name,
                                fcm.commodity_sub_group,
                                ftm.theme_name,
                                fvd.*

                        FROM save_created_fsp scf
                                LEFT JOIN fsp_commodity fc ON CAST(scf.id AS BIGINT) = fc.fsp_form_id
                                LEFT JOIN fsp_commodity_master fcm ON fcm.commodity_id = CAST(fc.fsp_commodity_name as BIGINT)
                                LEFT JOIN ocbis_users ou ON CAST(scf.user_id AS BIGINT) = ou.id
                                LEFT JOIN fsp_state_master fsm ON CAST(ou.state_id AS BIGINT) = fsm.id
                                LEFT JOIN fsp_mission_master fmm ON scf.mission_name = fmm.parent_code
                                LEFT JOIN fsp_item_type_master fitm ON CAST(scf.fsp_item_type AS BIGINT) = fitm.id
                                LEFT JOIN fsp_submission_master fsmm ON scf.mission_name = fsmm.mission_code
                                LEFT JOIN fsp_approve_levels_details fald ON CAST(scf.id AS BIGINT) = fald.fsp_form_id
                                LEFT JOIN fsp_theme_master ftm ON scf.theme_name = ftm.type_code
                                LEFT JOIN fsp_vehicle_details fvd ON CAST(scf.id AS BIGINT) = fvd.fsp_form_id

                        WHERE (?1 IS NULL OR scf.field_season_year = ?1)
                            AND (?2 IS NULL OR scf.proposal_id ILIKE '%' || ?2 || '%')
                            AND (?3 IS NULL OR fmm.parent_name = ?3)
                            AND (?4 IS NULL OR fsmm.mission_name = ?4)
                            AND (?5 IS NULL OR scf.region_name = ?5)
                            AND (?6 IS NULL OR scf.fsp_stage_of_investigation = ?6)
                            AND (?7 IS NULL OR fcm.commodity_name = ?7)
                            AND (?8 IS NULL OR fcm.commodity_sub_group = ?8)
                            AND (?9 IS NULL OR fcm.mineral_type = ?9)
                            AND (?10 IS NULL OR ftm.type_code = ?10)
                            AND (?11 IS NULL OR fsm.state_name = ?11)
                            AND (?12 IS NULL OR fitm.item_type = ?12)
                            AND (?13 IS NULL OR scf.fsp_title ILIKE '%' || ?13 || '%')
                            AND (?14 IS NULL OR ou.username ILIKE '%' || ?14 || '%')
                                    ORDER BY scf.id
                                    """, nativeQuery = true)
        Page<Map<String, Object>> getFormulationSearchFsp(
                        String fieldSeasonYear,
                        String proposalId,
                        String mission,
                        String subMission,
                        String region,
                        String fspStageOfInvestigation,
                        String commodityName,
                        String commoditySubGroup,
                        String mineralType,
                        String activity,
                        String stateUnit,
                        String itemType,
                        String title,
                        String fspOwner,
                        Pageable pageable);

        @Query(nativeQuery = true, value = """
                        SELECT fpr.*,fald.*,scf.*,ou.*
                         FROM
                             save_created_fsp scf
                          JOIN fsp_approve_levels_details fald ON fald.fsp_form_id = scf.id
                          JOIN ocbis_users ou on ou.id = scf.user_id
                          left join fsp_peer_review fpr on fpr.proposal_id = fald.proposal_id

                          WHERE scf.steps_completed = 9 and fpr.pss_status='Approved' and  fpr.forwarded_to_director_of_pu_id=?2 AND  ou.state_id = ?1 and scf.fsp_id is not null

                                   """)
        Page<Map<String, Object>> getApprovedFspAfterPeerReview(String stateId, Long id, Pageable pageable);

        @Modifying
        @Query(nativeQuery = true, value = """
                            WITH fsp_data AS (
                            SELECT
                                pu_region,
                                pu_state_unit
                            FROM
                                save_created_fsp
                            WHERE
                                fsp_id IS NOT NULL
                        ),
                        user_data AS (
                            SELECT
                                ou.id AS user_id,
                                fd.pu_region,
                                fd.pu_state_unit
                            FROM
                                fsp_data fd
                            JOIN
                                public.ocbis_users ou
                            ON
                                ou.regional_id = fd.pu_region
                                AND ou.state_id = fd.pu_state_unit
                            WHERE
                                ou.designation_id = '1'
                        )
                        UPDATE
                            fsp_peer_review fpr
                        SET
                            forwarded_to_director_of_pu_id = ud.user_id
                        FROM
                            user_data ud
                        WHERE
                            EXISTS (
                                SELECT 1
                                FROM save_created_fsp scf
                                WHERE scf.fsp_id = fpr.fsp_id
                                AND scf.pu_region = ud.pu_region
                                AND scf.pu_state_unit = ud.pu_state_unit
                            )
                        """)
        List<Map<String, Object>> assignFspToDirector();

}
