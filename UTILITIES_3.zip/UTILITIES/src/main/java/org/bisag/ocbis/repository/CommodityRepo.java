package org.bisag.ocbis.repository;

import java.util.List;

import org.bisag.ocbis.models.Commodity;
import org.bisag.ocbis.models.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommodityRepo extends JpaRepository<Commodity, Long> {

    void deleteByFspFormId(Long fspFormId);

    List<Commodity> findByFspFormId(Long fspFormId);

}
