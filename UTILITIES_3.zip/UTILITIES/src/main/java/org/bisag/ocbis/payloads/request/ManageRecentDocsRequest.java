package org.bisag.ocbis.payloads.request;

public record ManageRecentDocsRequest( 
        Long id , 
        String title ,
        String region , 
        String securityGroup,
        String type , 
        String documentType,
        String description ,
        String status ,
        String receivedDate ){}


