package org.bisag.ocbis.repository;

import java.util.List;

import org.bisag.ocbis.models.BoreholeEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface BoreholeRepo extends JpaRepository<BoreholeEntity, Long> {

  @Query(nativeQuery = true, value = """
        SELECT * FROM Borehole_Information b
        WHERE (?1\\:\\:text IS NULL OR b\\:\\:text ILIKE ?1)
        AND (?2\\:\\:text IS NULL OR b.prospectname = ?2)
        AND (?3\\:\\:text IS NULL OR b.block_name = ?3)
        AND (?4\\:\\:text IS NULL OR b.input_center_code = ?4)
        AND (?5\\:\\:text IS NULL OR b.commodity = ?5)
        AND (?6\\:\\:text IS NULL OR b.borehole_name = ?6)
        AND (?7\\:\\:text IS NULL OR b.source_of_data = ?7)
        AND (?8\\:\\:text IS NULL OR b.region = ?8)
        AND (?9\\:\\:text IS NULL OR b.state = ?9)
        AND (?10\\:\\:text IS NULL OR b.district = ?10)

      """)
  Page<BoreholeEntity> findByFilters(String search, String prospectName, String blockName, String inputCenterCode,
      String commodity, String boreholeName, String sourceOfData, String region, String state, String district,
      Pageable pageable);

  @Query(nativeQuery = true, value = """
        SELECT * FROM Borehole_Information b
        WHERE (?1\\:\\:text IS NULL OR b\\:\\:text ILIKE ?1)
        AND (?2\\:\\:text IS NULL OR b.prospectname = ?2)
        AND (?3\\:\\:text IS NULL OR b.block_name = ?3)
        AND (?4\\:\\:text IS NULL OR b.input_center_code = ?4)
        AND (?5\\:\\:text IS NULL OR b.commodity = ?5)
        AND (?6\\:\\:text IS NULL OR b.borehole_name = ?6)
        AND (?7\\:\\:text IS NULL OR b.source_of_data = ?7)
        AND (?8\\:\\:text IS NULL OR b.region = ?8)
        AND (?9\\:\\:text IS NULL OR b.state = ?9)
        AND (?10\\:\\:text IS NULL OR b.district = ?10)

      """)
  List<BoreholeEntity> findByFiltersExport(String search, String prospectName, String blockName, String inputCenterCode,
      String commodity, String boreholeName, String sourceOfData, String region, String state, String district);
}
