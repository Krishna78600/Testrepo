package org.bisag.ocbis.models;

public enum ERole {
    ROLE_USER, ROLE_MODERATOR, ROLE_ADMIN
}
