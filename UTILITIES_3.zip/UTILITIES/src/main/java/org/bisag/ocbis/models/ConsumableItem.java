package org.bisag.ocbis.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "fsp_consumable_item")
public class ConsumableItem {
    
     @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String consumableItemTypes;
    private Integer consumableQuantity;
    private Integer itemExpense;
    private Integer consumableTotal;
    private String proposalId;
    private Long fspFormId;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getConsumableItemTypes() {
        return consumableItemTypes;
    }
    public void setConsumableItemTypes(String consumableItemTypes) {
        this.consumableItemTypes = consumableItemTypes;
    }
    public String getProposalId() {
        return proposalId;
    }
    public void setProposalId(String proposalId) {
        this.proposalId = proposalId;
    }
    public Integer getItemExpense() {
        return itemExpense;
    }
    public void setItemExpense(Integer itemExpense) {
        this.itemExpense = itemExpense;
    }
    public Integer getConsumableQuantity() {
        return consumableQuantity;
    }
    public void setConsumableQuantity(Integer consumableQuantity) {
        this.consumableQuantity = consumableQuantity;
    }
    public Integer getConsumableTotal() {
        return consumableTotal;
    }
    public void setConsumableTotal(Integer consumableTotal) {
        this.consumableTotal = consumableTotal;
    }
    public Long getFspFormId() {
        return fspFormId;
    }
    public void setFspFormId(Long fspFormId) {
        this.fspFormId = fspFormId;
    }
    

    

}
