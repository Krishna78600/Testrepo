package org.bisag.ocbis.services;

import java.time.ZonedDateTime;

import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.springframework.transaction.annotation.Transactional;

public class PeerReviewService {
    @Transactional
    public EncryptedResponse rejectOrReturnFsp(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
            String status, String remarks, Long fspFormId, ZonedDateTime createdDate) throws Exception {

        return new EncryptedResponse("Forwarded to DDG of Submission successfully");
    }
}
