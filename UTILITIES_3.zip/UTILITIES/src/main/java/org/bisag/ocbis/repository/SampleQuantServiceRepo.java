package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.SampleQuantService;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;


public interface SampleQuantServiceRepo extends JpaRepository<SampleQuantService, Long> {
  void deleteByFspFormId(Long fspFormId);
    List<SampleQuantService> findByFspFormId(Long fspFormId);
}
