package org.bisag.ocbis.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.util.List;

@Entity
@Table(name = "fsp_sample_quant_service")
public class SampleQuantService {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String sampleQuantAndServiceActivityType;
    private String sampleQuantAndServiceActivityName;
    private Integer sampleQuantAndServiceSampleTarget;
    private List<String> sampleQuantAndServiceElements;
    private Integer sampleQuantAndServiceTotalWorkload;
    private Integer sampleQuantAndServiceWorkCompleted;

    private String proposalId;
    private Long fspFormId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProposalId() {
        return proposalId;
    }

    public void setProposalId(String proposalId) {
        this.proposalId = proposalId;
    }

    public String getSampleQuantAndServiceActivityType() {
        return sampleQuantAndServiceActivityType;
    }

    public void setSampleQuantAndServiceActivityType(String sampleQuantAndServiceActivityType) {
        this.sampleQuantAndServiceActivityType = sampleQuantAndServiceActivityType;
    }

    public String getSampleQuantAndServiceActivityName() {
        return sampleQuantAndServiceActivityName;
    }

    public void setSampleQuantAndServiceActivityName(String sampleQuantAndServiceActivityName) {
        this.sampleQuantAndServiceActivityName = sampleQuantAndServiceActivityName;
    }

    public Integer getSampleQuantAndServiceSampleTarget() {
        return sampleQuantAndServiceSampleTarget;
    }

    public void setSampleQuantAndServiceSampleTarget(Integer sampleQuantAndServiceSampleTarget) {
        this.sampleQuantAndServiceSampleTarget = sampleQuantAndServiceSampleTarget;
    }

    public Integer getSampleQuantAndServiceTotalWorkload() {
        return sampleQuantAndServiceTotalWorkload;
    }

    public void setSampleQuantAndServiceTotalWorkload(Integer sampleQuantAndServiceTotalWorkload) {
        this.sampleQuantAndServiceTotalWorkload = sampleQuantAndServiceTotalWorkload;
    }

    public Integer getSampleQuantAndServiceWorkCompleted() {
        return sampleQuantAndServiceWorkCompleted;
    }

    public void setSampleQuantAndServiceWorkCompleted(Integer sampleQuantAndServiceWorkCompleted) {
        this.sampleQuantAndServiceWorkCompleted = sampleQuantAndServiceWorkCompleted;
    }

    public Long getFspFormId() {
        return fspFormId;
    }

    public void setFspFormId(Long fspFormId) {
        this.fspFormId = fspFormId;
    }

    public List<String> getSampleQuantAndServiceElements() {
        return sampleQuantAndServiceElements;
    }

    public void setSampleQuantAndServiceElements(List<String> sampleQuantAndServiceElements) {
        this.sampleQuantAndServiceElements = sampleQuantAndServiceElements;
    }

}
