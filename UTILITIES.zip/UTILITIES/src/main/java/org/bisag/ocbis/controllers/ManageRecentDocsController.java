// package org.bisag.ocbis.controllers;

// import org.bisag.ocbis.models.ManageRecentDocs;
// import org.bisag.ocbis.services.ManageRecentDocsService;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.stereotype.Controller;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RequestParam;
// import org.springframework.web.multipart.MultipartFile;

// @Controller
// @RequestMapping("/file")
// public class ManageRecentDocsController {

//     @Autowired
//     private ManageRecentDocsService managerecentdocservice;

//     @PostMapping("/uploadRecentDocument")
//     public ResponseEntity<ManageRecentDocs> UploadRecentDocument(@RequestParam("file") MultipartFile file , @RequestParam ManageRecentDocs manageDocs) 
     
//     {
//         String message ;
//         try {
//             ManageRecentDocs response = managerecentdocservice.UploadDoc(manageDocs, file);

//             message = "Uploaded the file successfully: " + file.getOriginalFilename();
//             System.out.println(message);
//             return ResponseEntity.ok(response);
//         } catch (Exception e) {
//             ManageRecentDocs response = managerecentdocservice.UploadDoc(manageDocs, file);
//             message = "Could not upload the file: " + file.getOriginalFilename() + ". Error: " + e.getMessage();
//             System.out.println(message);
//             return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(response);

//         }
//     }
// }

//------------------------------------------------------------------------------------    

// Anil sir code ---------------------------------------------------------------------

//   @Value("${fileServerPath}")
//   String fileServerPath;

//   @GetMapping("/docs/{file}")
//   public void verifyPdf(@PathVariable(value = "file") String file,
//       HttpServletResponse response)
//       throws Exception {
//     try {
//       response.setStatus(200);
//       response.setContentType("application/pdf");
//       IOUtils.copy(FileUtils.openInputStream(
//           new File(fileServerPath + "PeerReview/" + file)),
//           response.getOutputStream());
//     } catch (Exception ex) {
//       System.out.println("ex: " + ex.getMessage());
//       throw new NotFoundException("Pdf not found.");
//     }
//   }

//   @GetMapping("/documents/{file}")
//   public void verifyPdfFile(@PathVariable(value = "file") String file,
//       HttpServletResponse response)
//       throws Exception {
//     try {
//       response.setStatus(200);
//       response.setContentType("application/pdf");
//       IOUtils.copy(FileUtils.openInputStream(
//           new File(fileServerPath + "ExternalPeerReview/" + file)),
//           response.getOutputStream());
//     } catch (Exception ex) { 
//       System.out.println("ex: " + ex.getMessage());
//       throw new NotFoundException("Pdf not found.");
//     }
//   }
//-----------------------------------------------------------------------------

package org.bisag.ocbis.controllers;

import org.bisag.ocbis.models.ManageRecentDocs;
import org.bisag.ocbis.services.ManageRecentDocsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/file")
public class ManageRecentDocsController {

    @Autowired
    private ManageRecentDocsService managerecentdocservice;

    @PostMapping("/uploadRecentDocument")
    public ResponseEntity<String> uploadRecentDocument(@RequestParam("file") MultipartFile file, 
                                                       @RequestParam("title") String title,
                                                       @RequestParam("region") String region,
                                                       @RequestParam("securityGroup") String securityGroup,
                                                       @RequestParam("type") String type,
                                                       @RequestParam("documentType") String documentType,
                                                       @RequestParam("description") String description,
                                                       @RequestParam("status") String status,
                                                       @RequestParam("receivedDate") String receivedDate) {
        String message;
        ManageRecentDocs manageDocs = new ManageRecentDocs();
        manageDocs.setTitle(title);
        manageDocs.setRegion(region);
        manageDocs.setSecurityGroup(securityGroup);
        manageDocs.setType(type);
        manageDocs.setDocumentType(documentType);
        manageDocs.setDescription(description);
        manageDocs.setStatus(status);
        manageDocs.setReceivedDate(receivedDate);

        try {
            ManageRecentDocs response = managerecentdocservice.UploadDoc(manageDocs, file);
            message = "Uploaded the file successfully: " + file.getOriginalFilename();
            System.out.println(message);
            return ResponseEntity.ok(message);
        } catch (Exception e) {
            message = "Could not upload the file: " + file.getOriginalFilename() + ". Error: " + e.getMessage();
            System.out.println(message);
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
        }
    }
}

  
