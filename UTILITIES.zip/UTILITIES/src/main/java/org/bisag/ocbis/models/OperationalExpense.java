package org.bisag.ocbis.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "fsp_operational_expense")
public class OperationalExpense {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String expenseHead;
    private String expenseType;
    private Integer budget;
    private Integer qtr1;
    private Integer qtr2;
    private Integer qtr3;
    private Integer qtr4;
    private String proposalId;
    private Long fspFormId;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getExpenseHead() {
        return expenseHead;
    }
    public void setExpenseHead(String expenseHead) {
        this.expenseHead = expenseHead;
    }
    public String getExpenseType() {
        return expenseType;
    }
    public void setExpenseType(String expenseType) {
        this.expenseType = expenseType;
    }
    public Integer getBudget() {
        return budget;
    }
    public void setBudget(Integer budget) {
        this.budget = budget;
    }
    public Integer getQtr1() {
        return qtr1;
    }
    public void setQtr1(Integer qtr1) {
        this.qtr1 = qtr1;
    }
    public Integer getQtr2() {
        return qtr2;
    }
    public void setQtr2(Integer qtr2) {
        this.qtr2 = qtr2;
    }
    public Integer getQtr3() {
        return qtr3;
    }
    public void setQtr3(Integer qtr3) {
        this.qtr3 = qtr3;
    }
    public Integer getQtr4() {
        return qtr4;
    }
    public void setQtr4(Integer qtr4) {
        this.qtr4 = qtr4;
    }
    public String getProposalId() {
        return proposalId;
    }
    public void setProposalId(String proposalId) {
        this.proposalId = proposalId;
    }
    public Long getFspFormId() {
        return fspFormId;
    }
    public void setFspFormId(Long fspFormId) {
        this.fspFormId = fspFormId;
    }


}
