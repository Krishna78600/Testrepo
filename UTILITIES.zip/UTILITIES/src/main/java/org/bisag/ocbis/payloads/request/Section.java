package org.bisag.ocbis.payloads.request;

public record Section(String search, String chainPLINE, String leftPLINE, String rightPLINE, String linePLINE,
    String mainlinechain) {

}
