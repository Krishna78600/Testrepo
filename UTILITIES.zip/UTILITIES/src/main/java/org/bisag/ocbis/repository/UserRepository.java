package org.bisag.ocbis.repository;

import java.util.List;
import java.util.Map;

import org.bisag.ocbis.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

        User findFirstByEmail(String username);

        @Query(nativeQuery = true, value = """
                                SELECT * FROM ocbis_users WHERE designation_id = '11' AND state_id = ?1 limit 1
                        """)
        User findSuHeadStateWise(String stateId);

        @Query(nativeQuery = true, value = """
                                SELECT * FROM ocbis_users WHERE regional_id = ?1 AND designation_id = ?2
                        """)
        List<User> findUserByRegionalandDesignation(String regionalId, String designationId);

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_region_master ORDER BY region_name ASC
                            """)
        List<Map<String, Object>> getAllRegion();

}
