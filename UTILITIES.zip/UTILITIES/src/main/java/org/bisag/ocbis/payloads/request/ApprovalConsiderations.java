package org.bisag.ocbis.payloads.request;

public record ApprovalConsiderations(String firstApprovingAuthority, String parentMission,
        String subMission, String proposalId, Long fspFormId, Long Id, Long forwardeToOfficerUserId, String remarks,String status,String keyword) {

}
