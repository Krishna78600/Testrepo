package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.Vehicle;
// import org.hibernate.mapping.List;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface VehicleRepo extends JpaRepository<Vehicle, Long> {
     void deleteByFspFormId(Long fspFormId);
    List<Vehicle> findByFspFormId(Long fspFormId);
}
