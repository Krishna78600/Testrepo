package org.bisag.ocbis.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="managerecentdocs")
public class ManageRecentDocs {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title ;
    private String region ;
    private String securityGroup ;
    private String type ;
    private String documentType ;
    private String description ;
    private String status ;
    private String receivedDate ;
    private byte[] uploadDocument ;
    
    public void setId(long id ){
        this.id = id ;
    }
    public long getId(){
        return id ;
    }

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title ;
       
    }
    public String getRegion() {
        return region;
    }
    public void setRegion(String region) {
        this.region = region;
    }
    public String getSecurityGroup() {
        return securityGroup;
    }
    public void setSecurityGroup(String securityGroup) {
        this.securityGroup = securityGroup;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getDocumentType() {
        return documentType;
    }
    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getReceivedDate() {
        return receivedDate;
    }
    public void setReceivedDate(String receivedDate) {
        this.receivedDate = receivedDate;
    }
  

    public byte[] getUploadDocument() {
        return this.uploadDocument;
    }

    public void setUploadDocument(byte[] uploadDocument) {
        this.uploadDocument = uploadDocument;
    }
    
}


