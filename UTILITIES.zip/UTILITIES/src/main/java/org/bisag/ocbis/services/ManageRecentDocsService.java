package org.bisag.ocbis.services;

import org.bisag.ocbis.models.ManageRecentDocs;
import org.bisag.ocbis.repository.ManageRecentDocsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import io.jsonwebtoken.io.IOException;

@Service
public class ManageRecentDocsService {
    
    @Autowired
    private ManageRecentDocsRepository managerecentdocsrepo ;

    public ManageRecentDocs UploadDoc(ManageRecentDocs manageDocs, MultipartFile file) throws IOException 
    {
        
        ManageRecentDocs manageRecent = new ManageRecentDocs();

        try {
            manageRecent.setUploadDocument(file.getBytes());
            
            manageRecent.setTitle(manageDocs.getTitle());
            manageRecent.setRegion(manageDocs.getRegion());
            manageRecent.setSecurityGroup(manageDocs.getSecurityGroup());
            manageRecent.setType(manageDocs.getType());
            manageRecent.setDocumentType(manageDocs.getDocumentType());
            manageRecent.setDescription(manageDocs.getDescription());
            manageRecent.setStatus(manageDocs.getStatus());
            manageRecent.setReceivedDate(manageDocs.getReceivedDate());
            
            managerecentdocsrepo.save(manageRecent);

        } catch (java.io.IOException ex) {
        }
        

       // throw new UnsupportedOperationException("Unimplemented method 'UploadFile'");
        return manageRecent ;
    }

}
