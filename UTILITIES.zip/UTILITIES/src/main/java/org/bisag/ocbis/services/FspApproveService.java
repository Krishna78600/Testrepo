package org.bisag.ocbis.services;

import java.time.ZonedDateTime;

import org.bisag.ocbis.models.User;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.FspApproveRepo;
import org.bisag.ocbis.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FspApproveService {

        @Autowired
        FspApproveRepo fspApproveRepo;

        @Autowired
        UserRepository userRepo;

        @Transactional
        public EncryptedResponse forwardToSUhead(Long forwardedByOfficerUserId, Long forwardedToSuHeadId,
                        ZonedDateTime createdDate, Long fspFormId, String stateId, String Remarks, String status)
                        throws Exception {

                // AutoPush to suhead--> logic for finding suHead
                User userDetails = userRepo.findSuHeadStateWise(stateId);
                forwardedToSuHeadId = userDetails.getId();

                fspApproveRepo.forwardToSUhead(forwardedByOfficerUserId, forwardedToSuHeadId, createdDate, fspFormId,
                                null,
                                null, null);
                return new EncryptedResponse("Forwarded to SU Head successfully");
        }

        @Transactional
        public EncryptedResponse forwardToRmhOfPmBySuHead(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {

                fspApproveRepo.forwardToRmhOfPmBySuHead(forwardeByOfficerUserId, forwardeToOfficerUserId, createdDate,
                                fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded to RMH of Parent Mission successfully");
        }

        @Transactional
        public EncryptedResponse forwardToHodByRmhOfPm(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {
                fspApproveRepo.forwardToHodByRmhOfPm(forwardeByOfficerUserId, forwardeToOfficerUserId, createdDate,
                                fspFormId,
                                remarks, status, null);
                return new EncryptedResponse("Forwarded to HOD successfully");
        }

        @Transactional
        public EncryptedResponse forwardToDdgofSmByHod(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {

                fspApproveRepo.forwardToDdgofSmByHod(forwardeByOfficerUserId, forwardeToOfficerUserId, createdDate,
                                fspFormId,
                                remarks, status, null);
                return new EncryptedResponse("Forwarded to DDG of Submission successfully");
        }

        @Transactional
        public EncryptedResponse forwardToAdgOfPssByDdgofSm(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {

                fspApproveRepo.forwardToAdgOfPssByDdgofSm(forwardeByOfficerUserId, forwardeToOfficerUserId, createdDate,
                                fspFormId, remarks, status, null);
                return new EncryptedResponse("Forwarded to DDG of Submission successfully");
        }

        @Transactional
        public EncryptedResponse forwardToHodBySu(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {

                fspApproveRepo.forwardToHodBySu(forwardeByOfficerUserId, forwardeToOfficerUserId, createdDate,
                                fspFormId,
                                remarks, status, null);
                return new EncryptedResponse("Forwarded to DDG of Submission successfully");
        }

        @Transactional
        public EncryptedResponse forwardedByAdgOfPss(Long forwardeByOfficerUserId,
                        ZonedDateTime createdDate, Long fspFormId, String remarks, String status, String stateId)
                        throws Exception {

                fspApproveRepo.forwardedByAdgOfPss(forwardeByOfficerUserId, createdDate, fspFormId, remarks, status,
                                null);
                return new EncryptedResponse("Forwarded to DDG of Submission successfully");
        }

        @Transactional
        public EncryptedResponse rejectOrReturnFsp(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        String status, String remarks, Long fspFormId, ZonedDateTime createdDate) throws Exception {
                fspApproveRepo.rejectOrReturnFsp(forwardeByOfficerUserId, forwardeToOfficerUserId, status, remarks,
                                fspFormId, createdDate);
                return new EncryptedResponse("Forwarded to DDG of Submission successfully");
        }

}
