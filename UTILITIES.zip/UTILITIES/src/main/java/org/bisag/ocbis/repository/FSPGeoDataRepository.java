package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.FspGeoData;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FSPGeoDataRepository extends JpaRepository<FspGeoData, Long> {
    // @Query(value = """
    //         INSERT INTO geom (geom, wkt, fsp_form_id, proposal_id,topo_sheet_number)
    //         VALUES (ST_GeomFromText(?1, 4326), ?1, ?2, ?3,?4)
    //         RETURNING id
    //         """, nativeQuery = true)
    // Long saveGeometry(String wkt, Long fspFormId, String proposalId, String topoSheetNumber);
}