package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.ManageRecentDocs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ManageRecentDocsRepository extends JpaRepository<ManageRecentDocs, Long> {


}
