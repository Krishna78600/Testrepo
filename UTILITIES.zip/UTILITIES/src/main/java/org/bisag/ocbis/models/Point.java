package org.bisag.ocbis.models;

public class Point {
	String odwktforpoint;
	String distancefromsource;

	public String getOdwktforpoint() {
		return odwktforpoint;
	}

	public void setOdwktforpoint(String odwktforpoint) {
		this.odwktforpoint = odwktforpoint;
	}

	public String getDistancefromsource() {
		return distancefromsource;
	}

	public void setDistancefromsource(String distancefromsource) {
		this.distancefromsource = distancefromsource;
	}
}
