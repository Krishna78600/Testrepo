package org.bisag.clis.payloads.request;

public record Pagination(int page, int size) {};
