package org.bisag.clis.payloads.request;

public record GetId(String id, String code, Long fspFormId, String fspId) {
}
