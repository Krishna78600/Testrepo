package org.bisag.clis.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bisag.clis.model.District;
import org.bisag.clis.model.State;
import org.bisag.clis.model.Taluka;
import org.bisag.clis.model.Village;
import org.bisag.clis.payloads.request.BoundaryRequest;
import org.bisag.clis.repository.DistrictRepository;
import org.bisag.clis.repository.StateRepsitory;
import org.bisag.clis.repository.TalukaRepository;
import org.bisag.clis.repository.VillageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class NavigationService {
  @Autowired
  StateRepsitory stateRepo;
  @Autowired
  DistrictRepository districtRepo;
  @Autowired
  TalukaRepository talukaRepo;
  @Autowired
  VillageRepository villageRepo;
  @Autowired
  JdbcTemplate jdbcTemplate;

  public List<State> getAllStates() {
    return stateRepo.findAllByStatenameNotNullOrderByStatenameAsc();
  }

  public List<District> getDistrictsByStateId(String stateId) {
    return districtRepo
        .findByStatecodeAndDistrictnameNotNullOrderByDistrictnameAsc(stateId);
  }

  public List<Taluka> getTalukasByDistrictId(String districtId) {
    return talukaRepo
        .findByDistrictcodeAndTalukanameNotNullOrderByTalukanameAsc(districtId);
  }

  public List<Village> getVillagesByTalukaId(String talukaId) {
    return villageRepo
        .findByTalukacodeAndVillageNameNotNullOrderByVillageNameAsc(talukaId);
  }

  public List<Map<String, Object>> getBoundary(BoundaryRequest boundaryRequest) {
    String query = "SELECT ST_AsGeoJSON(geom) FROM " + boundaryRequest.table()
        + " WHERE " + boundaryRequest.column() + " = ?";
    return jdbcTemplate.queryForList(query, boundaryRequest.id());
  }

  public List<Map<String, Object>> searchAll(String query) {
    String startsWithQuery = query + "%";
    var states = stateRepo.search(startsWithQuery);
    var districts = districtRepo.search(startsWithQuery);
    var talukas = talukaRepo.search(startsWithQuery);
    var villages = villageRepo.search(startsWithQuery);
    var totalSize = states.size() + districts.size() + talukas.size() + villages.size();
    var mergedList = new ArrayList<Map<String, Object>>(totalSize);
    mergedList.addAll(states);
    mergedList.addAll(districts);
    mergedList.addAll(talukas);
    mergedList.addAll(villages);
    return mergedList;
  }
}
