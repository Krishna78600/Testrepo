package org.bisag.clis.security.jwt;

public record Jwt(String subject, String fp, long timestamp) {
}
