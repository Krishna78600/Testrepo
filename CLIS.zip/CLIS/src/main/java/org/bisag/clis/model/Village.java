package org.bisag.clis.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import static jakarta.persistence.GenerationType.IDENTITY;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "village_boundary_21_03_2023",
		uniqueConstraints = {@UniqueConstraint(columnNames = "gid")})
public class Village {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private int gid;
	@Column(name = "vil_name11")
	private String villageName;

	@Column(name = "vil_2011")
	private String villagecode;

	@Column(name = "sdt_2011")
	private String talukacode;

	private String minx;
	private String miny;
	private String maxx;
	private String maxy;


	public String getMinx() {
		return minx;
	}

	public void setMinx(String minx) {
		this.minx = minx;
	}

	public String getMiny() {
		return miny;
	}

	public void setMiny(String miny) {
		this.miny = miny;
	}

	public String getMaxx() {
		return maxx;
	}

	public void setMaxx(String maxx) {
		this.maxx = maxx;
	}

	public String getMaxy() {
		return maxy;
	}

	public void setMaxy(String maxy) {
		this.maxy = maxy;
	}

	public int getGid() {
		return gid;
	}

	public void setGid(int gid) {
		this.gid = gid;
	}

	public String getVillageName() {
		return villageName;
	}

	public void setVillageName(String villageName) {
		this.villageName = villageName;
	}

	public String getVillagecode() {
		return villagecode;
	}

	public void setVillagecode(String villagecode) {
		this.villagecode = villagecode;
	}

	public String getTalukacode() {
		return talukacode;
	}

	public void setTalukacode(String talukacode) {
		this.talukacode = talukacode;
	}

}
