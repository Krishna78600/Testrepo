package org.bisag.clis.payloads.request;

public record BoundaryRequest(String table, String column, String id) {
}
