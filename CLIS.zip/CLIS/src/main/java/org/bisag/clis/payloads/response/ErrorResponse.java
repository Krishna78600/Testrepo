package org.bisag.clis.payloads.response;

public record ErrorResponse(String error) {}
