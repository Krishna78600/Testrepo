package org.bisag.clis.payloads.request;

public record Progress(int id,
    String date,
    String progress,
    Integer ministryid,
    String username,
    Integer userid) {}
