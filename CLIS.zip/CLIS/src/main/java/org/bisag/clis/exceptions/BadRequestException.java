package org.bisag.clis.exceptions;

public class BadRequestException extends Exception {
  public BadRequestException(String msg) {
    super(msg);
  }
}
