package org.bisag.clis.exceptions;

public class UnauthorizedException extends Exception {
  public UnauthorizedException(String msg) {
    super(msg);
  }
}
