package org.bisag.clis.repository;

import java.util.List;
import java.util.Map;

import org.bisag.clis.model.Village;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface VillageRepository extends JpaRepository<Village, Integer> {

  List<Village> findByTalukacodeAndVillageNameNotNullOrderByVillageNameAsc(String id);

  @Query(nativeQuery = true, value = """
          SELECT vil_name11 as Village, minx, miny, maxx, maxy
          FROM village_boundary_21_03_2023
          WHERE UPPER(vil_name11) LIKE UPPER(?1)
          GROUP BY vil_name11, minx, miny, maxx, maxy
      """)
  List<Map<String, Object>> search(String query);

}
