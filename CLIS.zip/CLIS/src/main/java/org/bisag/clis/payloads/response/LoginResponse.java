package org.bisag.clis.payloads.response;

import org.bisag.clis.model.User;

public record LoginResponse(String token, User user) {}
