package org.bisag.clis.exceptions;

public class ForbiddenException extends Exception {
  public ForbiddenException(String msg) {
    super(msg);
  }
}
