package org.bisag.clis.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import static jakarta.persistence.GenerationType.IDENTITY;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "taluka_boundary_21_03_2023",
		uniqueConstraints = {@UniqueConstraint(columnNames = "gid")})
public class Taluka {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private int gid;

	@Column(name = "dtcode_lg")
	private String districtcode;

	@Column(name = "sdtcode11")
	private String talukacode;

	@Column(name = "name11")
	private String talukaname;

	private String minx;
	private String miny;
	private String maxx;
	private String maxy;


	public String getMinx() {
		return minx;
	}

	public void setMinx(String minx) {
		this.minx = minx;
	}

	public String getMiny() {
		return miny;
	}

	public void setMiny(String miny) {
		this.miny = miny;
	}

	public String getMaxx() {
		return maxx;
	}

	public void setMaxx(String maxx) {
		this.maxx = maxx;
	}

	public String getMaxy() {
		return maxy;
	}

	public void setMaxy(String maxy) {
		this.maxy = maxy;
	}

	public int getGid() {
		return gid;
	}

	public void setGid(int gid) {
		this.gid = gid;
	}

	public String getDistrictcode() {
		return districtcode;
	}

	public void setDistrictcode(String districtcode) {
		this.districtcode = districtcode;
	}

	public String getTalukacode() {
		return talukacode;
	}

	public void setTalukacode(String talukacode) {
		this.talukacode = talukacode;
	}

	public String getTalukaname() {
		return talukaname;
	}

	public void setTalukaname(String talukaname) {
		this.talukaname = talukaname;
	}


}

