package org.bisag.clis.payloads.request;

public record LongId(Long id) {
}
