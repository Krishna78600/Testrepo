package org.bisag.clis.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SmsThread {
  @Autowired
  MailConfig mailconfig;

  public void send(String otp, String mobile, String email) {
    new Thread() {
      @Override
      public void run() {
        System.out.println("sending SMS with OTP: " + otp);
        try {
          // if (mailconfig.sendMail("Verify OTP for Public PM Gatishakti", new
          // InternetAddress(email),
          // "Your OTP is " + otp, null).equals("SUCCESS"))
          // System.out.println("Email sent successfully");

          String smsResponse = new SmsService()
              .sendOtpSMS("Your OTP is " + otp + " - Digital India Corporation", mobile);
          System.out.println("SMS API response: " + smsResponse);
        } catch (Exception e) {
          System.out.println("SMS API error: " + e);
        }
      }
    }.start();
  }
}
