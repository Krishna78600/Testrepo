package org.bisag.clis.repository;

import java.util.List;
import java.util.Map;

import org.bisag.clis.model.Taluka;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface TalukaRepository extends JpaRepository<Taluka, Integer> {

  List<Taluka> findByDistrictcodeAndTalukanameNotNullOrderByTalukanameAsc(String id);

  @Query(nativeQuery = true, value = """
          SELECT name11 as Taluka, minx, miny, maxx, maxy
          FROM taluka_boundary_21_03_2023
          WHERE UPPER(name11) LIKE UPPER(?1)
          GROUP BY name11, minx, miny, maxx, maxy
      """)
  List<Map<String, Object>> search(String query);

}
