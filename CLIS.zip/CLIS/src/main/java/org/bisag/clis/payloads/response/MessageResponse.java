package org.bisag.clis.payloads.response;

public record MessageResponse(String message) {}
