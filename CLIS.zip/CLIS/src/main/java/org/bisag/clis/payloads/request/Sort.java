package org.bisag.clis.payloads.request;

// directions: 0 -> ASC, 1 -> DESC
public record Sort(String column, int direction) {}
