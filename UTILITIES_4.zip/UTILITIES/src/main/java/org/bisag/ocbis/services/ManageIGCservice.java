package org.bisag.ocbis.services;

import java.io.File;
import java.io.OutputStream;
import java.util.Base64;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.bisag.ocbis.models.ManageIGCcontacts;
import org.bisag.ocbis.models.ManageIGCphotos;
import org.bisag.ocbis.payloads.request.Report;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.ManageIGCcontactRepository;
import org.bisag.ocbis.repository.ManageIGCdocsRepository;
import org.bisag.ocbis.repository.ManageIGCphotosRepository;
import org.bisag.ocbis.utils.FileValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import io.micrometer.common.util.StringUtils;
import jakarta.transaction.Transactional;

@Service
public class ManageIGCservice {

    @Value("")
    String fileServerPath;

    @Autowired
    private ManageIGCcontactRepository contactsrepo;

    @Autowired
    private ManageIGCdocsRepository docsrepo;

    @Autowired
    private ManageIGCphotosRepository photosrepo;
    
    // 1. IGC Contact saving - website is taking as String ( link )

    @Transactional
    public <json> EncryptedResponse saveManageIGCcontacts(ManageIGCcontacts body) throws Exception{
        
        ManageIGCcontacts contactigc = new ManageIGCcontacts();
        try {
            contactigc.setSection(body.getSection());
            contactigc.setName(body.getName());
            contactigc.setIp(body.getIp());
            contactigc.setFax(body.getFax());
            contactigc.setDesignation(body.getDesignation());
            contactigc.setAddress(body.getAddress());
            contactigc.setEmailId(body.getEmailId());
            contactigc.setPhone(body.getWebsite());

            contactsrepo.save(contactigc);
            return new EncryptedResponse("IGC contact saved successfully ") ;
            
        } catch (Exception e) {
            return new EncryptedResponse("Error while saving IGC contact");
        }
    }

//----------------------------------------------------------

    
// 3. Saving IGC photographs ---------------------------------------------------------
    
    @Transactional
    public <json> EncryptedResponse saveManageIGCphotos(ManageIGCphotos body) throws Exception {
        
        UUID uuid = UUID.randomUUID();
        // Long id = body.getId();
        
        // Optional<ManageRecentDocs> savedObj = managerecentdocsrepo.findById(id);
        
        var photoPathTenth = fileServerPath + "photo" + uuid;
        
        File fileTenth = new File(photoPathTenth);
        
        byte[] picUpload = Base64.getDecoder().decode(body.getUploadPhoto().split(",")[1]);
        
        FileValidator.validateFileSize(picUpload, 5);
        
        // if (savedObj.isPresent()) {
            // try {
                // ManageRecentDocs existingDetails = savedObj.get();
                
                // try (OutputStream stream = FileUtils.openOutputStream(fileTenth))
                // {
                    // stream.write(docUpload);
                    // existingDetails.setUploadDocument(uuid.toString());
                    // }
                    // existingDetails.setId((body.getId()));
                    // existingDetails.setTitle(body.getTitle());
                    // existingDetails.setSecurityGroup(body.getSecurityGroup());
                    // existingDetails.setType(body.getType());
                    // existingDetails.setDocumentType(body.getDocumentType());
                    // existingDetails.setDescription(body.getDescription());
                    // existingDetails.setStatus(body.getStatus());
                    // existingDetails.setReceivedDate(body.getReceivedDate());
                    // existingDetails.setRegion(body.getRegion());
                    
                    // managerecentdocsrepo.save(existingDetails);
                    
                    // return new EncryptedResponse("Document uploaded");
                    // } catch (Exception e) {
                        // return new EncryptedResponse("some error occured");
                        // }
                        // } else {
                            try {
                                
                                ManageIGCphotos newIGCphotos = new ManageIGCphotos();
                                
                                newIGCphotos.setPhotoCaption((body.getPhotoCaption()));
                                newIGCphotos.setUploadType(body.getUploadType());
                                newIGCphotos.setReceivedDate(body.getReceivedDate());
                                newIGCphotos.setPhotoSource(body.getPhotoSource());
                                newIGCphotos.setUploadPhoto(body.getUploadPhoto());
                                
                                try (OutputStream stream = FileUtils.openOutputStream(fileTenth)) {
                stream.write(picUpload);
                newIGCphotos.setUploadPhoto(uuid.toString());
            }
            
            photosrepo.save(newIGCphotos);
            
            return new EncryptedResponse("Photos saved successfully");
            
        } catch (Exception e) {
            return new EncryptedResponse("Error saving Photo");
        }
    }

   

//---------------------------------------------------------

// Getting all the IGC Contacts 
public EncryptedResponse getAllIGCcontacts(Report body) throws Exception {

        var pageable = PageRequest.of(body.pagination().page(), body.pagination().size());
        var searchQuery = StringUtils.isBlank(body.search()) ? null : "%" + body.search() + "%";
        
        var customs = body.custom();
        String section = null ;
        String name = null ;
        String designation = null ;
        String address = null ;
        String ip = null ;
        String emailId = null ;
        String fax = null ;
        String phone = null ;
        String website = null ;
        
                System.out.println("custom: " + customs);

                if(body.custom() != null )
                {
              
                section = StringUtils.isNotBlank((String) customs.get("section"))
                                ? (String) customs.get("section")
                                : null;

                name = StringUtils.isNotBlank((String) customs.get("name"))
                                ? (String) customs.get("name")
                                : null;

                designation = StringUtils.isNotBlank((String) customs.get("designation"))
                                ? (String) customs.get("designation")
                                : null;

                address = StringUtils.isNotBlank((String) customs.get("address"))
                                ? (String) customs.get("address")
                                : null;

                emailId = StringUtils.isNotBlank((String) customs.get("emailId"))
                                ? (String) customs.get("emailId")
                                : null;

                ip = StringUtils.isNotBlank((String) customs.get("ip"))
                                ? (String) customs.get("ip")
                                : null;

                fax = StringUtils.isNotBlank((String) customs.get("fax"))
                                ? (String) customs.get("fax")
                                : null;

                phone = StringUtils.isNotBlank((String) customs.get("phone"))
                                ? (String) customs.get("phone")
                                : null;

                website = StringUtils.isNotBlank((String) customs.get("website"))
                                ? (String) customs.get("website")
                                : null;

          }
          var result = contactsrepo.findByFilters(searchQuery, section, name, designation,
          address, emailId, ip, fax, phone, website, pageable);
          return new EncryptedResponse(result);
    }      
    
}








    



