package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.QualitativeTargetsSubTask;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QualitativeTargetsSubTaskRepo extends JpaRepository<QualitativeTargetsSubTask, Long> {

     void deleteByFspFormId(Long fspFormId);
    List<QualitativeTargetsSubTask> findByFspFormId(Long fspFormId);

}