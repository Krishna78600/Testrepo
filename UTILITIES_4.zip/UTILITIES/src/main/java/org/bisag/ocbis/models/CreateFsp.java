package org.bisag.ocbis.models;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import java.time.ZonedDateTime;

@Entity
@Table(name = "save_created_fsp")
public class CreateFsp {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private Long userId;

  // proposal creation
  private String missionName;
  private String subMissionName;
  private String themeName;
  private String typeCode;
  private String commercialCode;
  private String regionName;
  private String stateUnitName;
  private String yearOfInitiation;
  private String yearOfCompletion;
  private String firstApprovingAuthority;
  private String fieldSeasonYear;
  private String proposalId;
  private ZonedDateTime CreateFspDate;
  private Long serialNo;

  // field season program details
  @Column(columnDefinition = "text")
  private String fspTitle;
  private String commodityName;
  private String fspStartDate;
  private String fspItemType;
  private String fspAreaType;
  private String fspDurationItem;
  private String fspItemFundedby;
  private String fspItemFundedbyName;
  private String fspItemRecommByCgpb;
  private String fspCgpbCommitieeList;
  private String fspItemRecommBySgpb;
  private String fspStateListBySgpb;
  private String fspKeyWords;
  private String fspStageOfInvestigation;
  private String fspCoOwner;
  private String fspCoOwnerStream;
  private String fspSpinOfOtherItem;
  private String fspSpinOfCategory;
  private String fspSpinOfFspItem;
  private String fspCoverdByGpm;
  private String fspCoverdByGcm;

  private String fspCoverdByNagmp;
  private String fspCollaborativeItem;
  private String fspCollaborativeAgencyBox;
  private String fspSponsoredItem;
  private String fspSponsoredAgencyBox;
  @Column(columnDefinition = "text")
  private String fspObjective;
  private ZonedDateTime fspDetailDate;
  private String backgroundInfo;

  // drill unit
  private String block;
  private String otherBlock;
  private Integer area;
  private Integer altitude;
  private String terrainConditions;
  private Integer nearestRailHeadName;
  private String railHeadDistance;
  private String waterSourceType;
  private String clearanceReceivedFrom;
  private String quantumOfDrilling;
  private Integer numberOfBoreholes;
  private Integer boreHolesAngle;
  private String boreHoleSpacing;
  private Integer boreSize;
  private Integer estimatedBoreholeDepthRange;
  private String pattern;
  private String patternText;
  private String coreRecoveryMineralised;
  private String coreRecoveryFormations;
  private String geophysicalBhlog;
  private String geophysicalBhlogNumber;
  private String typeOfDrilling;
  private String drillingBy;
  private String otherDrillingBy;
  private ZonedDateTime drillCreatedDate;

  // participating units
  private String puRegion;
  private String puStateUnit;
  private String puDivision;
  private String puPersonType;
  private List<String> puPersonnelStreams;
  private Integer puFullOrPartTime;
  private ZonedDateTime puCreatedDate;

  // Quant and Service Form
  private String decrepitationTestTarget;
  private String decrepitationTestWorkload;
  private String decrepitationTestCompleted;
  private String waterSampleTestingTarget;
  private String waterSampleTestingWorkload;
  private String waterSampleTestingCompleted;
  private String alterationZoneMappingTarget;
  private String alterationZoneMappingWorkload;
  private String alterationZoneMappingCompleted;
  private String bedRockSamplingTarget;
  private String bedRockSamplingWorkload;
  private String bedRockSamplingCompleted;
  private String bulkSampleingInTonnesTarget;
  private String bulkSampleingInTonnesWorkload;
  private String bulkSampleingInTonnesCompleted;
  private String channelGroupSamplingTarget;
  private String channelGroupWorkload;
  private String channelGroupCompleted;
  private String coalAndAssociatedRockSamplingTarget;
  private String coalAndAssociatedRockSamplingWorkload;
  private String coalAndAssociatedRockSamplingCompleted;
  private String airborneGeophysicalDataTarget;
  private String airborneGeophysicalDataWorkload;
  private String airborneGeophysicalDataCompleted;
  private String boreholesWithRealwcoTarget;
  private String boreholesWithRealwcoWorkload;
  private String boreholesWithRealwcoCompleted;
  private String coalfieldMapTarget;
  private String coalfieldMapWorkload;
  private String coalfieldMapCompleted;
  private String compilationOfGeoQuaMapTarget;
  private String compilationOfGeoQuaMapWorkload;
  private String compilationOfGeoQuaMapCompleted;
  private String aerialReconnaissanceandPGRSstudiesTarget;
  private String aerialReconnaissanceandPGRSstudiesWorkload;
  private String aerialReconnaissanceandPGRSstudiesCompleted;
  private String geologicalboreholesloggingTarget;
  private String geologicalboreholesloggingWorkload;
  private String geologicalboreholesloggingCompleted;
  private String glacialSnoutmonitoringTarget;
  private String glacialSnoutmonitoringWorkload;
  private String glacialSnoutmonitoringTargetCompleted;
  private String magnetotelluricsurveyTarget;
  private String magnetotelluricsurveyWorkload;
  private String magnetotelluricsurveyCompleted;
  private String geophysicalGravityTarget;
  private String geophysicalGravityWorkload;
  private String geophysicalGravityCompleted;
  private String geophysicalIpAreaTarget;
  private String geophysicalIpAreaWorkload;
  private String geophysicalIpAreaCompleted;
  private String bathymetricSurveySingleBeamTarget;
  private String bathymetricSurveySingleBeamWorkload;
  private String bathymetricSurveySingleBeamCompleted;
  private String beachProfilingTarget;
  private String beachProfilingWorkload;
  private String beachProfilingCompleted;
  private String mappingDetailedMappingTarget;
  private String mappingDetailedMappingWorkload;
  private String mappingDetailedMappingCompleted;
  private String mappingGeochemicalMappingTarget;
  private String mappingGeochemicalMappingWorkload;
  private String mappingGeochemicalMappingCompleted;
  private String mappingGeologicalMappingRemoteTarget;
  private String mappingGeologicalMappingRemoteWorkload;
  private String mappingGeologicalMappingRemoteCompleted;
  private String augerDrillingTarget;
  private String augerDrillingWorkload;
  private String augerDrillingCompleted;
  private String technologiclDrillingTarget;
  private String technologiclDrillingWorkload;
  private String technologiclDrillingCompleted;
  private String pittingandTrenchingTarget;
  private String pittingandTrenchingWorkload;
  private String pittingandTrenchingCompleted;
  private String standardPenetrationTestingTarget;
  private String standardPenetrationTestingWorkload;
  private String standardPenetrationTestingCompleted;
  private ZonedDateTime quantCreatedDate;
  // quant service form end

  // fsp course details tab start
  private String cuCourseId;
  private String cuCourseSubType;
  private String cuSelfNomination;
  private String cuCourseSubTypeOther;
  private String cuOrganisedFor;
  private String cuProposedStartDate;
  private String cuProposedEndDate;
  private String cuDurationOfCourse;
  private String cuBackgroundInfo;
  private String cuObjective;
  private String cuFundingAgencyName;
  private Integer cuMinimumNumberOfPeople;
  private Integer cuNumberOfCoreFaculty;
  private Integer cuNumberOfGuestFaculty;
  private Integer cuCourseCoordinatorEmployeeId;
  private Integer cuVehicleBudget;
  private Integer cuLogisticsBudget;
  private Integer cuOtherBudget;
  private String cuCourseContent;
  
  private ZonedDateTime courseCreatedDate;;
 // fsp course details tab end

  private ZonedDateTime vehicleCreatedDate;
  private ZonedDateTime operationCreatedDate;
  Integer stepsCompleted;

  @Transient
  Commodity[] commodity;

  @Transient
  String firstApprovingAuthorityName;

  @Transient
  String parentMissionCode;

  @Transient
  String subMissionCode;

  public String getFirstApprovingAuthorityName() {
    return firstApprovingAuthorityName;
  }

  public void setFirstApprovingAuthorityName(String firstApprovingAuthorityName) {
    this.firstApprovingAuthorityName = firstApprovingAuthorityName;
  }

  public String getParentMissionCode() {
    return parentMissionCode;
  }

  public void setParentMissionCode(String parentMissionCode) {
    this.parentMissionCode = parentMissionCode;
  }

  public String getSubMissionCode() {
    return subMissionCode;
  }

  public void setSubMissionCode(String subMissionCode) {
    this.subMissionCode = subMissionCode;
  }

  public Long getUserId() {
    return userId;
  }

  public void setUserId(Long userId) {
    this.userId = userId;
  }

  public String getFspObjective() {
    return fspObjective;
  }

  public void setFspObjective(String fspObjective) {
    this.fspObjective = fspObjective;
  }

  public String getFspCoverdByGpm() {
    return fspCoverdByGpm;
  }

  public void setFspCoverdByGpm(String fspCoverdByGpm) {
    this.fspCoverdByGpm = fspCoverdByGpm;
  }

  public String getFspCoverdByGcm() {
    return fspCoverdByGcm;
  }

  public void setFspCoverdByGcm(String fspCoverdByGcm) {
    this.fspCoverdByGcm = fspCoverdByGcm;
  }

  public String getFspCoverdByNagmp() {
    return fspCoverdByNagmp;
  }

  public void setFspCoverdByNagmp(String fspCoverdByNagmp) {
    this.fspCoverdByNagmp = fspCoverdByNagmp;
  }

  public Commodity[] getCommodity() {
    return commodity;
  }

  public void setCommodity(Commodity[] commodity) {
    this.commodity = commodity;
  }

  public String getBlock() {
    return block;
  }

  public void setBlock(String block) {
    this.block = block;
  }

  public Integer getArea() {
    return area;
  }

  public void setArea(Integer area) {
    this.area = area;
  }

  public Integer getAltitude() {
    return altitude;
  }

  public void setAltitude(Integer altitude) {
    this.altitude = altitude;
  }

  public String getTerrainConditions() {
    return terrainConditions;
  }

  public void setTerrainConditions(String terrainConditions) {
    this.terrainConditions = terrainConditions;
  }

  public Integer getNearestRailHeadName() {
    return nearestRailHeadName;
  }

  public void setNearestRailHeadName(Integer nearestRailHeadName) {
    this.nearestRailHeadName = nearestRailHeadName;
  }

  public String getRailHeadDistance() {
    return railHeadDistance;
  }

  public void setRailHeadDistance(String railHeadDistance) {
    this.railHeadDistance = railHeadDistance;
  }

  public String getWaterSourceType() {
    return waterSourceType;
  }

  public void setWaterSourceType(String waterSourceType) {
    this.waterSourceType = waterSourceType;
  }

  public String getClearanceReceivedFrom() {
    return clearanceReceivedFrom;
  }

  public void setClearanceReceivedFrom(String clearanceReceivedFrom) {
    this.clearanceReceivedFrom = clearanceReceivedFrom;
  }

  public String getQuantumOfDrilling() {
    return quantumOfDrilling;
  }

  public void setQuantumOfDrilling(String quantumOfDrilling) {
    this.quantumOfDrilling = quantumOfDrilling;
  }

  public Integer getNumberOfBoreholes() {
    return numberOfBoreholes;
  }

  public void setNumberOfBoreholes(Integer numberOfBoreholes) {
    this.numberOfBoreholes = numberOfBoreholes;
  }

  public Integer getBoreHolesAngle() {
    return boreHolesAngle;
  }

  public void setBoreHolesAngle(Integer boreHolesAngle) {
    this.boreHolesAngle = boreHolesAngle;
  }

  public String getBoreHoleSpacing() {
    return boreHoleSpacing;
  }

  public void setBoreHoleSpacing(String boreHoleSpacing) {
    this.boreHoleSpacing = boreHoleSpacing;
  }

  public Integer getBoreSize() {
    return boreSize;
  }

  public void setBoreSize(Integer boreSize) {
    this.boreSize = boreSize;
  }

  public Integer getEstimatedBoreholeDepthRange() {
    return estimatedBoreholeDepthRange;
  }

  public void setEstimatedBoreholeDepthRange(Integer estimatedBoreholeDepthRange) {
    this.estimatedBoreholeDepthRange = estimatedBoreholeDepthRange;
  }

  public String getPattern() {
    return pattern;
  }

  public void setPattern(String pattern) {
    this.pattern = pattern;
  }

  public String getCoreRecoveryMineralised() {
    return coreRecoveryMineralised;
  }

  public void setCoreRecoveryMineralised(String coreRecoveryMineralised) {
    this.coreRecoveryMineralised = coreRecoveryMineralised;
  }

  public String getCoreRecoveryFormations() {
    return coreRecoveryFormations;
  }

  public void setCoreRecoveryFormations(String coreRecoveryFormations) {
    this.coreRecoveryFormations = coreRecoveryFormations;
  }

  public String getGeophysicalBhlogNumber() {
    return geophysicalBhlogNumber;
  }

  public void setGeophysicalBhlogNumber(String geophysicalBhlogNumber) {
    this.geophysicalBhlogNumber = geophysicalBhlogNumber;
  }

  public String getTypeOfDrilling() {
    return typeOfDrilling;
  }

  public void setTypeOfDrilling(String typeOfDrilling) {
    this.typeOfDrilling = typeOfDrilling;
  }

  public String getPatternText() {
    return patternText;
  }

  public void setPatternText(String patternText) {
    this.patternText = patternText;
  }

  public String getOtherBlock() {
    return otherBlock;
  }

  public void setOtherBlock(String otherBlock) {
    this.otherBlock = otherBlock;
  }

  public String getGeophysicalBhlog() {
    return geophysicalBhlog;
  }

  public void setGeophysicalBhlog(String geophysicalBhlog) {
    this.geophysicalBhlog = geophysicalBhlog;
  }

  public Long getSerialNo() {
    return serialNo;
  }

  public void setSerialNo(Long serialNo) {
    this.serialNo = serialNo;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getMissionName() {
    return missionName;
  }

  public void setMissionName(String missionName) {
    this.missionName = missionName;
  }

  public String getSubMissionName() {
    return subMissionName;
  }

  public void setSubMissionName(String subMissionName) {
    this.subMissionName = subMissionName;
  }

  public String getThemeName() {
    return themeName;
  }

  public void setThemeName(String themeName) {
    this.themeName = themeName;
  }

  public String getTypeCode() {
    return typeCode;
  }

  public void setTypeCode(String typeCode) {
    this.typeCode = typeCode;
  }

  public String getCommercialCode() {
    return commercialCode;
  }

  public void setCommercialCode(String commercialCode) {
    this.commercialCode = commercialCode;
  }

  public String getRegionName() {
    return regionName;
  }

  public void setRegionName(String regionName) {
    this.regionName = regionName;
  }

  public String getStateUnitName() {
    return stateUnitName;
  }

  public void setStateUnitName(String stateUnitName) {
    this.stateUnitName = stateUnitName;
  }

  public String getYearOfInitiation() {
    return yearOfInitiation;
  }

  public void setYearOfInitiation(String yearOfInitiation) {
    this.yearOfInitiation = yearOfInitiation;
  }

  public String getYearOfCompletion() {
    return yearOfCompletion;
  }

  public void setYearOfCompletion(String yearOfCompletion) {
    this.yearOfCompletion = yearOfCompletion;
  }

  public String getFirstApprovingAuthority() {
    return firstApprovingAuthority;
  }

  public void setFirstApprovingAuthority(String firstApprovingAuthority) {
    this.firstApprovingAuthority = firstApprovingAuthority;
  }

  public String getFieldSeasonYear() {
    return fieldSeasonYear;
  }

  public void setFieldSeasonYear(String fieldSeasonYear) {
    this.fieldSeasonYear = fieldSeasonYear;
  }

  public String getProposalId() {
    return proposalId;
  }

  public void setProposalId(String proposalId) {
    this.proposalId = proposalId;
  }

  public String getFspTitle() {
    return fspTitle;
  }

  public void setFspTitle(String fspTitle) {
    this.fspTitle = fspTitle;
  }

  public String getCommodityName() {
    return commodityName;
  }

  public void setCommodityName(String commodityName) {
    this.commodityName = commodityName;
  }

  public String getFspStartDate() {
    return fspStartDate;
  }

  public void setFspStartDate(String fspStartDate) {
    this.fspStartDate = fspStartDate;
  }

  public String getFspItemType() {
    return fspItemType;
  }

  public void setFspItemType(String fspItemType) {
    this.fspItemType = fspItemType;
  }

  public String getFspAreaType() {
    return fspAreaType;
  }

  public void setFspAreaType(String fspAreaType) {
    this.fspAreaType = fspAreaType;
  }

  public String getFspDurationItem() {
    return fspDurationItem;
  }

  public void setFspDurationItem(String fspDurationItem) {
    this.fspDurationItem = fspDurationItem;
  }

  public String getFspItemFundedby() {
    return fspItemFundedby;
  }

  public void setFspItemFundedby(String fspItemFundedby) {
    this.fspItemFundedby = fspItemFundedby;
  }

  public String getFspItemFundedbyName() {
    return fspItemFundedbyName;
  }

  public void setFspItemFundedbyName(String fspItemFundedbyName) {
    this.fspItemFundedbyName = fspItemFundedbyName;
  }

  public String getFspItemRecommByCgpb() {
    return fspItemRecommByCgpb;
  }

  public void setFspItemRecommByCgpb(String fspItemRecommByCgpb) {
    this.fspItemRecommByCgpb = fspItemRecommByCgpb;
  }

  public String getFspCgpbCommitieeList() {
    return fspCgpbCommitieeList;
  }

  public void setFspCgpbCommitieeList(String fspCgpbCommitieeList) {
    this.fspCgpbCommitieeList = fspCgpbCommitieeList;
  }

  public String getFspItemRecommBySgpb() {
    return fspItemRecommBySgpb;
  }

  public void setFspItemRecommBySgpb(String fspItemRecommBySgpb) {
    this.fspItemRecommBySgpb = fspItemRecommBySgpb;
  }

  public String getFspStateListBySgpb() {
    return fspStateListBySgpb;
  }

  public void setFspStateListBySgpb(String fspStateListBySgpb) {
    this.fspStateListBySgpb = fspStateListBySgpb;
  }

  public String getFspKeyWords() {
    return fspKeyWords;
  }

  public void setFspKeyWords(String fspKeyWords) {
    this.fspKeyWords = fspKeyWords;
  }

  public String getFspStageOfInvestigation() {
    return fspStageOfInvestigation;
  }

  public void setFspStageOfInvestigation(String fspStageOfInvestigation) {
    this.fspStageOfInvestigation = fspStageOfInvestigation;
  }

  public String getFspCoOwner() {
    return fspCoOwner;
  }

  public void setFspCoOwner(String fspCoOwner) {
    this.fspCoOwner = fspCoOwner;
  }

  public String getFspCoOwnerStream() {
    return fspCoOwnerStream;
  }

  public void setFspCoOwnerStream(String fspCoOwnerStream) {
    this.fspCoOwnerStream = fspCoOwnerStream;
  }

  public String getFspSpinOfOtherItem() {
    return fspSpinOfOtherItem;
  }

  public void setFspSpinOfOtherItem(String fspSpinOfOtherItem) {
    this.fspSpinOfOtherItem = fspSpinOfOtherItem;
  }

  public String getFspSpinOfCategory() {
    return fspSpinOfCategory;
  }

  public void setFspSpinOfCategory(String fspSpinOfCategory) {
    this.fspSpinOfCategory = fspSpinOfCategory;
  }

  public String getFspSpinOfFspItem() {
    return fspSpinOfFspItem;
  }

  public void setFspSpinOfFspItem(String fspSpinOfFspItem) {
    this.fspSpinOfFspItem = fspSpinOfFspItem;
  }

  public String getFspCollaborativeItem() {
    return fspCollaborativeItem;
  }

  public void setFspCollaborativeItem(String fspCollaborativeItem) {
    this.fspCollaborativeItem = fspCollaborativeItem;
  }

  public String getFspCollaborativeAgencyBox() {
    return fspCollaborativeAgencyBox;
  }

  public void setFspCollaborativeAgencyBox(String fspCollaborativeAgencyBox) {
    this.fspCollaborativeAgencyBox = fspCollaborativeAgencyBox;
  }

  public String getFspSponsoredItem() {
    return fspSponsoredItem;
  }

  public void setFspSponsoredItem(String fspSponsoredItem) {
    this.fspSponsoredItem = fspSponsoredItem;
  }

  public String getFspSponsoredAgencyBox() {
    return fspSponsoredAgencyBox;
  }

  public void setFspSponsoredAgencyBox(String fspSponsoredAgencyBox) {
    this.fspSponsoredAgencyBox = fspSponsoredAgencyBox;
  }

  public Integer getStepsCompleted() {
    return stepsCompleted;
  }

  public void setStepsCompleted(Integer stepsCompleted) {
    this.stepsCompleted = stepsCompleted;
  }

  public String getDecrepitationTestTarget() {
    return decrepitationTestTarget;
  }

  public void setDecrepitationTestTarget(String decrepitationTestTarget) {
    this.decrepitationTestTarget = decrepitationTestTarget;
  }

  public String getDecrepitationTestWorkload() {
    return decrepitationTestWorkload;
  }

  public void setDecrepitationTestWorkload(String decrepitationTestWorkload) {
    this.decrepitationTestWorkload = decrepitationTestWorkload;
  }

  public String getDecrepitationTestCompleted() {
    return decrepitationTestCompleted;
  }

  public void setDecrepitationTestCompleted(String decrepitationTestCompleted) {
    this.decrepitationTestCompleted = decrepitationTestCompleted;
  }

  public String getWaterSampleTestingTarget() {
    return waterSampleTestingTarget;
  }

  public void setWaterSampleTestingTarget(String waterSampleTestingTarget) {
    this.waterSampleTestingTarget = waterSampleTestingTarget;
  }

  public String getWaterSampleTestingWorkload() {
    return waterSampleTestingWorkload;
  }

  public void setWaterSampleTestingWorkload(String waterSampleTestingWorkload) {
    this.waterSampleTestingWorkload = waterSampleTestingWorkload;
  }

  public String getWaterSampleTestingCompleted() {
    return waterSampleTestingCompleted;
  }

  public void setWaterSampleTestingCompleted(String waterSampleTestingCompleted) {
    this.waterSampleTestingCompleted = waterSampleTestingCompleted;
  }

  public String getAlterationZoneMappingTarget() {
    return alterationZoneMappingTarget;
  }

  public void setAlterationZoneMappingTarget(String alterationZoneMappingTarget) {
    this.alterationZoneMappingTarget = alterationZoneMappingTarget;
  }

  public String getAlterationZoneMappingWorkload() {
    return alterationZoneMappingWorkload;
  }

  public void setAlterationZoneMappingWorkload(String alterationZoneMappingWorkload) {
    this.alterationZoneMappingWorkload = alterationZoneMappingWorkload;
  }

  public String getAlterationZoneMappingCompleted() {
    return alterationZoneMappingCompleted;
  }

  public void setAlterationZoneMappingCompleted(String alterationZoneMappingCompleted) {
    this.alterationZoneMappingCompleted = alterationZoneMappingCompleted;
  }

  public String getBedRockSamplingTarget() {
    return bedRockSamplingTarget;
  }

  public void setBedRockSamplingTarget(String bedRockSamplingTarget) {
    this.bedRockSamplingTarget = bedRockSamplingTarget;
  }

  public String getBedRockSamplingWorkload() {
    return bedRockSamplingWorkload;
  }

  public void setBedRockSamplingWorkload(String bedRockSamplingWorkload) {
    this.bedRockSamplingWorkload = bedRockSamplingWorkload;
  }

  public String getBedRockSamplingCompleted() {
    return bedRockSamplingCompleted;
  }

  public void setBedRockSamplingCompleted(String bedRockSamplingCompleted) {
    this.bedRockSamplingCompleted = bedRockSamplingCompleted;
  }

  public String getBulkSampleingInTonnesTarget() {
    return bulkSampleingInTonnesTarget;
  }

  public void setBulkSampleingInTonnesTarget(String bulkSampleingInTonnesTarget) {
    this.bulkSampleingInTonnesTarget = bulkSampleingInTonnesTarget;
  }

  public String getBulkSampleingInTonnesWorkload() {
    return bulkSampleingInTonnesWorkload;
  }

  public void setBulkSampleingInTonnesWorkload(String bulkSampleingInTonnesWorkload) {
    this.bulkSampleingInTonnesWorkload = bulkSampleingInTonnesWorkload;
  }

  public String getBulkSampleingInTonnesCompleted() {
    return bulkSampleingInTonnesCompleted;
  }

  public void setBulkSampleingInTonnesCompleted(String bulkSampleingInTonnesCompleted) {
    this.bulkSampleingInTonnesCompleted = bulkSampleingInTonnesCompleted;
  }

  public String getChannelGroupSamplingTarget() {
    return channelGroupSamplingTarget;
  }

  public void setChannelGroupSamplingTarget(String channelGroupSamplingTarget) {
    this.channelGroupSamplingTarget = channelGroupSamplingTarget;
  }

  public String getChannelGroupWorkload() {
    return channelGroupWorkload;
  }

  public void setChannelGroupWorkload(String channelGroupWorkload) {
    this.channelGroupWorkload = channelGroupWorkload;
  }

  public String getChannelGroupCompleted() {
    return channelGroupCompleted;
  }

  public void setChannelGroupCompleted(String channelGroupCompleted) {
    this.channelGroupCompleted = channelGroupCompleted;
  }

  public String getCoalAndAssociatedRockSamplingTarget() {
    return coalAndAssociatedRockSamplingTarget;
  }

  public void setCoalAndAssociatedRockSamplingTarget(String coalAndAssociatedRockSamplingTarget) {
    this.coalAndAssociatedRockSamplingTarget = coalAndAssociatedRockSamplingTarget;
  }

  public String getCoalAndAssociatedRockSamplingWorkload() {
    return coalAndAssociatedRockSamplingWorkload;
  }

  public void setCoalAndAssociatedRockSamplingWorkload(String coalAndAssociatedRockSamplingWorkload) {
    this.coalAndAssociatedRockSamplingWorkload = coalAndAssociatedRockSamplingWorkload;
  }

  public String getCoalAndAssociatedRockSamplingCompleted() {
    return coalAndAssociatedRockSamplingCompleted;
  }

  public void setCoalAndAssociatedRockSamplingCompleted(String coalAndAssociatedRockSamplingCompleted) {
    this.coalAndAssociatedRockSamplingCompleted = coalAndAssociatedRockSamplingCompleted;
  }

  public String getAirborneGeophysicalDataTarget() {
    return airborneGeophysicalDataTarget;
  }

  public void setAirborneGeophysicalDataTarget(String airborneGeophysicalDataTarget) {
    this.airborneGeophysicalDataTarget = airborneGeophysicalDataTarget;
  }

  public String getAirborneGeophysicalDataWorkload() {
    return airborneGeophysicalDataWorkload;
  }

  public void setAirborneGeophysicalDataWorkload(String airborneGeophysicalDataWorkload) {
    this.airborneGeophysicalDataWorkload = airborneGeophysicalDataWorkload;
  }

  public String getAirborneGeophysicalDataCompleted() {
    return airborneGeophysicalDataCompleted;
  }

  public void setAirborneGeophysicalDataCompleted(String airborneGeophysicalDataCompleted) {
    this.airborneGeophysicalDataCompleted = airborneGeophysicalDataCompleted;
  }

  public String getBoreholesWithRealwcoTarget() {
    return boreholesWithRealwcoTarget;
  }

  public void setBoreholesWithRealwcoTarget(String boreholesWithRealwcoTarget) {
    this.boreholesWithRealwcoTarget = boreholesWithRealwcoTarget;
  }

  public String getBoreholesWithRealwcoWorkload() {
    return boreholesWithRealwcoWorkload;
  }

  public void setBoreholesWithRealwcoWorkload(String boreholesWithRealwcoWorkload) {
    this.boreholesWithRealwcoWorkload = boreholesWithRealwcoWorkload;
  }

  public String getBoreholesWithRealwcoCompleted() {
    return boreholesWithRealwcoCompleted;
  }

  public void setBoreholesWithRealwcoCompleted(String boreholesWithRealwcoCompleted) {
    this.boreholesWithRealwcoCompleted = boreholesWithRealwcoCompleted;
  }

  public String getCoalfieldMapTarget() {
    return coalfieldMapTarget;
  }

  public void setCoalfieldMapTarget(String coalfieldMapTarget) {
    this.coalfieldMapTarget = coalfieldMapTarget;
  }

  public String getCoalfieldMapWorkload() {
    return coalfieldMapWorkload;
  }

  public void setCoalfieldMapWorkload(String coalfieldMapWorkload) {
    this.coalfieldMapWorkload = coalfieldMapWorkload;
  }

  public String getCoalfieldMapCompleted() {
    return coalfieldMapCompleted;
  }

  public void setCoalfieldMapCompleted(String coalfieldMapCompleted) {
    this.coalfieldMapCompleted = coalfieldMapCompleted;
  }

  public String getCompilationOfGeoQuaMapTarget() {
    return compilationOfGeoQuaMapTarget;
  }

  public void setCompilationOfGeoQuaMapTarget(String compilationOfGeoQuaMapTarget) {
    this.compilationOfGeoQuaMapTarget = compilationOfGeoQuaMapTarget;
  }

  public String getCompilationOfGeoQuaMapWorkload() {
    return compilationOfGeoQuaMapWorkload;
  }

  public void setCompilationOfGeoQuaMapWorkload(String compilationOfGeoQuaMapWorkload) {
    this.compilationOfGeoQuaMapWorkload = compilationOfGeoQuaMapWorkload;
  }

  public String getCompilationOfGeoQuaMapCompleted() {
    return compilationOfGeoQuaMapCompleted;
  }

  public void setCompilationOfGeoQuaMapCompleted(String compilationOfGeoQuaMapCompleted) {
    this.compilationOfGeoQuaMapCompleted = compilationOfGeoQuaMapCompleted;
  }

  public String getGeologicalboreholesloggingTarget() {
    return geologicalboreholesloggingTarget;
  }

  public void setGeologicalboreholesloggingTarget(String geologicalboreholesloggingTarget) {
    this.geologicalboreholesloggingTarget = geologicalboreholesloggingTarget;
  }

  public String getGeologicalboreholesloggingWorkload() {
    return geologicalboreholesloggingWorkload;
  }

  public void setGeologicalboreholesloggingWorkload(String geologicalboreholesloggingWorkload) {
    this.geologicalboreholesloggingWorkload = geologicalboreholesloggingWorkload;
  }

  public String getGeologicalboreholesloggingCompleted() {
    return geologicalboreholesloggingCompleted;
  }

  public void setGeologicalboreholesloggingCompleted(String geologicalboreholesloggingCompleted) {
    this.geologicalboreholesloggingCompleted = geologicalboreholesloggingCompleted;
  }

  public String getBathymetricSurveySingleBeamTarget() {
    return bathymetricSurveySingleBeamTarget;
  }

  public void setBathymetricSurveySingleBeamTarget(String bathymetricSurveySingleBeamTarget) {
    this.bathymetricSurveySingleBeamTarget = bathymetricSurveySingleBeamTarget;
  }

  public String getBathymetricSurveySingleBeamWorkload() {
    return bathymetricSurveySingleBeamWorkload;
  }

  public void setBathymetricSurveySingleBeamWorkload(String bathymetricSurveySingleBeamWorkload) {
    this.bathymetricSurveySingleBeamWorkload = bathymetricSurveySingleBeamWorkload;
  }

  public String getBathymetricSurveySingleBeamCompleted() {
    return bathymetricSurveySingleBeamCompleted;
  }

  public void setBathymetricSurveySingleBeamCompleted(String bathymetricSurveySingleBeamCompleted) {
    this.bathymetricSurveySingleBeamCompleted = bathymetricSurveySingleBeamCompleted;
  }

  public String getBeachProfilingTarget() {
    return beachProfilingTarget;
  }

  public void setBeachProfilingTarget(String beachProfilingTarget) {
    this.beachProfilingTarget = beachProfilingTarget;
  }

  public String getBeachProfilingWorkload() {
    return beachProfilingWorkload;
  }

  public void setBeachProfilingWorkload(String beachProfilingWorkload) {
    this.beachProfilingWorkload = beachProfilingWorkload;
  }

  public String getBeachProfilingCompleted() {
    return beachProfilingCompleted;
  }

  public void setBeachProfilingCompleted(String beachProfilingCompleted) {
    this.beachProfilingCompleted = beachProfilingCompleted;
  }

  public String getMappingDetailedMappingTarget() {
    return mappingDetailedMappingTarget;
  }

  public void setMappingDetailedMappingTarget(String mappingDetailedMappingTarget) {
    this.mappingDetailedMappingTarget = mappingDetailedMappingTarget;
  }

  public String getMappingDetailedMappingWorkload() {
    return mappingDetailedMappingWorkload;
  }

  public void setMappingDetailedMappingWorkload(String mappingDetailedMappingWorkload) {
    this.mappingDetailedMappingWorkload = mappingDetailedMappingWorkload;
  }

  public String getMappingDetailedMappingCompleted() {
    return mappingDetailedMappingCompleted;
  }

  public void setMappingDetailedMappingCompleted(String mappingDetailedMappingCompleted) {
    this.mappingDetailedMappingCompleted = mappingDetailedMappingCompleted;
  }

  public String getMappingGeochemicalMappingTarget() {
    return mappingGeochemicalMappingTarget;
  }

  public void setMappingGeochemicalMappingTarget(String mappingGeochemicalMappingTarget) {
    this.mappingGeochemicalMappingTarget = mappingGeochemicalMappingTarget;
  }

  public String getMappingGeochemicalMappingWorkload() {
    return mappingGeochemicalMappingWorkload;
  }

  public void setMappingGeochemicalMappingWorkload(String mappingGeochemicalMappingWorkload) {
    this.mappingGeochemicalMappingWorkload = mappingGeochemicalMappingWorkload;
  }

  public String getMappingGeochemicalMappingCompleted() {
    return mappingGeochemicalMappingCompleted;
  }

  public void setMappingGeochemicalMappingCompleted(String mappingGeochemicalMappingCompleted) {
    this.mappingGeochemicalMappingCompleted = mappingGeochemicalMappingCompleted;
  }

  public String getAugerDrillingTarget() {
    return augerDrillingTarget;
  }

  public void setAugerDrillingTarget(String augerDrillingTarget) {
    this.augerDrillingTarget = augerDrillingTarget;
  }

  public String getAugerDrillingWorkload() {
    return augerDrillingWorkload;
  }

  public void setAugerDrillingWorkload(String augerDrillingWorkload) {
    this.augerDrillingWorkload = augerDrillingWorkload;
  }

  public String getAugerDrillingCompleted() {
    return augerDrillingCompleted;
  }

  public void setAugerDrillingCompleted(String augerDrillingCompleted) {
    this.augerDrillingCompleted = augerDrillingCompleted;
  }

  public String getTechnologiclDrillingTarget() {
    return technologiclDrillingTarget;
  }

  public void setTechnologiclDrillingTarget(String technologiclDrillingTarget) {
    this.technologiclDrillingTarget = technologiclDrillingTarget;
  }

  public String getTechnologiclDrillingWorkload() {
    return technologiclDrillingWorkload;
  }

  public void setTechnologiclDrillingWorkload(String technologiclDrillingWorkload) {
    this.technologiclDrillingWorkload = technologiclDrillingWorkload;
  }

  public String getTechnologiclDrillingCompleted() {
    return technologiclDrillingCompleted;
  }

  public void setTechnologiclDrillingCompleted(String technologiclDrillingCompleted) {
    this.technologiclDrillingCompleted = technologiclDrillingCompleted;
  }

  public String getAerialReconnaissanceandPGRSstudiesTarget() {
    return aerialReconnaissanceandPGRSstudiesTarget;
  }

  public void setAerialReconnaissanceandPGRSstudiesTarget(String aerialReconnaissanceandPGRSstudiesTarget) {
    this.aerialReconnaissanceandPGRSstudiesTarget = aerialReconnaissanceandPGRSstudiesTarget;
  }

  public String getAerialReconnaissanceandPGRSstudiesWorkload() {
    return aerialReconnaissanceandPGRSstudiesWorkload;
  }

  public void setAerialReconnaissanceandPGRSstudiesWorkload(String aerialReconnaissanceandPGRSstudiesWorkload) {
    this.aerialReconnaissanceandPGRSstudiesWorkload = aerialReconnaissanceandPGRSstudiesWorkload;
  }

  public String getAerialReconnaissanceandPGRSstudiesCompleted() {
    return aerialReconnaissanceandPGRSstudiesCompleted;
  }

  public void setAerialReconnaissanceandPGRSstudiesCompleted(String aerialReconnaissanceandPGRSstudiesCompleted) {
    this.aerialReconnaissanceandPGRSstudiesCompleted = aerialReconnaissanceandPGRSstudiesCompleted;
  }

  public String getGlacialSnoutmonitoringTarget() {
    return glacialSnoutmonitoringTarget;
  }

  public void setGlacialSnoutmonitoringTarget(String glacialSnoutmonitoringTarget) {
    this.glacialSnoutmonitoringTarget = glacialSnoutmonitoringTarget;
  }

  public String getGlacialSnoutmonitoringWorkload() {
    return glacialSnoutmonitoringWorkload;
  }

  public void setGlacialSnoutmonitoringWorkload(String glacialSnoutmonitoringWorkload) {
    this.glacialSnoutmonitoringWorkload = glacialSnoutmonitoringWorkload;
  }

  public String getGlacialSnoutmonitoringTargetCompleted() {
    return glacialSnoutmonitoringTargetCompleted;
  }

  public void setGlacialSnoutmonitoringTargetCompleted(String glacialSnoutmonitoringTargetCompleted) {
    this.glacialSnoutmonitoringTargetCompleted = glacialSnoutmonitoringTargetCompleted;
  }

  public String getMagnetotelluricsurveyTarget() {
    return magnetotelluricsurveyTarget;
  }

  public void setMagnetotelluricsurveyTarget(String magnetotelluricsurveyTarget) {
    this.magnetotelluricsurveyTarget = magnetotelluricsurveyTarget;
  }

  public String getMagnetotelluricsurveyWorkload() {
    return magnetotelluricsurveyWorkload;
  }

  public void setMagnetotelluricsurveyWorkload(String magnetotelluricsurveyWorkload) {
    this.magnetotelluricsurveyWorkload = magnetotelluricsurveyWorkload;
  }

  public String getMagnetotelluricsurveyCompleted() {
    return magnetotelluricsurveyCompleted;
  }

  public void setMagnetotelluricsurveyCompleted(String magnetotelluricsurveyCompleted) {
    this.magnetotelluricsurveyCompleted = magnetotelluricsurveyCompleted;
  }

  public String getGeophysicalGravityTarget() {
    return geophysicalGravityTarget;
  }

  public void setGeophysicalGravityTarget(String geophysicalGravityTarget) {
    this.geophysicalGravityTarget = geophysicalGravityTarget;
  }

  public String getGeophysicalGravityWorkload() {
    return geophysicalGravityWorkload;
  }

  public void setGeophysicalGravityWorkload(String geophysicalGravityWorkload) {
    this.geophysicalGravityWorkload = geophysicalGravityWorkload;
  }

  public String getGeophysicalGravityCompleted() {
    return geophysicalGravityCompleted;
  }

  public void setGeophysicalGravityCompleted(String geophysicalGravityCompleted) {
    this.geophysicalGravityCompleted = geophysicalGravityCompleted;
  }

  public String getGeophysicalIpAreaTarget() {
    return geophysicalIpAreaTarget;
  }

  public void setGeophysicalIpAreaTarget(String geophysicalIpAreaTarget) {
    this.geophysicalIpAreaTarget = geophysicalIpAreaTarget;
  }

  public String getGeophysicalIpAreaWorkload() {
    return geophysicalIpAreaWorkload;
  }

  public void setGeophysicalIpAreaWorkload(String geophysicalIpAreaWorkload) {
    this.geophysicalIpAreaWorkload = geophysicalIpAreaWorkload;
  }

  public String getGeophysicalIpAreaCompleted() {
    return geophysicalIpAreaCompleted;
  }

  public void setGeophysicalIpAreaCompleted(String geophysicalIpAreaCompleted) {
    this.geophysicalIpAreaCompleted = geophysicalIpAreaCompleted;
  }

  public String getPittingandTrenchingTarget() {
    return pittingandTrenchingTarget;
  }

  public void setPittingandTrenchingTarget(String pittingandTrenchingTarget) {
    this.pittingandTrenchingTarget = pittingandTrenchingTarget;
  }

  public String getPittingandTrenchingWorkload() {
    return pittingandTrenchingWorkload;
  }

  public void setPittingandTrenchingWorkload(String pittingandTrenchingWorkload) {
    this.pittingandTrenchingWorkload = pittingandTrenchingWorkload;
  }

  public String getPittingandTrenchingCompleted() {
    return pittingandTrenchingCompleted;
  }

  public void setPittingandTrenchingCompleted(String pittingandTrenchingCompleted) {
    this.pittingandTrenchingCompleted = pittingandTrenchingCompleted;
  }

  public String getStandardPenetrationTestingTarget() {
    return standardPenetrationTestingTarget;
  }

  public void setStandardPenetrationTestingTarget(String standardPenetrationTestingTarget) {
    this.standardPenetrationTestingTarget = standardPenetrationTestingTarget;
  }

  public String getStandardPenetrationTestingWorkload() {
    return standardPenetrationTestingWorkload;
  }

  public void setStandardPenetrationTestingWorkload(String standardPenetrationTestingWorkload) {
    this.standardPenetrationTestingWorkload = standardPenetrationTestingWorkload;
  }

  public String getStandardPenetrationTestingCompleted() {
    return standardPenetrationTestingCompleted;
  }

  public void setStandardPenetrationTestingCompleted(String standardPenetrationTestingCompleted) {
    this.standardPenetrationTestingCompleted = standardPenetrationTestingCompleted;
  }

  public String getMappingGeologicalMappingRemoteTarget() {
    return mappingGeologicalMappingRemoteTarget;
  }

  public void setMappingGeologicalMappingRemoteTarget(String mappingGeologicalMappingRemoteTarget) {
    this.mappingGeologicalMappingRemoteTarget = mappingGeologicalMappingRemoteTarget;
  }

  public String getMappingGeologicalMappingRemoteWorkload() {
    return mappingGeologicalMappingRemoteWorkload;
  }

  public void setMappingGeologicalMappingRemoteWorkload(String mappingGeologicalMappingRemoteWorkload) {
    this.mappingGeologicalMappingRemoteWorkload = mappingGeologicalMappingRemoteWorkload;
  }

  public String getMappingGeologicalMappingRemoteCompleted() {
    return mappingGeologicalMappingRemoteCompleted;
  }

  public void setMappingGeologicalMappingRemoteCompleted(String mappingGeologicalMappingRemoteCompleted) {
    this.mappingGeologicalMappingRemoteCompleted = mappingGeologicalMappingRemoteCompleted;
  }

  public String getPuRegion() {
    return puRegion;
  }

  public void setPuRegion(String puRegion) {
    this.puRegion = puRegion;
  }

  public String getPuStateUnit() {
    return puStateUnit;
  }

  public void setPuStateUnit(String puStateUnit) {
    this.puStateUnit = puStateUnit;
  }

  public String getPuDivision() {
    return puDivision;
  }

  public void setPuDivision(String puDivision) {
    this.puDivision = puDivision;
  }

  public List<String> getPuPersonnelStreams() {
    return puPersonnelStreams;
  }

  public void setPuPersonnelStreams(List<String> puPersonnelStreams) {
    this.puPersonnelStreams = puPersonnelStreams;
  }

  public ZonedDateTime getCreateFspDate() {
    return CreateFspDate;
  }

  public void setCreateFspDate(ZonedDateTime createFspDate) {
    CreateFspDate = createFspDate;
  }

  public ZonedDateTime getFspDetailDate() {
    return fspDetailDate;
  }

  public void setFspDetailDate(ZonedDateTime fspDetailDate) {
    this.fspDetailDate = fspDetailDate;
  }

  public ZonedDateTime getPuCreatedDate() {
    return puCreatedDate;
  }

  public void setPuCreatedDate(ZonedDateTime puCreatedDate) {
    this.puCreatedDate = puCreatedDate;
  }

  public ZonedDateTime getQuantCreatedDate() {
    return quantCreatedDate;
  }

  public void setQuantCreatedDate(ZonedDateTime quantCreatedDate) {
    this.quantCreatedDate = quantCreatedDate;
  }

  public ZonedDateTime getDrillCreatedDate() {
    return drillCreatedDate;
  }

  public void setDrillCreatedDate(ZonedDateTime drillCreatedDate) {
    this.drillCreatedDate = drillCreatedDate;
  }

  public ZonedDateTime getVehicleCreatedDate() {
    return vehicleCreatedDate;
  }

  public void setVehicleCreatedDate(ZonedDateTime vehicleCreatedDate) {
    this.vehicleCreatedDate = vehicleCreatedDate;
  }

  public ZonedDateTime getOperationCreatedDate() {
    return operationCreatedDate;
  }

  public void setOperationCreatedDate(ZonedDateTime operationCreatedDate) {
    this.operationCreatedDate = operationCreatedDate;
  }

  public Integer getPuFullOrPartTime() {
    return puFullOrPartTime;
  }

  public void setPuFullOrPartTime(Integer puFullOrPartTime) {
    this.puFullOrPartTime = puFullOrPartTime;
  }

  public String getDrillingBy() {
    return drillingBy;
  }

  public void setDrillingBy(String drillingBy) {
    this.drillingBy = drillingBy;
  }

  public String getPuPersonType() {
    return puPersonType;
  }

  public void setPuPersonType(String puPersonType) {
    this.puPersonType = puPersonType;
  }

  public String getOtherDrillingBy() {
    return otherDrillingBy;
  }

  public void setOtherDrillingBy(String otherDrillingBy) {
    this.otherDrillingBy = otherDrillingBy;
  }

  public String getBackgroundInfo() {
    return backgroundInfo;
  }

  public void setBackgroundInfo(String backgroundInfo) {
    this.backgroundInfo = backgroundInfo;
  }

  public String getCuCourseId() {
    return cuCourseId;
  }

  public void setCuCourseId(String cuCourseId) {
    this.cuCourseId = cuCourseId;
  }

  public String getCuCourseSubType() {
    return cuCourseSubType;
  }

  public void setCuCourseSubType(String cuCourseSubType) {
    this.cuCourseSubType = cuCourseSubType;
  }

  public String getCuSelfNomination() {
    return cuSelfNomination;
  }

  public void setCuSelfNomination(String cuSelfNomination) {
    this.cuSelfNomination = cuSelfNomination;
  }

  public String getCuCourseSubTypeOther() {
    return cuCourseSubTypeOther;
  }

  public void setCuCourseSubTypeOther(String cuCourseSubTypeOther) {
    this.cuCourseSubTypeOther = cuCourseSubTypeOther;
  }

  public String getCuOrganisedFor() {
    return cuOrganisedFor;
  }

  public void setCuOrganisedFor(String cuOrganisedFor) {
    this.cuOrganisedFor = cuOrganisedFor;
  }

  public String getCuProposedStartDate() {
    return cuProposedStartDate;
  }

  public void setCuProposedStartDate(String cuProposedStartDate) {
    this.cuProposedStartDate = cuProposedStartDate;
  }

  public String getCuProposedEndDate() {
    return cuProposedEndDate;
  }

  public void setCuProposedEndDate(String cuProposedEndDate) {
    this.cuProposedEndDate = cuProposedEndDate;
  }

  public String getCuDurationOfCourse() {
    return cuDurationOfCourse;
  }

  public void setCuDurationOfCourse(String cuDurationOfCourse) {
    this.cuDurationOfCourse = cuDurationOfCourse;
  }

  public String getCuBackgroundInfo() {
    return cuBackgroundInfo;
  }

  public void setCuBackgroundInfo(String cuBackgroundInfo) {
    this.cuBackgroundInfo = cuBackgroundInfo;
  }

  public String getCuObjective() {
    return cuObjective;
  }

  public void setCuObjective(String cuObjective) {
    this.cuObjective = cuObjective;
  }

  public String getCuFundingAgencyName() {
    return cuFundingAgencyName;
  }

  public void setCuFundingAgencyName(String cuFundingAgencyName) {
    this.cuFundingAgencyName = cuFundingAgencyName;
  }

  public Integer getCuMinimumNumberOfPeople() {
    return cuMinimumNumberOfPeople;
  }

  public void setCuMinimumNumberOfPeople(Integer cuMinimumNumberOfPeople) {
    this.cuMinimumNumberOfPeople = cuMinimumNumberOfPeople;
  }

  public Integer getCuNumberOfCoreFaculty() {
    return cuNumberOfCoreFaculty;
  }

  public void setCuNumberOfCoreFaculty(Integer cuNumberOfCoreFaculty) {
    this.cuNumberOfCoreFaculty = cuNumberOfCoreFaculty;
  }

  public Integer getCuNumberOfGuestFaculty() {
    return cuNumberOfGuestFaculty;
  }

  public void setCuNumberOfGuestFaculty(Integer cuNumberOfGuestFaculty) {
    this.cuNumberOfGuestFaculty = cuNumberOfGuestFaculty;
  }

  public Integer getCuCourseCoordinatorEmployeeId() {
    return cuCourseCoordinatorEmployeeId;
  }

  public void setCuCourseCoordinatorEmployeeId(Integer cuCourseCoordinatorEmployeeId) {
    this.cuCourseCoordinatorEmployeeId = cuCourseCoordinatorEmployeeId;
  }

  public Integer getCuVehicleBudget() {
    return cuVehicleBudget;
  }

  public void setCuVehicleBudget(Integer cuVehicleBudget) {
    this.cuVehicleBudget = cuVehicleBudget;
  }

  public Integer getCuLogisticsBudget() {
    return cuLogisticsBudget;
  }

  public void setCuLogisticsBudget(Integer cuLogisticsBudget) {
    this.cuLogisticsBudget = cuLogisticsBudget;
  }

  public Integer getCuOtherBudget() {
    return cuOtherBudget;
  }

  public void setCuOtherBudget(Integer cuOtherBudget) {
    this.cuOtherBudget = cuOtherBudget;
  }

  public String getCuCourseContent() {
    return cuCourseContent;
  }

  public void setCuCourseContent(String cuCourseContent) {
    this.cuCourseContent = cuCourseContent;
  }

  public ZonedDateTime getCourseCreatedDate() {
    return courseCreatedDate;
  }

  public void setCourseCreatedDate(ZonedDateTime courseCreatedDate) {
    this.courseCreatedDate = courseCreatedDate;
  }

  
}
