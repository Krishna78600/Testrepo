package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.ManageIGCcontacts;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ManageIGCcontactRepository extends JpaRepository<ManageIGCcontacts, Long>{

    Object findByFilters(Object searchQuery, String section, String name, String designation, String address,
            String emailId, String ip, String fax, String phone, String website, Object pageable);

}
