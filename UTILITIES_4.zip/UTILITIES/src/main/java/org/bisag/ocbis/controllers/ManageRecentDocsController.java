package org.bisag.ocbis.controllers;

import java.time.ZonedDateTime;

import org.bisag.ocbis.models.ManageRecentDocs;
import org.bisag.ocbis.models.User;
import org.bisag.ocbis.payloads.request.EncryptedRequest;
import org.bisag.ocbis.payloads.request.Report;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.ManageRecentDocsRepository;
import org.bisag.ocbis.services.ManageRecentDocsService;
import org.bisag.ocbis.utils.Json;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.micrometer.common.util.StringUtils;
import jakarta.servlet.http.HttpServletRequest;

@RestController
@CrossOrigin("*")
@RequestMapping("/fileupload")
public class ManageRecentDocsController{

    @Autowired
    private ManageRecentDocsRepository manageRecentDocsRepository;
    
    @Autowired
    private ManageRecentDocsService managerecentdocservice;
    
    // 1- Save/ / Edit user details and uploading recent docs 
    
    @PostMapping("/save-recent-docs")
    public <json> EncryptedResponse SaveRecentDocs(@RequestBody EncryptedRequest req , HttpServletRequest request , @AuthenticationPrincipal User user ) throws Exception 
    {
        try {
            //ManageRecentDocs body = req.bodyAs(ManageRecentDocs.class);
            var body = Json.deserialize(ManageRecentDocs.class, req.getData());
            managerecentdocservice.saveRecentDocs(body);
            return new EncryptedResponse("saved");
             
        } catch (Exception e) {
            return new EncryptedResponse("Document not saved ");
        } 
    }
    
    
    // 2 -  Getting Doc uploaded by me ---------------------------------------------------------
    
    @PostMapping("/get-doc-upload-by-me")
        public EncryptedResponse getDocUploadByMe(@RequestBody EncryptedRequest req) throws Exception 
        {
                var reportReq = Json.deserialize(Report.class, req.getData());
                //var pagination = reportReq.pagination();
                var pageable = PageRequest.of(reportReq.pagination().page(), reportReq.pagination().size());

                var searchQuery = StringUtils.isBlank(reportReq.search()) ? null : "%" + reportReq.search() + "%";

                var custom = reportReq.custom();
                String title = null ;
                String documentType = null ;
                String type = null ;


                System.out.println("custom: " + custom);

                title = StringUtils.isNotBlank((String) custom.get("title"))
                                ? (String) custom.get("title")
                                : null;
                documentType = StringUtils.isNotBlank((String) custom.get("documentType"))
                                ? (String) custom.get("documentType")
                                : null;
                type = StringUtils.isNotBlank((String) custom.get("type"))
                                ? (String) custom.get("type")
                                : null;
                
                ZonedDateTime receivedDateFrom = (ZonedDateTime) custom.get("receivedDateFrom");
                ZonedDateTime receivedDateTo = (ZonedDateTime) custom.get("receivedDateTo");
                
                var result = manageRecentDocsRepository.findByFilters(searchQuery, title, documentType, type, pageable);

                return new EncryptedResponse(result);
        }


    // Delete ------------------------------------------------------------------------------------
    
    @DeleteMapping("/delete_doc-byid")
    public ResponseEntity<EncryptedResponse> deleteDocById(@RequestBody EncryptedRequest req ) throws Exception {
        
        var body = Json.deserialize(ManageRecentDocs.class , req.getData());

        boolean isDeleted = managerecentdocservice.deleteDocById(body.getId());

        if(isDeleted)
            return ResponseEntity.ok(new EncryptedResponse("Doc and Details Deleted "));
        else 
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new EncryptedResponse("Doc not found "));
    }
    
}
