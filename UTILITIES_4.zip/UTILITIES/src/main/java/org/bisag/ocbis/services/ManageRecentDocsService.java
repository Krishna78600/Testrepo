package org.bisag.ocbis.services;

import java.io.File;
import java.io.OutputStream;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.bisag.ocbis.models.ManageRecentDocs;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.repository.ManageRecentDocsRepository;
import org.bisag.ocbis.utils.FileValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

import jakarta.transaction.Transactional;

@CrossOrigin("*")
@Service
public class ManageRecentDocsService {

    @Value("${fileServerPath}")
    String fileServerPath;

    @Autowired
    private ManageRecentDocsRepository managerecentdocsrepo;

    // Used for Save & Edit also
    @Transactional
    public <json> EncryptedResponse saveRecentDocs(ManageRecentDocs body) throws Exception {

        UUID uuid = UUID.randomUUID();
        Long id = body.getId();

        //Optional<ManageRecentDocs> savedObj = managerecentdocsrepo.findById(id);

        var pdfPathTenth = fileServerPath + "document" + uuid + ".pdf";

        File fileTenth = new File(pdfPathTenth);

        byte[] docUpload = Base64.getDecoder().decode(body.getUploadDocument().split(",")[1]);

        FileValidator.validateFileSize(docUpload, 5);

        // if (savedObj.isPresent()) {
        //     try {
        //         ManageRecentDocs existingDetails = savedObj.get();

        //         try (OutputStream stream = FileUtils.openOutputStream(fileTenth))
        //         {
        //             stream.write(docUpload);
        //             existingDetails.setUploadDocument(uuid.toString());
        //         }
        //         existingDetails.setId((body.getId()));
        //         existingDetails.setTitle(body.getTitle());
        //         existingDetails.setSecurityGroup(body.getSecurityGroup());
        //         existingDetails.setType(body.getType());
        //         existingDetails.setDocumentType(body.getDocumentType());
        //         existingDetails.setDescription(body.getDescription());
        //         existingDetails.setStatus(body.getStatus());
        //         existingDetails.setReceivedDate(body.getReceivedDate());
        //         existingDetails.setRegion(body.getRegion());

        //         managerecentdocsrepo.save(existingDetails);

        //         return new EncryptedResponse("Document uploaded");
        //     } catch (Exception e) {
        //         return new EncryptedResponse("some error occured");
        //     }
        // } else {
                try {
                
                ManageRecentDocs newDetails = new ManageRecentDocs();

                newDetails.setTitle(body.getTitle());
                newDetails.setSecurityGroup(body.getSecurityGroup());
                newDetails.setRegion(body.getRegion());
                newDetails.setType(body.getType());
                newDetails.setDocumentType(body.getDocumentType());
                newDetails.setDescription(body.getDescription());
                newDetails.setStatus(body.getStatus());
                newDetails.setReceivedDate(body.getReceivedDate());
                
                try (OutputStream stream = FileUtils.openOutputStream(fileTenth)) 
                {
                    stream.write(docUpload);
                    newDetails.setUploadDocument(uuid.toString());

                    
                }

                managerecentdocsrepo.save(newDetails);
                System.out.println(newDetails);

                return new EncryptedResponse("Document saved successfully");

            } catch (Exception e) 
            {
                return new EncryptedResponse("Error saving document");
            }
        }
    //}

// ---------------------------------------------------
// 2 - Getting uploaded docs - Service
    

    // public Page<ManageRecentDocs> findByFilters(String searchQuery, String title, String documentType, String type,
    //         ZonedDateTime receivedDateFrom, ZonedDateTime receivedDateTo, PageRequest pageable) {

    //     return managerecentdocsrepo.findAll(pageable)
    // }
    
    public List<ManageRecentDocs> getAllManageRecentDocs(PageRequest page){
        return managerecentdocsrepo.findAll();
    }

    // ---------------------------------------------------------------------
    // 3 - Delete 

    @Transactional
    public boolean deleteDocById(Long id) {
        // managerecentdocsrepo.deleteById(id);

        if (managerecentdocsrepo.existsById(id)) {
            managerecentdocsrepo.deleteById(id);
            return true;
        } else
            return false;
    }
// ---------------------------------------------------------------------

   

}
