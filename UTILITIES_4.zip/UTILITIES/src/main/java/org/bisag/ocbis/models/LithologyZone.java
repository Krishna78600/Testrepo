package org.bisag.ocbis.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "fsp_lithology_zone")
public class LithologyZone {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String rockCharacteristics;
    private String otherRockCharacteristics;
    private String rockTypes;
    private String otherRockTypes;
    private String depth;
    private String proposalId;
    private Long fspFormId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRockCharacteristics() {
        return rockCharacteristics;
    }

    public void setRockCharacteristics(String rockCharacteristics) {
        this.rockCharacteristics = rockCharacteristics;
    }

    public String getRockTypes() {
        return rockTypes;
    }

    public void setRockTypes(String rockTypes) {
        this.rockTypes = rockTypes;
    }

    public String getDepth() {
        return depth;
    }

    public void setDepth(String depth) {
        this.depth = depth;
    }

    public String getProposalId() {
        return proposalId;
    }

    public void setProposalId(String proposalId) {
        this.proposalId = proposalId;
    }

    public Long getFspFormId() {
        return fspFormId;
    }

    public void setFspFormId(Long fspFormId) {
        this.fspFormId = fspFormId;
    }

    public String getOtherRockCharacteristics() {
        return otherRockCharacteristics;
    }

    public void setOtherRockCharacteristics(String otherRockCharacteristics) {
        this.otherRockCharacteristics = otherRockCharacteristics;
    }

    public String getOtherRockTypes() {
        return otherRockTypes;
    }

    public void setOtherRockTypes(String otherRockTypes) {
        this.otherRockTypes = otherRockTypes;
    }

}
