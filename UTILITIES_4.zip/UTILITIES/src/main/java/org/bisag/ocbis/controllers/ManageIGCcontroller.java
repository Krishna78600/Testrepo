package org.bisag.ocbis.controllers;

import org.bisag.ocbis.models.ManageIGCcontacts;
import org.bisag.ocbis.models.ManageIGCphotos;
import org.bisag.ocbis.models.User;
import org.bisag.ocbis.payloads.request.EncryptedRequest;
import org.bisag.ocbis.payloads.request.Report;
import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.services.ManageIGCservice;
import org.bisag.ocbis.utils.Json;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;


@RestController
@CrossOrigin("*")
@RequestMapping("/igc")
public class ManageIGCcontroller {

    @Autowired
    ManageIGCservice manageigcservice;
    
    // 1. Manage IGC Contact save - website is taking as String ( link )
    @PostMapping("/save-manage-igc-contact")
    public <json> EncryptedResponse saveManageIGCcontact(@RequestBody EncryptedRequest req, HttpServletRequest request, @AuthenticationPrincipal User user) throws Exception {
        try {
            var body = Json.deserialize(ManageIGCcontacts.class, req.getData());
            manageigcservice.saveManageIGCcontacts(body);
            return new EncryptedResponse("IGC contact saved");

        } catch (Exception e) {
            return new EncryptedResponse("IGC contact not saved ");
        }
    }


    // 2. Manage IGC contacts view all 
    @GetMapping("/get-igc-contacts")
    public EncryptedResponse getAllIGCcontacts(@RequestBody EncryptedRequest req ) throws Exception {

        try {
            var body = Json.deserialize(Report.class , req.getData());
            manageigcservice.getAllIGCcontacts(body);
            return new EncryptedResponse("contact list is here ");

        } catch (Exception e) {
            return new EncryptedResponse("Error : " +e.getMessage());
        }
    }


    // 3. Mangage IGC photo save 
    @PostMapping("/save-manage-igc-photo")
    public <json> EncryptedResponse SaveManageIGCphoto(@RequestBody EncryptedRequest req, HttpServletRequest request, @AuthenticationPrincipal User user) throws Exception {
     try {
         var body = Json.deserialize(ManageIGCphotos.class, req.getData());
         return manageigcservice.saveManageIGCphotos(body);
     } catch (Exception e) {
         return new EncryptedResponse("Error : " +e.getMessage());
     }
 }

    // 2. Manage IGC document save

    // @PostMapping("/save-manage-igc-doc") 
    // public <json> EncryptedResponse SaveManageIGCdoc(@RequestBody EncryptedRequest req, HttpServletRequest request, @AuthenticationPrincipal User user) throws Exception {
    //     try {
    //         var body = Json.deserialize(ManageIGCcontacts.class, req.getData());
    //         manageigcservice.saveManageIGCdocs(body);
    //         return new EncryptedResponse("IGC document saved");

    //     } catch (Exception e) {
    //         return new EncryptedResponse("document not saved ");
    //     }
    // }
  
}
