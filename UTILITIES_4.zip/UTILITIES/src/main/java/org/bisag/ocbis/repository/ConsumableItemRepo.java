package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.ConsumableItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsumableItemRepo extends JpaRepository<ConsumableItem, Long> {
    
}
