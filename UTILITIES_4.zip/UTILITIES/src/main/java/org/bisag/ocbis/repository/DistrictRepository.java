package org.bisag.ocbis.repository;

import java.util.List;
import java.util.Map;

import org.bisag.ocbis.models.District;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface DistrictRepository extends JpaRepository<District, Integer> {

  List<District> findByStatecodeAndDistrictnameNotNullOrderByDistrictnameAsc(String id);

  List<District> findAllByDistrictnameNotNullOrderByDistrictnameAsc();

  @Query(nativeQuery = true, value = """
          SELECT name11 as District, minx, miny, maxx, maxy
          FROM district_boundary_21_03_2023
          WHERE UPPER(name11) LIKE UPPER(?1)
          GROUP BY name11, minx, miny, maxx, maxy
      """)
  List<Map<String, Object>> search(String query);
}
