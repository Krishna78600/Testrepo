package org.bisag.ocbis.payloads.request;
import java.util.List;

import org.bisag.ocbis.models.ConsumableItem;
import org.bisag.ocbis.models.NonConsumableItem;
import org.bisag.ocbis.models.OperationalExpense;

public record OperationalExpenseRequest(
   Long fspFormId,
   List<OperationalExpense> expenses,
   List<ConsumableItem> consumableItems,
   List<NonConsumableItem> nonConsumableItems,
   String proposalId , Integer stepsCompleted) {
    
}
