package org.bisag.ocbis.models;

import java.util.Collection;
import java.util.Map;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import jakarta.persistence.*;

@Entity
@Table(name = "ocbis_users", uniqueConstraints = { @UniqueConstraint(columnNames = "email") })
public class User implements UserDetails {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private String email;
  private String password;
  private String mobile;
  private String otp;
  private Integer otpCount;
  private Long otpTimestamp;
  private String captcha;
  private String employeeName;
  private Boolean isVerified;
  private Long jwtTimestamp;

  @Column(columnDefinition = "text")
  String employeeId;
  String designation;
  private String username;
  private Long roleId;
  private String stateId;
  private String regionalId;
  private String parentMissionId;
  private String submMissionId;
  private String designationId;

  @Transient
  private boolean isEnabled;
  @Column(columnDefinition = "jsonb")
  @JdbcTypeCode(SqlTypes.JSON)
  Map<String, Object> access;
  // private Json access;

  @Transient
  private Collection<? extends GrantedAuthority> authorities;

  @Override
  public Collection<? extends GrantedAuthority> getAuthorities() {
    return authorities;
  }

  @Override
  public boolean isAccountNonExpired() {
    return true;
  }

  @Override
  public boolean isAccountNonLocked() {
    return true;
  }

  @Override
  public boolean isCredentialsNonExpired() {
    return true;
  }

  @Override
  public boolean isEnabled() {
    return true;
  }

  public String getEmployeeId() {
    return employeeId;
  }

  public void setEmployeeIdCardPath(String employeeId) {
    this.employeeId = employeeId;
  }

  public String getDesignation() {
    return designation;
  }

  public void setDesignation(String designation) {
    this.designation = designation;
  }

  public void setAuthorities(Collection<? extends GrantedAuthority> authorities) {
    this.authorities = authorities;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getMobile() {
    return mobile;
  }

  public void setMobile(String mobile) {
    this.mobile = mobile;
  }

  public String getOtp() {
    return otp;
  }

  public void setOtp(String otp) {
    this.otp = otp;
  }

  public Integer getOtpCount() {
    return otpCount;
  }

  public void setOtpCount(Integer otpCount) {
    this.otpCount = otpCount;
  }

  public Long getOtpTimestamp() {
    return otpTimestamp;
  }

  public void setOtpTimestamp(Long otpTimestamp) {
    this.otpTimestamp = otpTimestamp;
  }

  public String getCaptcha() {
    return captcha;
  }

  public void setCaptcha(String captcha) {
    this.captcha = captcha;
  }

  public Boolean getIsVerified() {
    return isVerified;
  }

  public void setIsVerified(Boolean isVerified) {
    this.isVerified = isVerified;
  }

  public Long getJwtTimestamp() {
    return jwtTimestamp;
  }

  public void setJwtTimestamp(Long jwtTimestamp) {
    this.jwtTimestamp = jwtTimestamp;
  }

  public String getEmployeeName() {
    return employeeName;
  }

  public void setEmployeeName(String employeeName) {
    this.employeeName = employeeName;
  }

  public void setEnabled(boolean isEnabled) {
    this.isEnabled = isEnabled;
  }

  public void setEmployeeId(String employeeId) {
    this.employeeId = employeeId;
  }

  // public Json getAccess() {
  // return access;
  // }

  // public void setAccess(Json access) {
  // this.access = access;
  // }

  public String getStateId() {
    return stateId;
  }

  public void setStateId(String stateId) {
    this.stateId = stateId;
  }

  public String getRegionalId() {
    return regionalId;
  }

  public void setRegionalId(String regionalId) {
    this.regionalId = regionalId;
  }

  public String getParentMissionId() {
    return parentMissionId;
  }

  public void setParentMissionId(String parentMissionId) {
    this.parentMissionId = parentMissionId;
  }

  public String getSubmMissionId() {
    return submMissionId;
  }

  public void setSubmMissionId(String submMissionId) {
    this.submMissionId = submMissionId;
  }

  public String getDesignationId() {
    return designationId;
  }

  public void setDesignationId(String designationId) {
    this.designationId = designationId;
  }

  public Map<String, Object> getAccess() {
    return access;
  }

  public void setAccess(Map<String, Object> access) {
    this.access = access;
  }

  @Override
  public String toString() {
    return "User [id=" + id + ", email=" + email + ", password=" + password + ", mobile=" + mobile + ", stateId="
        + stateId
        + ", otp=" + otp + ", otpCount=" + otpCount + ", otpTimestamp=" + otpTimestamp
        + ", captcha=" + captcha + ", fullName=" + employeeName + ", isVerified=" + isVerified
        + ", jwtTimestamp=" + jwtTimestamp + "]";
  }

  public Long getRoleId() {
    return roleId;
  }

  public void setRoleId(Long roleId) {
    this.roleId = roleId;
  }

}
