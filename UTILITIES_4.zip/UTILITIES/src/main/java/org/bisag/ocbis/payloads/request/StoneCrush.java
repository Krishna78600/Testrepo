package org.bisag.ocbis.payloads.request;

public record StoneCrush(String wkt, String tblname) {}
