package org.bisag.ocbis.models;
import java.io.Serializable;

import jakarta.persistence.*;

// import javax.persistence.Entity;
// import javax.persistence.GeneratedValue;
// import javax.persistence.GenerationType;
// import javax.persistence.Id;
// import javax.persistence.Table;

@Entity
@Table(name="ministry_progress")
public class Progress implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String date;
	private String progress;
	private Integer ministryid;
	private String username;
	private Integer userid;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getProgress() {
		return progress;
	}
	public void setProgress(String progress) {
		this.progress = progress;
	}

	public Integer getMinistryid() {
		return ministryid;
	}
	public void setMinistryid(Integer ministryid) {
		this.ministryid = ministryid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	@Override
	public String toString() {
		return "Progress [id=" + id + ", date=" + date + ", progress=" + progress + ", ministryid=" + ministryid
				+ ", username=" + username + ", userid=" + userid + "]";
	}


}
