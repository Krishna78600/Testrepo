package org.bisag.ocbis.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bisag.ocbis.models.District;
import org.bisag.ocbis.models.State;
import org.bisag.ocbis.models.Taluka;
import org.bisag.ocbis.models.Village;
import org.bisag.ocbis.payloads.request.BoundaryRequest;
import org.bisag.ocbis.repository.DistrictRepository;
import org.bisag.ocbis.repository.StateRepsitory;
import org.bisag.ocbis.repository.TalukaRepository;
import org.bisag.ocbis.repository.VillageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class NavigationService {
  @Autowired
  StateRepsitory stateRepo;
  @Autowired
  DistrictRepository districtRepo;
  @Autowired
  TalukaRepository talukaRepo;
  @Autowired
  VillageRepository villageRepo;
  @Autowired
  JdbcTemplate jdbcTemplate;

  public List<State> getAllStates() {
    return stateRepo.findAllByStatenameNotNullOrderByStatenameAsc();
  }

  public List<District> getAllDistricts() {
    return districtRepo.findAllByDistrictnameNotNullOrderByDistrictnameAsc();
  }

  public List<District> getDistrictsByStateId(String stateId) {
    return districtRepo
        .findByStatecodeAndDistrictnameNotNullOrderByDistrictnameAsc(stateId);
  }

  public List<Taluka> getTalukasByDistrictId(String districtId) {
    return talukaRepo
        .findByDistrictcodeAndTalukanameNotNullOrderByTalukanameAsc(districtId);
  }

  public List<Village> getVillagesByTalukaId(String talukaId) {
    return villageRepo
        .findByTalukacodeAndVillageNameNotNullOrderByVillageNameAsc(talukaId);
  }

  public List<Map<String, Object>> getBoundary(BoundaryRequest boundaryRequest) {
    String query = "SELECT ST_AsGeoJSON(geom) FROM " + boundaryRequest.table()
        + " WHERE " + boundaryRequest.column() + " = ?";
    return jdbcTemplate.queryForList(query, boundaryRequest.id());
  }

  public List<Map<String, Object>> searchAll(String query) {
    String startsWithQuery = query + "%";
    var states = stateRepo.search(startsWithQuery);
    var districts = districtRepo.search(startsWithQuery);
    var talukas = talukaRepo.search(startsWithQuery);
    var villages = villageRepo.search(startsWithQuery);
    var totalSize = states.size() + districts.size() + talukas.size() + villages.size();
    var mergedList = new ArrayList<Map<String, Object>>(totalSize);
    mergedList.addAll(states);
    mergedList.addAll(districts);
    mergedList.addAll(talukas);
    mergedList.addAll(villages);
    return mergedList;
  }
}
