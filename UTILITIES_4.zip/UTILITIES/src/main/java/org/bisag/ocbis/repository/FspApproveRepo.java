package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.FspApprove;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import java.util.Map;
import java.util.List;

import java.time.ZonedDateTime;

public interface FspApproveRepo extends JpaRepository<FspApprove, Long> {

        @Query(nativeQuery = true, value = """
                        SELECT * FROM fsp_approve_levels_details WHERE fsp_form_id = ?1
                        """)
        FspApprove findByFormId(long id);

        @Query(nativeQuery = true, value = """
                                SELECT first_approving_authority_name,parent_mission_code,sub_mission_code FROM fsp_approve_levels_details WHERE fsp_form_id = ?1
                        """)
        List<Map<String, Object>> getFspApproveFactors(Long id);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details SET forwarded_by_fsp_creater = ?1,forwarded_to_suhead = ?2, fsp_creater_created_date = ?3,
                        auto_push_status='Approve'
                        WHERE fsp_form_id = ?4
                        """)
        void forwardToSUhead(Long forwardedByFspCreaterId, Long forwardedToSuHeadId, ZonedDateTime createdDate,
                        Long fspFormId, String stateId, String remakrs, String status);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details SET forwarded_by_suhead = ?1,forwarded_to_rmh_of_pm = ?2, su_head_created_date = ?3,su_head_remarks = ?5,su_head_status = ?6 WHERE fsp_form_id = ?4
                        """)
        void forwardToRmhOfPmBySuHead(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate,
                        Long fspFormId, String remakrs, String status, String stateId);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details SET forwarded_by_rmh_of_pm = ?1,forwarded_to_hod = ?2, rmh_of_pm_created_date = ?3,rmh_of_pm_remarks = ?5,rmh_of_pm_status = ?6 WHERE fsp_form_id = ?4
                        """)
        void forwardToHodByRmhOfPm(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate,
                        Long fspFormId, String remakrs, String status, String stateId);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details SET forwarded_by_hod = ?1,forwarded_to_ddg_of_sm = ?2, hod_created_date = ?3,hod_remarks = ?5,hod_status = ?6 WHERE fsp_form_id = ?4
                        """)
        void forwardToDdgofSmByHod(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate,
                        Long fspFormId, String remakrs, String status, String stateId);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details SET forwarded_by_ddg_of_sm = ?1,forwarded_to_adg_of_pss = ?2, ddg_of_sm_created_date = ?3,ddg_of_sm_remarks = ?5,ddg_of_sm_status = ?6 WHERE fsp_form_id = ?4
                        """)
        void forwardToAdgOfPssByDdgofSm(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate,
                        Long fspFormId, String remakrs, String status, String stateId);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details SET forwarded_by_suhead = ?1,forwarded_to_hod = ?2, su_head_created_date = ?3,su_head_remarks = ?5,su_head_status = ?6 WHERE fsp_form_id = ?4
                        """)
        void forwardToHodBySu(Long forwardeByOfficerUserId, Long forwardeToOfficerUserId,
                        ZonedDateTime createdDate,
                        Long fspFormId, String remakrs, String status, String stateId);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details SET forwarded_by_adg_of_pss = ?1, adg_of_pss_created_date = ?2,adg_of_pss_remarks = ?4,adg_of_pss_status = ?5 WHERE fsp_form_id = ?3
                        """)
        void forwardedByAdgOfPss(Long forwardeByOfficerUserId,
                        ZonedDateTime createdDate,
                        Long fspFormId, String remakrs, String status, String stateId);

        // @Modifying
        // @Query(nativeQuery = true, value = """
        // UPDATE fsp_approve_levels_details SET reject_or_return_fsp_forwardedby_id =
        // ?1, forwarded_to_fsp_creater_id = ?2,reject_or_return_fsp_status = ?3,
        // reject_or_return_fsp_remarks = ?4,reject_or_return_fsp_created_date = ?6,
        // auto_push_status = null,forwarded_by_suhead = null, forwarded_to_suhead =
        // null, su_head_remarks = null, su_head_status = null, su_head_created_date =
        // null,
        // forwarded_by_rmh_of_pm = null, forwarded_to_rmh_of_pm = null,
        // rmh_of_pm_remarks = null, rmh_of_pm_status = null, rmh_of_pm_created_date =
        // null,
        // forwarded_by_nmh_of_pm = null, forwarded_to_nmh_of_pm = null,
        // nmh_of_pm_remarks = null, nmh_of_pm_status = null, nmh_of_pm_created_date =
        // null,
        // forwarded_by_hod = null, forwarded_to_hod = null, hod_remarks = null,
        // hod_status = null, hod_created_date = null,
        // forwarded_by_ddg_of_sm = null, forwarded_to_ddg_of_sm = null,
        // ddg_of_sm_remarks = null, ddg_of_sm_status = null, ddg_of_sm_created_date =
        // null,
        // forwarded_by_ddg_of_stss_or_adss = null,forwarded_to_ddg_of_stss_or_adss =
        // null, ddg_of_stss_or_adss_remarks = null, ddg_of_stss_or_adss_status = null,
        // ddg_of_stss_or_adss_created_date = null,
        // forwarded_by_adg_of_pss = null, forwarded_to_adg_of_pss = null,
        // adg_of_pss_remarks = null, adg_of_pss_status = null, adg_of_pss_created_date
        // = null,
        // forwarded_by_adg_of_stss_or_adss = null, adg_or_stss_of_adss_remarks = null,
        // adg_or_stss_of_adss_status = null, adg_or_stss_of_adssd_created_date =
        // null,forwarded_to_adg_of_stss_or_adss = null
        // WHERE fsp_form_id = ?5
        // """)
        // void rejectOrReturnFsp(Long forwardedById, Long forwardedToId, String status,
        // String remarks,
        // Long fspFormId, ZonedDateTime createdDate);

        @Modifying
        @Query(nativeQuery = true, value = """
                        UPDATE fsp_approve_levels_details SET reject_or_return_fsp_forwardedby_id = ?1, forwarded_to_fsp_creater_id = ?2,reject_or_return_fsp_status = ?3,
                        reject_or_return_fsp_remarks  = ?4,reject_or_return_fsp_created_date = ?6
                        WHERE fsp_form_id = ?5
                                        """)
        void rejectOrReturnFsp(Long forwardedById, Long forwardedToId, String status, String remarks,
                        Long fspFormId, ZonedDateTime createdDate);

}
