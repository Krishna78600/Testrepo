package org.bisag.ocbis.models;

import java.time.ZonedDateTime;
import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "fsp_peer_review")
public class PeerReview {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String proposalId;
    private Long fspFormId;

    private Long appliedForPeerReviewByPss;
    private Long appliedForPeerReviewToRmh;
   
    private Long appliedForPeerReviewToNmh;
    private String remarks;
    private String rmhRemarks;
    private String nmhRemarks;
    public ZonedDateTime getRmhPeerReviewDate() {
        return rmhPeerReviewDate;
    }

    public void setRmhPeerReviewDate(ZonedDateTime rmhPeerReviewDate) {
        this.rmhPeerReviewDate = rmhPeerReviewDate;
    }

    public ZonedDateTime getNmhPeerReviewDate() {
        return nmhPeerReviewDate;
    }

    public void setNmhPeerReviewDate(ZonedDateTime nmhPeerReviewDate) {
        this.nmhPeerReviewDate = nmhPeerReviewDate;
    }

    private String status;
    private String rmhStatus;
    private String nmhStatus;
    private ZonedDateTime rmhPeerReviewDate;
    private ZonedDateTime nmhPeerReviewDate;

    private ZonedDateTime pssAppliedCreatedDate;
    
    public String getRmhRemarks() {
        return rmhRemarks;
    }

    public void setRmhRemarks(String rmhRemarks) {
        this.rmhRemarks = rmhRemarks;
    }

    public String getNmhRemarks() {
        return nmhRemarks;
    }

    public void setNmhRemarks(String nmhRemarks) {
        this.nmhRemarks = nmhRemarks;
    }

    public String getRmhStatus() {
        return rmhStatus;
    }

    public void setRmhStatus(String rmhStatus) {
        this.rmhStatus = rmhStatus;
    }

    public String getNmhStatus() {
        return nmhStatus;
    }

    public void setNmhStatus(String nmhStatus) {
        this.nmhStatus = nmhStatus;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProposalId() {
        return proposalId;
    }

    public void setProposalId(String proposalId) {
        this.proposalId = proposalId;
    }

    public Long getFspFormId() {
        return fspFormId;
    }

    public void setFspFormId(Long fspFormId) {
        this.fspFormId = fspFormId;
    }

    public Long getAppliedForPeerReviewByPss() {
        return appliedForPeerReviewByPss;
    }

    public void setAppliedForPeerReviewByPss(Long appliedForPeerReviewByPss) {
        this.appliedForPeerReviewByPss = appliedForPeerReviewByPss;
    }

    public Long getAppliedForPeerReviewToRmh() {
        return appliedForPeerReviewToRmh;
    }

    public void setAppliedForPeerReviewToRmh(Long appliedForPeerReviewToRmh) {
        this.appliedForPeerReviewToRmh = appliedForPeerReviewToRmh;
    }

    public Long getAppliedForPeerReviewToNmh() {
        return appliedForPeerReviewToNmh;
    }

    public void setAppliedForPeerReviewToNmh(Long appliedForPeerReviewToNmh) {
        this.appliedForPeerReviewToNmh = appliedForPeerReviewToNmh;
    }

    public ZonedDateTime getPssAppliedCreatedDate() {
        return pssAppliedCreatedDate;
    }

    public void setPssAppliedCreatedDate(ZonedDateTime pssAppliedCreatedDate) {
        this.pssAppliedCreatedDate = pssAppliedCreatedDate;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
