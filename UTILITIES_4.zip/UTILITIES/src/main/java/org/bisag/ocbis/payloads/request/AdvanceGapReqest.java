package org.bisag.ocbis.payloads.request;

public record AdvanceGapReqest(String inputLength_GapDistance_g,
                String state_GapAddtool,
                String district_GapAddtool,
                String tbl_Gap,
                String tbl_Gap1) {

}
