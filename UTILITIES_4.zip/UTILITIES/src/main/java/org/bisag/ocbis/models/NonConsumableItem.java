package org.bisag.ocbis.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "fsp_non_consumable_item")
public class NonConsumableItem {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String operationalNonConsumable;
    private Integer nonConsumableQuantity;
    private Integer unitPrice;
    private Integer nonConsumableTotal;
    private String proposalId;
    private Long fspFormId;
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getOperationalNonConsumable() {
        return operationalNonConsumable;
    }
    public void setOperationalNonConsumable(String operationalNonConsumable) {
        this.operationalNonConsumable = operationalNonConsumable;
    }
    public Integer getUnitPrice() {
        return unitPrice;
    }
    public void setUnitPrice(Integer unitPrice) {
        this.unitPrice = unitPrice;
    }
    public String getProposalId() {
        return proposalId;
    }
    public void setProposalId(String proposalId) {
        this.proposalId = proposalId;
    }
    public Integer getNonConsumableQuantity() {
        return nonConsumableQuantity;
    }
    public void setNonConsumableQuantity(Integer nonConsumableQuantity) {
        this.nonConsumableQuantity = nonConsumableQuantity;
    }
    public Integer getNonConsumableTotal() {
        return nonConsumableTotal;
    }
    public void setNonConsumableTotal(Integer nonConsumableTotal) {
        this.nonConsumableTotal = nonConsumableTotal;
    }
    public Long getFspFormId() {
        return fspFormId;
    }
    public void setFspFormId(Long fspFormId) {
        this.fspFormId = fspFormId;
    }

    
}
