package org.bisag.ocbis.payloads.request;

public record LoginRequest(
    String email,
    String password,
    String mobile,
    String captcha,
    String date,
    String otp,
    String fp,
    String fullName,
    Boolean isVerified,
    String stateId,
    String districtId, String orgName, String orgType, String employeeIdCard, String designation) {
}
