package org.bisag.ocbis.controllers;

import org.apache.commons.io.FileUtils;
import org.apache.coyote.BadRequestException;

import org.bisag.ocbis.models.User;

import org.bisag.ocbis.payloads.request.EncryptedRequest;
import org.bisag.ocbis.payloads.request.GetId;

import org.bisag.ocbis.payloads.request.Report;

import org.bisag.ocbis.payloads.response.EncryptedResponse;
import org.bisag.ocbis.utils.FileValidator;

import java.util.List;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import java.io.File;
import java.io.OutputStream;
import java.time.ZonedDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@RestController
@CrossOrigin("*")
@RequestMapping("/createVigilance")
public class CreateVigilanceController {

  @Value("${fileServerPath}")
  String fileServerPath;

  // @Transactional
  // @PostMapping("/save-complainant-details")
  // public EncryptedResponse saveComplainantDetails(@Valid @RequestBody
  // EncryptedRequest req,
  // HttpServletRequest request)
  // throws Exception {
  // FspDetails body = req.bodyAs(FspDetails.class);
  // }
}
