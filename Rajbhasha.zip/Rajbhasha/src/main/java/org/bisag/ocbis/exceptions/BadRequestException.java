package org.bisag.ocbis.exceptions;

public class BadRequestException extends Exception {
  public BadRequestException(String msg) {
    super(msg);
  }
}
