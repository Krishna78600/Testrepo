package org.bisag.ocbis.payloads.request;

import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

public record IdWithPaginate(CustomPagination paginate, String id, String onSelect,
    Map<String, Object> filter) {
  public IdWithPaginate {
    if (filter == null) {
      filter = Map.of();
    } else {
      for (var entry : filter.entrySet()) {
        var v = entry.getValue();
        if (v == null) {
          continue;
        }
        if ((v instanceof String && StringUtils.isBlank((String) v))
            || (v instanceof List && ((List<?>) v).size() == 0)) {
          entry.setValue(null);
        }
      }
    }
  }
}
