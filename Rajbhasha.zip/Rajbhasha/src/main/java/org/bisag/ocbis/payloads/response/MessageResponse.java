package org.bisag.ocbis.payloads.response;

public record MessageResponse(String message) {}
