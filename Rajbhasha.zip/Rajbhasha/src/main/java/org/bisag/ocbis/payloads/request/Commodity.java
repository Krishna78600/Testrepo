package org.bisag.ocbis.payloads.request;

public class Commodity {

    Commodity[] commodity;

    public Commodity[] getCommodity() {
        return commodity;
    }

    public void setCommodity(Commodity[] commodity) {
        this.commodity = commodity;
    }

    

    
}
