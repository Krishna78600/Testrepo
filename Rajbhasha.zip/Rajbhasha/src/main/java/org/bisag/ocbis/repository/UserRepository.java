package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface UserRepository extends JpaRepository<User, Long> {

    User findFirstByEmail(String username);

     @Query(nativeQuery = true, value = """
            SELECT * FROM ocbis_users WHERE designation_id = '11' AND state_id = ?1 limit 1
    """)
    User findSuHeadStateWise(String stateId);

}
