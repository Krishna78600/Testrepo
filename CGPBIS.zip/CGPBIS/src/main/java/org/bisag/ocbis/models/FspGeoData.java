package org.bisag.ocbis.models;

import org.locationtech.jts.geom.Geometry;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "fsp_data")
public class FspGeoData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "wkt", columnDefinition = "VARCHAR")
    private String wkt;
    @JsonIgnore
    private Geometry geom;
    private Long fsp_form_id;
    private String proposal_id;
    private String topo_sheet_number; 



    public String getProposal_id() {
        return proposal_id;
    }

    public void setProposal_id(String proposal_id) {
        this.proposal_id = proposal_id;
    }

    public Long getFsp_form_id() {
        return fsp_form_id;
    }

    public void setFsp_form_id(Long fsp_form_id) {
        this.fsp_form_id = fsp_form_id;
    }

    public String getTopo_sheet_number() {
        return topo_sheet_number;
    }

    public void setTopo_sheet_number(String topo_sheet_number) {
        this.topo_sheet_number = topo_sheet_number;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getWkt() {
        return wkt;
    }

    public void setWkt(String wkt) {
        this.wkt = wkt;
    }

    public Geometry getGeom() {
        return geom;
    }

    public void setGeom(Geometry geom) {
        this.geom = geom;
    }

}
