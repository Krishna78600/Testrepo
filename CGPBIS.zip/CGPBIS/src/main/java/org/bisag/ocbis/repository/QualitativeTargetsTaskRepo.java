package org.bisag.ocbis.repository;

import org.bisag.ocbis.models.QualitativeTargetsTask;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface QualitativeTargetsTaskRepo extends JpaRepository<QualitativeTargetsTask, Long> {

     void deleteByFspFormId(Long fspFormId);
    List<QualitativeTargetsTask> findByFspFormId(Long fspFormId);

}
