package org.bisag.ocbis.payloads.request;

public record CustomPagination(String search, Long limit, Long offset, Long page) {}
