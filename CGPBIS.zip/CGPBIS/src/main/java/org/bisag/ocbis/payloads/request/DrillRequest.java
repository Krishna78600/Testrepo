package org.bisag.ocbis.payloads.request;

import java.util.List;

import org.bisag.ocbis.models.LithologyZone;

public record DrillRequest( String block,
                String otherBlock,
                Integer area,
                Integer altitude,
                String terrainConditions,
                Integer nearestRailHeadName,
                String railHeadDistance,
                String waterSourceType,
                String clearanceReceivedfrom,
                String quantumOfDrilling,
                Integer numberOfBoreholes,
                Integer boreHolesAngle,
                String boreHoleSpacing,
                Integer boreSize,
                Integer estimatedBoreholeDepthRange,
                String pattern,
                String patternText,
                String coreRecoveryMineralised,
                String coreRecoveryFormations,
                String geophysicalBhlog,
                String geophysicalBhlogNumber,
                String typeOfDrilling,
                String drillingBy,
                String otherDrillingBy, List<LithologyZone> lithology, Long fspFormId, String proposalId,
                Integer stepsCompleted) {

}
