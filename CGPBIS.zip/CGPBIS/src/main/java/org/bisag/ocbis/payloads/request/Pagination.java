package org.bisag.ocbis.payloads.request;

public record Pagination(int page, int size) {};
