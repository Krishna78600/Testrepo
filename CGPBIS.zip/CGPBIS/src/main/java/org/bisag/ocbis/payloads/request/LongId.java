package org.bisag.ocbis.payloads.request;

public record LongId(Long id) {
}
