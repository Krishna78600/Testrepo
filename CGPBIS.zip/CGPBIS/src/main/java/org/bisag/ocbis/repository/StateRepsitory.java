package org.bisag.ocbis.repository;

import java.util.List;
import java.util.Map;

import org.bisag.ocbis.models.State;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface StateRepsitory extends JpaRepository<State, Integer> {

  List<State> findAllByStatenameNotNullOrderByStatenameAsc();

  @Query(nativeQuery = true, value = """
          SELECT stname as State, minx, miny, maxx, maxy
          FROM state_boundary_21_03_2023
          WHERE UPPER(stname) LIKE UPPER(?1)
          GROUP BY stname, minx, miny, maxx, maxy
      """)
  List<Map<String, Object>> search(String query);
}
