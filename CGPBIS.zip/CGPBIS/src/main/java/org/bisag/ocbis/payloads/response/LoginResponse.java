package org.bisag.ocbis.payloads.response;

import org.bisag.ocbis.models.User;

public record LoginResponse(String token, User user) {}
