package org.bisag.ocbis.exceptions;

public class UnauthorizedException extends Exception {
  public UnauthorizedException(String msg) {
    super(msg);
  }
}
