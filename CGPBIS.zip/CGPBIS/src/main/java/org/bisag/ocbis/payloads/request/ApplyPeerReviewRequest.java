package org.bisag.ocbis.payloads.request;

public record ApplyPeerReviewRequest(String appliedForPeerReviewByPssId, String region,
                String proposalId, Long fspFormId, Long id, Long appliedForPeerReviewToRmh,
                Long appliedForPeerReviewToNmh,
                String remarks,
                String status, String keyword, String rmh_remarks, String nmh_remarks, String nmhStatus,
                String rmhStatus) {

}
