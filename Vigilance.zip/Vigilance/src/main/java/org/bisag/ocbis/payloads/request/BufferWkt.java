package org.bisag.ocbis.payloads.request;

import java.util.List;

public record BufferWkt(String wkt, double range, List<Double> ranges) {
}
